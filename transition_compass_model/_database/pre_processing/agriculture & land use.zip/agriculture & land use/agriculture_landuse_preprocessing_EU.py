import numpy as np
from model.common.auxiliary_functions import interpolate_nans, add_missing_ots_years, linear_fitting_ots_db, linear_fitting, create_years_list
#from _database.pre_processing.api_routines_CH import get_data_api_CH
from scipy.stats import linregress
import pandas as pd
import faostat
import os
import re
from model.common.data_matrix_class import DataMatrix
from model.common.constant_data_matrix_class import ConstantDataMatrix
from model.common.io_database import read_database, read_database_fxa, edit_database, database_to_df, dm_to_database, database_to_dm
from model.common.io_database import read_database_to_ots_fts_dict, read_database_to_ots_fts_dict_w_groups, read_database_to_dm
from model.common.interface_class import Interface
from model.common.auxiliary_functions import compute_stock,  filter_geoscale, calibration_rates, filter_years_DM, add_dummy_country_to_DM
from model.common.auxiliary_functions import read_level_data, simulate_input
from scipy.optimize import linprog
import pickle
import json
import os
import numpy as np
import time

# Ensure structure coherence
def ensure_structure(df):
    # Get unique values for geoscale, timescale, and variables
    df['timescale'] = df['timescale'].astype(int)
    df = df.drop_duplicates(subset=['geoscale', 'timescale', 'level', 'variables', 'lever', 'module'])
    lever_name = list(set(df['lever']))[0]
    countries = df['geoscale'].unique()
    years = df['timescale'].unique()
    variables = df['variables'].unique()
    level = df['level'].unique()
    lever = df['lever'].unique()
    module = df['module'].unique()
    # Create a complete multi-index from all combinations of unique values
    full_index = pd.MultiIndex.from_product(
         [countries, years, variables, level, lever, module],
            names=['geoscale', 'timescale', 'variables', 'level', 'lever', 'module']
        )
    # Reindex the DataFrame to include all combinations, filling missing values with NaN
    df = df.set_index(['geoscale', 'timescale', 'variables', 'level', 'lever', 'module'])
    df = df.reindex(full_index, fill_value=np.nan).reset_index()

    return df

def create_ots_years_list(years_setting):
    startyear: int = years_setting[0]  # Start year is argument [0], i.e., 1990
    baseyear: int = years_setting[1]  # Base/Reference year is argument [1], i.e., 2015
    lastyear: int = years_setting[2]  # End/Last year is argument [2], i.e., 2050
    step_fts = years_setting[3]  # Timestep for scenario is argument [3], i.e., 5 years
    years_ots = list(
        np.linspace(start=startyear, stop=baseyear, num=(baseyear - startyear) + 1).astype(int).astype(str))
    return years_ots
# CalculationLeaf DIET (LIFESTYLE) ------------------------------------------------------------------------------------
def diet_processing():
    # ----------------------------------------------------------------------------------------------------------------------
    # CONSUMER DIET Part 1 - including food waste
    # ----------------------------------------------------------------------------------------------------------------------

    # Read data ------------------------------------------------------------------------------------------------------------

    # Common for all
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # FOOD BALANCE SHEETS (FBS) - -------------------------------------------------
    # List of elements
    list_elements = ['Food supply (kcal/capita/day)']

    list_items = ['Cereals - Excluding Beer + (Total)', 'Fruits - Excluding Wine + (Total)', 'Oilcrops + (Total)',
                  'Pulses + (Total)', 'Rice (Milled Equivalent)',
                  'Starchy Roots + (Total)', 'Stimulants + (Total)', 'Sugar Crops + (Total)', 'Vegetables + (Total)',
                  'Demersal Fish', 'Freshwater Fish',
                  'Aquatic Animals, Others', 'Pelagic Fish', 'Beer', 'Beverages, Alcoholic', 'Beverages, Fermented',
                  'Wine', 'Sugar (Raw Equivalent)', 'Sweeteners, Other', 'Vegetable Oils + (Total)',
                  'Milk - Excluding Butter + (Total)', 'Eggs + (Total)', 'Animal fats + (Total)', 'Offals + (Total)',
                  'Bovine Meat', 'Meat, Other', 'Pigmeat',
                  'Poultry Meat', 'Mutton & Goat Meat', 'Fish, Seafood + (Total)', 'Coffee and products',
                  'Grand Total + (Total)']

    # 1990 - 2013
    ld = faostat.list_datasets()
    code = 'FBSH'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002',
                  '2003', '2004', '2005', '2006', '2007', '2008', '2009']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_diet_1990_2013 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # 2010-2022
    list_items = ['Cereals - Excluding Beer + (Total)', 'Fruits - Excluding Wine + (Total)', 'Oilcrops + (Total)',
                  'Pulses + (Total)', 'Rice and products',
                  'Starchy Roots + (Total)', 'Stimulants + (Total)', 'Sugar Crops + (Total)', 'Vegetables + (Total)',
                  'Demersal Fish', 'Freshwater Fish',
                  'Aquatic Animals, Others', 'Pelagic Fish', 'Beer', 'Beverages, Alcoholic', 'Beverages, Fermented',
                  'Wine', 'Sugar (Raw Equivalent)', 'Sweeteners, Other', 'Vegetable Oils + (Total)',
                  'Milk - Excluding Butter + (Total)', 'Eggs + (Total)', 'Animal fats + (Total)', 'Offals + (Total)',
                  'Bovine Meat', 'Meat, Other', 'Pigmeat',
                  'Poultry Meat', 'Mutton & Goat Meat', 'Fish, Seafood + (Total)', 'Coffee and products',
                  'Grand Total + (Total)']
    code = 'FBS'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021',
                  '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_diet_2010_2022 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Renaming the items for name matching
    df_diet_1990_2013.loc[
        df_diet_1990_2013['Item'].str.contains('Rice \(Milled Equivalent\)', case=False,
                                               na=False), 'Item'] = 'Rice and products'

    # Concatenating all the years together
    df_diet = pd.concat([df_diet_1990_2013, df_diet_2010_2022])

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Element', 'Item', 'Year', 'Value']
    df_diet = df_diet[columns_to_filter]

    # Filter to only have meat, fish, sugar, sweet, veg, fruits (the rest goes to share for further pre-processing)
    list_consumers_diet = ['Fruits - Excluding Wine', 'Vegetables',
                           'Demersal Fish', 'Freshwater Fish',
                           'Aquatic Animals, Others', 'Pelagic Fish',
                           'Sugar (Raw Equivalent)', 'Sweeteners, Other',
                           'Bovine Meat', 'Meat, Other', 'Pigmeat',
                           'Poultry Meat', 'Mutton & Goat Meat', 'Fish, Seafood']
    pattern_consumers_diet = '|'.join(re.escape(item) for item in list_consumers_diet)
    list_share = ['Cereals - Excluding Beer', 'Oilcrops',
                  'Pulses', 'Rice and products',
                  'Starchy Roots', 'Stimulants',
                  'Beer', 'Beverages, Alcoholic', 'Beverages, Fermented',
                  'Wine', 'Vegetable Oils',
                  'Milk - Excluding Butter', 'Eggs',
                  'Animal fats', 'Offals', 'Coffee and products', 'Grand Total']
    pattern_share = '|'.join(re.escape(item) for item in list_share)
    df_consumers_diet = df_diet[df_diet['Item'].str.contains(pattern_consumers_diet, case=False)]
    df_share = df_diet[df_diet['Item'].str.contains(pattern_share, case=False)]

    # Pivot the df
    pivot_df_consumers_diet = df_consumers_diet.pivot_table(index=['Area', 'Year', 'Item'], columns='Element',
                                                            values='Value').reset_index()
    # Rename columns
    #pivot_df_consumers_diet.rename(columns={'Food supply (kcal/capita/day)': 'value'}, inplace=True)

    # ----------------------------------------------------------------------------------------------------------------------
    # SHARE (FOR OTHER PRODUCTS)
    # ----------------------------------------------------------------------------------------------------------------------

    # Pivot the df
    pivot_df_share = df_share.pivot_table(index=['Area', 'Year', 'Item'], columns='Element',
                                          values='Value').reset_index()

    # Creating a column with the Grand Total kcal/cap/day
    # Step 1: Extract Grand Total for each Year and Area
    grand_totals = pivot_df_share[pivot_df_share['Item'] == 'Grand Total'][
        ['Area', 'Year', 'Food supply (kcal/capita/day)']]
    grand_totals.rename(columns={'Food supply (kcal/capita/day)': 'Grand Total'}, inplace=True)
    # Step 2: Merge the Grand Total back into the original DataFrame
    pivot_df_share = pivot_df_share.merge(grand_totals, on=['Area', 'Year'], how='left')
    # Step 3: Drop rows where Item is 'Grand Total'
    pivot_df_share = pivot_df_share[pivot_df_share['Item'] != 'Grand Total']

    # Divide the consumption by the total kcal to obtain the share
    pivot_df_share['value'] = pivot_df_share['Food supply (kcal/capita/day)'] / pivot_df_share['Grand Total']

    # Drop the columns
    pivot_df_share = pivot_df_share.drop(columns=['Food supply (kcal/capita/day)', 'Grand Total'])

    # Normalize so that for each year and country, sum(share) = 1
    pivot_df_share['value'] = pivot_df_share['value'] / pivot_df_share.groupby(['Area', 'Year'])['value'].transform(
        'sum')

    # ----------------------------------------------------------------------------------------------------------------------
    # CONSUMER DIET Part 2 - including food waste
    # ----------------------------------------------------------------------------------------------------------------------

    # Food item name matching with dictionary
    # Read excel file
    df_dict_waste = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='food-waste_lifestyle')

    # Merge based on 'Item'
    pivot_df_consumers_diet = pd.merge(df_dict_waste, pivot_df_consumers_diet, on='Item')

    # Food waste [kcal/cap/day] = food supply [kcal/cap/day] * food waste [%]
    pivot_df_consumers_diet['value'] = pivot_df_consumers_diet['Food supply (kcal/capita/day)'] * (1 - pivot_df_consumers_diet[
        'Proportion'])

    # Drop the unused columns
    pivot_df_consumers_diet = pivot_df_consumers_diet.drop(columns=['variables', 'Food supply (kcal/capita/day)', 'Proportion'])

    # Concatenating consumer diet & share
    pivot_df_diet = pd.concat([pivot_df_consumers_diet, pivot_df_share])

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Food item name matching with dictionary
    # Read excel file
    df_dict_diet = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='diet_lifestyle')

    # Merge based on 'Item'
    df_diet_pathwaycalc = pd.merge(df_dict_diet, pivot_df_diet, on='Item')

    # Drop the 'Item' column
    df_diet_pathwaycalc = df_diet_pathwaycalc.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_diet_pathwaycalc.rename(columns={'Area': 'geoscale', 'Year': 'timescale'}, inplace=True)

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_diet_pathwaycalc['module'] = 'agriculture'
    df_diet_pathwaycalc['lever'] = 'diet'
    df_diet_pathwaycalc['level'] = 0
    cols = df_diet_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_diet_pathwaycalc = df_diet_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_diet_pathwaycalc['geoscale'] = df_diet_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_diet_pathwaycalc['geoscale'] = df_diet_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                              'Netherlands')
    df_diet_pathwaycalc['geoscale'] = df_diet_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # Extrapolating
    df_diet_pathwaycalc = ensure_structure(df_diet_pathwaycalc)
    df_diet_pathwaycalc = linear_fitting_ots_db(df_diet_pathwaycalc, years_ots,
                                                                 countries='all')
    return df_diet_pathwaycalc, df_diet


# CalculationLeaf FOOD WASTE (LIFESTYLE) -----------------------------------------------------------------------------------
def food_waste_processing(df_diet):
    # Pivot the df
    pivot_df_diet = df_diet.pivot_table(index=['Area', 'Year', 'Item'], columns='Element',
                                        values='Value').reset_index()

    # Food item name matching with dictionary
    # Read excel file
    df_dict_waste = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='food-waste_lifestyle')

    # Merge based on 'Item'
    df_waste_pathwaycalc = pd.merge(df_dict_waste, pivot_df_diet, on='Item')

    # Food waste [kcal/cap/day] = food supply [kcal/cap/day] * food waste [%]
    df_waste_pathwaycalc['value'] = df_waste_pathwaycalc['Food supply (kcal/capita/day)'] * df_waste_pathwaycalc[
        'Proportion']

    # Drop the unused columns
    df_waste_pathwaycalc = df_waste_pathwaycalc.drop(columns=['Item', 'Food supply (kcal/capita/day)', 'Proportion'])

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Renaming existing columns (geoscale, timsecale, value)
    df_waste_pathwaycalc.rename(columns={'Area': 'geoscale', 'Year': 'timescale'}, inplace=True)

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_waste_pathwaycalc['module'] = 'agriculture'
    df_waste_pathwaycalc['lever'] = 'fwaste'
    df_waste_pathwaycalc['level'] = 0
    cols = df_waste_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_waste_pathwaycalc = df_waste_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_waste_pathwaycalc['geoscale'] = df_waste_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_waste_pathwaycalc['geoscale'] = df_waste_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                                'Netherlands')
    df_waste_pathwaycalc['geoscale'] = df_waste_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # Extrapolating
    df_waste_pathwaycalc = ensure_structure(df_waste_pathwaycalc)
    df_waste_pathwaycalc = linear_fitting_ots_db(df_waste_pathwaycalc, years_ots,
                                                                 countries='all')

    return df_waste_pathwaycalc

# CalculationLeaf ENERGY REQUIREMENTS -----------------------------------------------------------------------------------
def energy_requirements_processing():
    # Calorie requirements [kcal/cap/day] = BMR * PAL = ( C(age, sex) + S (age,sex) * BW(age,sex)) * PAL
    # BMR : Basal Metabolic Rate, PAL : Physical Activity Level (kept constant), BW : Body Weight
    # C constant, S Slope (depend on age and sex groups)

    # Computing average PAL of US adult non overweight
    # SOURCE : TABLE 5.10 https://openknowledge.fao.org/server/api/core/bitstreams/62ae7aeb-9536-4e43-b2d0-55120e662824/content
    men_mean_PAL = (1.75 + 1.78 + 1.84 + 1.60 + 1.61 + 1.62 + 1.17 + 1.38) / 8
    women_mean_PAL = (1.79 + 1.83 + 1.89 + 1.75 + 1.69 + 1.55 + 1.21 + 1.17) / 8
    mean_PAL = (men_mean_PAL + women_mean_PAL) / 2

    # Compute the calorie requirements per demography (age and gender)
    # PAL is constant
    # C and S come from https://pubs.acs.org/doi/10.1021/acs.est.5b05088 Table 1
    # Body Weight (constant through years) comes from https://pubs.acs.org/doi/10.1021/acs.est.5b05088 supplementary information

    # Read and format body weight
    df_body_weight = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/body_weight.xlsx',
        sheet_name='body-weight')
    df_body_weight_melted = pd.melt(
        df_body_weight,
        id_vars=['geoscale', 'sex'],  # Columns to keep
        value_vars=['age20-29', 'age30-59', 'age60-79', 'above80'],  # Columns to unpivot
        var_name='age',  # Name for the new 'age' column
        value_name='body weight'  # Name for the new 'body weight' column
    )
    df_body_weight_melted.sort_values(by=['geoscale', 'sex'], inplace=True)

    # Read and format C and S
    df_S_C = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/body_weight.xlsx',
        sheet_name='S_C')

    # Merge df based on columns age and sex
    df_kcal_req = pd.merge(
        df_body_weight_melted,
        df_S_C,
        on=['age', 'sex'],  # Columns to merge on
        how='inner'  # Merge method: 'inner' will keep only matching rows
    )
    df_kcal_req.sort_values(by=['geoscale', 'sex'], inplace=True)

    # Add the column with the constant PAL value
    df_kcal_req['PAL'] = mean_PAL

    # Compute the calorie requirements per demography (age and gender)
    df_kcal_req['Calorie requirement per demography [kcal/person/day]'] = \
        (df_kcal_req['C (kcal)'] + df_kcal_req['S (kcal/kg)'] * df_kcal_req['body weight']) * df_kcal_req['PAL']

    # Create a new column combining age and sex and merging it with the variable names
    df_kcal_req['sex_age'] = df_kcal_req['sex'] + '_' + df_kcal_req['age']
    df_kcal_req = df_kcal_req[['geoscale', 'sex_age', 'Calorie requirement per demography [kcal/person/day]']]
    df_dict_kcal = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='energy-req_lifestyle')
    df_kcal_req = pd.merge(df_dict_kcal, df_kcal_req, on='sex_age')
    df_kcal_req = df_kcal_req.drop(columns=['sex_age'])

    # Read lifestyle population
    df_population = pd.read_csv(
        '/Users/crosnier/Documents/PathwayCalc/_database/data/csv/lifestyles_population.csv', sep=';')
    # Format population
    df_population = df_population[['geoscale', 'timescale', 'eucalc-name', 'value']]
    df_population = df_population[df_population['eucalc-name'].str.contains('demography', case=False, na=False)]
    df_population.rename(columns={'value': 'population', 'eucalc-name': 'variables'}, inplace=True)
    df_population = df_population[df_population['timescale'] < 2023]

    # Merge with population based on geoscale and eucalc-name
    df_kcal_req_pathwaycalc = pd.merge(
        df_kcal_req,
        df_population,
        on=['variables', 'geoscale'],  # Columns to merge on
        how='inner'  # Merge method: 'inner' will keep only matching rows
    )

    # Multiply the kcal requirement of each group with the demography
    df_kcal_req_pathwaycalc['value'] = df_kcal_req_pathwaycalc['population'] * \
                                       df_kcal_req_pathwaycalc['Calorie requirement per demography [kcal/person/day]']
    df_kcal_req_pathwaycalc.sort_values(by=['geoscale', 'timescale'], inplace=True)

    # Filter relevant columns
    df_kcal_req_pathwaycalc = df_kcal_req_pathwaycalc[['variables', 'geoscale', 'timescale', 'value']]

    # rename correctly
    df_kcal_req_pathwaycalc['variables'] = df_kcal_req_pathwaycalc['variables'].str.replace('demography', 'kcal-req',
                                                                                            case=False)
    df_kcal_req_pathwaycalc['variables'] = df_kcal_req_pathwaycalc['variables'].str.replace('inhabitants',
                                                                                            'kcal/cap/day', case=False)

    # PathwayCalc formatting --------------------------------------------------------------------------------
    # Adding the columns module, lever, level and string-pivot at the correct places
    df_kcal_req_pathwaycalc['module'] = 'agriculture'
    df_kcal_req_pathwaycalc['lever'] = 'kcal-req'
    df_kcal_req_pathwaycalc['level'] = 0
    cols = df_kcal_req_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_kcal_req_pathwaycalc = df_kcal_req_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_kcal_req_pathwaycalc['geoscale'] = df_kcal_req_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_kcal_req_pathwaycalc['geoscale'] = df_kcal_req_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                                      'Netherlands')
    df_kcal_req_pathwaycalc['geoscale'] = df_kcal_req_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    return df_kcal_req_pathwaycalc

# CalculationLeaf SELF-SUFFICIENCY CROP & LIVESTOCK ------------------------------------------------------------------------------
def self_sufficiency_processing(years_ots):

    # Read data ------------------------------------------------------------------------------------------------------------

    # Common for all
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # FOOD BALANCE SHEETS (FBS) - For everything except molasses and cakes -------------------------------------------------
    # List of elements
    list_elements = ['Production Quantity', 'Import Quantity', 'Export Quantity', 'Feed']

    list_items = ['Cereals - Excluding Beer + (Total)', 'Fruits - Excluding Wine + (Total)', 'Oilcrops + (Total)',
                  'Pulses + (Total)', 'Rice (Milled Equivalent)',
                  'Starchy Roots + (Total)', 'Stimulants + (Total)', 'Sugar Crops + (Total)', 'Vegetables + (Total)',
                  'Demersal Fish', 'Freshwater Fish',
                  'Aquatic Animals, Others', 'Pelagic Fish', 'Beer', 'Beverages, Alcoholic', 'Beverages, Fermented',
                  'Wine', 'Sugar (Raw Equivalent)', 'Sweeteners, Other', 'Vegetable Oils + (Total)',
                  'Milk - Excluding Butter + (Total)', 'Eggs + (Total)', 'Animal fats + (Total)', 'Offals + (Total)',
                  'Bovine Meat', 'Meat, Other', 'Pigmeat',
                  'Poultry Meat', 'Mutton & Goat Meat', 'Fish, Seafood + (Total)']

    # 1990 - 2013
    ld = faostat.list_datasets()
    code = 'FBSH'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002',
                  '2003', '2004', '2005', '2006', '2007', '2008', '2009']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_ssr_1990_2013 = faostat.get_data_df(code, pars=my_pars, strval=False)
    # Renaming the elements
    df_ssr_1990_2013.loc[df_ssr_1990_2013['Element'].str.contains('Production Quantity', case=False, na=False), 'Element'] = 'Production'
    df_ssr_1990_2013.loc[
        df_ssr_1990_2013['Element'].str.contains('Import Quantity', case=False, na=False), 'Element'] = 'Import'
    df_ssr_1990_2013.loc[
        df_ssr_1990_2013['Element'].str.contains('Export Quantity', case=False, na=False), 'Element'] = 'Export'

    # 2010 - 2022
    list_elements = ['Production Quantity', 'Import quantity', 'Export quantity', 'Feed']
    # Different list becuse different in item nomination such as rice
    list_items = ['Cereals - Excluding Beer + (Total)', 'Fruits - Excluding Wine + (Total)', 'Oilcrops + (Total)',
                  'Pulses + (Total)', 'Rice and products',
                  'Starchy Roots + (Total)', 'Stimulants + (Total)', 'Sugar Crops + (Total)', 'Vegetables + (Total)',
                  'Demersal Fish', 'Freshwater Fish',
                  'Aquatic Animals, Others', 'Pelagic Fish', 'Beer', 'Beverages, Alcoholic', 'Beverages, Fermented',
                  'Wine', 'Sugar (Raw Equivalent)', 'Sweeteners, Other', 'Vegetable Oils + (Total)',
                  'Milk - Excluding Butter + (Total)', 'Eggs + (Total)', 'Animal fats + (Total)', 'Offals + (Total)',
                  'Bovine Meat', 'Meat, Other', 'Pigmeat',
                  'Poultry Meat', 'Mutton & Goat Meat', 'Fish, Seafood + (Total)']
    code = 'FBS'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_ssr_2010_2021 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Renaming the elements
    df_ssr_2010_2021.loc[
        df_ssr_2010_2021['Element'].str.contains('Production Quantity', case=False, na=False), 'Element'] = 'Production'
    df_ssr_2010_2021.loc[
        df_ssr_2010_2021['Element'].str.contains('Import quantity', case=False, na=False), 'Element'] = 'Import'
    df_ssr_2010_2021.loc[
        df_ssr_2010_2021['Element'].str.contains('Export quantity', case=False, na=False), 'Element'] = 'Export'

    # COMMODITY BALANCES (NON-FOOD) (OLD METHODOLOGY) - For molasse and cakes ----------------------------------------------
    # 1990 - 2013
    list_elements = ['Production Quantity', 'Import quantity', 'Export quantity', 'Feed']
    list_items = ['Copra Cake', 'Cottonseed Cake', 'Groundnut Cake', 'Oilseed Cakes, Other', 'Palmkernel Cake',
                  'Rape and Mustard Cake', 'Sesameseed Cake', 'Soyabean Cake', 'Sunflowerseed Cake']
    code = 'CBH'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002',
                  '2003', '2004', '2005', '2006', '2007', '2008', '2009']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_ssr_1990_2013_cake = faostat.get_data_df(code, pars=my_pars, strval=False)
    # Renaming the elements
    df_ssr_1990_2013_cake.loc[
        df_ssr_1990_2013_cake['Element'].str.contains('Production Quantity', case=False, na=False), 'Element'] = 'Production'
    df_ssr_1990_2013_cake.loc[
        df_ssr_1990_2013_cake['Element'].str.contains('Import quantity', case=False, na=False), 'Element'] = 'Import'
    df_ssr_1990_2013_cake.loc[
        df_ssr_1990_2013_cake['Element'].str.contains('Export Quantity', case=False, na=False), 'Element'] = 'Export'

    # SUPPLY UTILIZATION ACCOUNTS (SCl) - For molasse and cakes ----------------------------------------------------------
    # 2010 - 2022
    list_elements = ['Production Quantity', 'Import quantity', 'Export quantity', 'Feed']
    list_items = ['Molasses', 'Cake of  linseed', 'Cake of  soya beans', 'Cake of copra', 'Cake of cottonseed',
                  'Cake of groundnuts', 'Cake of hempseed', 'Cake of kapok', 'Cake of maize', 'Cake of mustard seed',
                  'Cake of palm kernel', 'Cake of rapeseed', 'Cake of rice bran', 'Cake of safflowerseed',
                  'Cake of sesame seed', 'Cake of sunflower seed', 'Cake, oilseeds nes', 'Cake, poppy seed',
                  'Cocoa powder and cake']
    code = 'SCL'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_ssr_2010_2021_molasse_cake = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Renaming the elements
    df_ssr_2010_2021_molasse_cake.loc[
        df_ssr_2010_2021_molasse_cake['Element'].str.contains('Production Quantity', case=False, na=False), 'Element'] = 'Production'
    df_ssr_2010_2021_molasse_cake.loc[
        df_ssr_2010_2021_molasse_cake['Element'].str.contains('Import quantity', case=False, na=False), 'Element'] = 'Import'
    df_ssr_2010_2021_molasse_cake.loc[
        df_ssr_2010_2021_molasse_cake['Element'].str.contains('Export quantity', case=False, na=False), 'Element'] = 'Export'

    # Aggregating cakes
    df_ssr_cake = pd.concat([df_ssr_1990_2013_cake, df_ssr_2010_2021_molasse_cake])
    # Filtering
    filtered_df = df_ssr_cake[df_ssr_cake['Item'].str.contains('cake', case=False)]
    # Groupby Area, Year and Element and sum the Value
    grouped_df = filtered_df.groupby(['Area', 'Element', 'Year'])['Value'].sum().reset_index()
    # Adding a column 'Item' containing 'Cakes' for all row, before the 'Value' column
    grouped_df['Item'] = 'Cakes'
    cols = grouped_df.columns.tolist()
    cols.insert(cols.index('Value'), cols.pop(cols.index('Item')))
    df_ssr_cake = grouped_df[cols]

    # Filtering for molasse
    df_ssr_molasses = df_ssr_2010_2021_molasse_cake[
        df_ssr_2010_2021_molasse_cake['Item'].str.contains('Molasses', case=False)]

    # Concatenating
    df_ssr = pd.concat([df_ssr_1990_2013, df_ssr_2010_2021])
    df_ssr = pd.concat([df_ssr, df_ssr_molasses])
    df_ssr = pd.concat([df_ssr, df_ssr_cake])

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Element', 'Item', 'Year', 'Value']
    df_ssr = df_ssr[columns_to_filter]

    # Compute Self-Sufficiency Ratio (SSR) ---------------------------------------------------------------------------------
    # SSR [%] = (100*Production) / (Production + Imports - Exports)
    # Step 1: Pivot the DataFrame to get 'Production', 'Import Quantity', and 'Export Quantity' in separate columns
    pivot_df = df_ssr.pivot_table(index=['Area', 'Year', 'Item'], columns='Element', values='Value').reset_index()

    # Create a copy for feed pre-processing and drop irrelevant columns
    df_csl_feed = pivot_df.copy()
    df_csl_feed = df_csl_feed.drop(columns=['Production', 'Import', 'Export'])

    # Step 2: Compute the SSR [%]
    pivot_df['SSR[%]'] = (pivot_df['Production']) / (
                pivot_df['Production'] + pivot_df['Import'] - pivot_df['Export'])

    # Drop the columns Production, Import Quantity and Export Quantity
    pivot_df = pivot_df.drop(columns=['Production', 'Import', 'Export', 'Feed'])

    # Extrapolate for missing data -----------------------------------------------------------------------------------------

    # Extrapolate for 2022 for everything ?

    # 'Molasses' (only 2010-2021), extrapolate for

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------

    # Food item name matching with dictionary
    # Read excel file
    df_dict_ssr = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='self-sufficiency')

    # Merge based on 'Item'
    df_ssr_pathwaycalc = pd.merge(df_dict_ssr, pivot_df, on='Item')

    # Drop the 'Item' column
    df_ssr_pathwaycalc = df_ssr_pathwaycalc.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_ssr_pathwaycalc.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'SSR[%]': 'value'}, inplace=True)

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_ssr_pathwaycalc['module'] = 'agriculture'
    df_ssr_pathwaycalc['lever'] = 'food-net-import'
    df_ssr_pathwaycalc['level'] = 0
    cols = df_ssr_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_ssr_pathwaycalc = df_ssr_pathwaycalc[cols]
    df_ssr_pathwaycalc = df_ssr_pathwaycalc.drop_duplicates()

    # Rename countries to Pathaywcalc name
    df_ssr_pathwaycalc['geoscale'] = df_ssr_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_ssr_pathwaycalc['geoscale'] = df_ssr_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                            'Netherlands')
    df_ssr_pathwaycalc['geoscale'] = df_ssr_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # Extrapolation
    df_ssr_pathwaycalc = linear_fitting_ots_db(df_ssr_pathwaycalc, years_ots, countries='all')

    return df_ssr_pathwaycalc, df_csl_feed

# CalculationLeaf CLIMATE SMART CROP ---------------------------------------------------------------------------------------------
def climate_smart_crop_processing():

    # Common for all
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']



    # ENERGY DEMAND --------------------------------------------------------------------------------------------------------

    # BIOENERGIES
    # Read excel
    df_bioenergy = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/statistiques_energie_2023.xlsx',
        sheet_name='T34b',
        skiprows = 7,
        nrows = 27
    )
    df_bioenergy = df_bioenergy[['timescale', 'Biodiesel', 'Bioéthanol / Biométhanol', "Biocarburants d'aviation", 'Huiles vég. / anim.']]

    # convert from [TJ] to [ktoe]
    tj_to_ktoe = 0.02388458966275 # source https://www.unitjuggler.com/convertir-energy-de-TJ-en-ktoe.html
    df_bioenergy.loc[:, df_bioenergy.columns != 'timescale'] *= tj_to_ktoe

    # OTHER ENERGIES
    df_oth_energy = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/statistiques_energie_2023.xlsx',
        sheet_name='T17d',
        skiprows=10,
        nrows=44
    )
    df_oth_energy = df_oth_energy[
        ['timescale', 'Energie du bois', 'Electricité', 'Gaz', 'Chaleur à distance', 'Charbon', 'Autres énergies renouvelables']]

    # Replace all occurrences of '-' with 0.0
    df_oth_energy = df_oth_energy.replace('-', 0.0)

    # Convert numeric columns to float (if necessary)
    df_oth_energy.iloc[:, 1:] = df_oth_energy.iloc[:, 1:].astype(float)

    # Keep only the years starting from 1990
    df_oth_energy = df_oth_energy[df_oth_energy["timescale"] >= 1990]

    # convert from [TJ] to [ktoe]
    tj_to_ktoe = 0.02388458966275  # source https://www.unitjuggler.com/convertir-energy-de-TJ-en-ktoe.html
    df_oth_energy.loc[:, df_oth_energy.columns != 'timescale'] *= tj_to_ktoe

    # PETROLEUM PRODUCTS
    df_petroleum = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/statistiques_energie_2023.xlsx',
        sheet_name='T20',
        skiprows=6,
        nrows=51
    )
    # convert from [kt] to [ktoe]
    kt_to_ktoe = 1.05  # https://enerteam.org/conversion-to-toe.html
    df_petroleum.loc[:, df_petroleum.columns != 'timescale'] *= kt_to_ktoe

    # BIOGAS
    df_biogas = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/statistiques_energie_2023.xlsx',
        sheet_name='T34a',
        skiprows=6,
        nrows=35
    )
    df_biogas = df_biogas[
        ['timescale', 'Biogas cons. Agr']]

    # convert from [GWh] to [ktoe]
    gwh_to_ktoe = 0.085984522785899 # source https://www.unitjuggler.com/convertir-energy-de-TJ-en-ktoe.html
    df_biogas.loc[:, df_biogas.columns != 'timescale'] *= gwh_to_ktoe

    # Merge (concat not possible due to different years)
    df_energy_demand = pd.merge(df_bioenergy, df_oth_energy, on='timescale', how='outer')
    df_energy_demand = pd.merge(df_energy_demand, df_petroleum, on='timescale', how='outer')
    df_energy_demand = pd.merge(df_energy_demand, df_biogas, on='timescale', how='outer')

    # Biodisel = huiles végétales animales + biodiesel
    df_energy_demand['Biodiesel'] = df_energy_demand['Biodiesel'] + df_energy_demand['Huiles vég. / anim.']

    # Oth energies = renouvelables energies - bioenergies considered
    df_energy_demand['Other energies'] = df_energy_demand['Autres énergies renouvelables'] -\
                                         df_energy_demand['Biodiesel'] - \
                                         df_energy_demand['Bioéthanol / Biométhanol'] - \
                                         df_energy_demand['Biogas cons. Agr']

    # Ajouter colonnes avec 0
    df_energy_demand['LPG'] = 0.0
    df_energy_demand['Other bioenergy liquids'] = 0.0

    # Pivot
    df_energy_demand = df_energy_demand.melt(
        id_vars='timescale',  # Columns to keep fixed
        var_name='Item',  # Name for the new 'item' column
        value_name='value'  # Name for the new 'value' column
    )

    # Create copy for calibration
    df_energy_demand_cal = df_energy_demand.copy()
    df_energy_demand_cal['geoscale'] = 'Switzerland'
    df_energy_demand_cal = df_energy_demand_cal.drop_duplicates()

    # convert from ktoe to ktoe/ha (divide by total agricultural area) -------------------------------------------------
    # Read FAO Values (for Switzerland)
    # List of countries
    list_countries = ['Switzerland']

    # List of elements
    list_elements = ['Area']

    list_items = ['-- Cropland', '-- Permanent meadows and pastures']

    # 1990 - 2022
    ld = faostat.list_datasets()
    code = 'RL'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_land_use = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Item', 'Year', 'Value']
    df_land_use = df_land_use[columns_to_filter]

    # Sum to get total agricultural land
    df_land_use = df_land_use.groupby(['Area', 'Year'], as_index=False)['Value'].sum()
    df_land_use = df_land_use.rename(columns={'Value': 'Agricultural land [kha]', 'Area': 'geoscale', 'Year': 'timescale'})

    # Merge and divide [kha]
    df_land_use['timescale'] = df_land_use['timescale'].astype(str)  # Convert to string
    df_energy_demand['timescale'] = df_energy_demand['timescale'].astype(str)  # Convert to string
    df_combined = pd.merge(
        df_energy_demand,
        df_land_use,
        on='timescale',
        how='inner'  # Use 'inner' to keep only matching rows
    )
    df_combined['value'] = df_combined['value'] / (df_combined['Agricultural land [kha]'] * 1000)
    # Read excel file
    df_dict_csc = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-crops')

    # Merge based on 'Item'
    df_energy_pathwaycalc = pd.merge(df_dict_csc, df_combined, on='Item')

    # Drop the 'Item' column
    df_energy_pathwaycalc = df_energy_pathwaycalc.drop(columns=['Item', 'Agricultural land [kha]'])

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_energy_pathwaycalc['module'] = 'agriculture'
    df_energy_pathwaycalc['lever'] = 'climate-smart-crop'
    df_energy_pathwaycalc['level'] = 0
    cols = df_energy_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_energy_pathwaycalc = df_energy_pathwaycalc[cols]

    # ----------------------------------------------------------------------------------------------------------------------
    # INPUT USE ------------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # NITROGEN, PHOSPHATE, POTASH ------------------------------------------------------------------------------------------

    # List of elements
    list_elements = ['Use per area of cropland']

    list_items = ['Nutrient nitrogen N (total)', 'Nutrient phosphate P2O5 (total)', 'Nutrient potash K2O (total)']
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # 1990 - 2021
    ld = faostat.list_datasets()
    code = 'RFN'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_input_nitrogen_1990_2021 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # PESTICIDES -----------------------------------------------------------------------------------------------------------

    # List of elements
    list_elements = ['Use per area of cropland']

    list_items = ['Pesticides (total) + (Total)']

    # 1990 - 2021
    code = 'RP'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_input_pesticides_1990_2021 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # LIMING, UREA ---------------------------------------------------------------------------------------------------------
    # List of elements
    list_elements = ['Agricultural Use']

    list_items = ['Urea', 'Calcium ammonium nitrate (CAN) and other mixtures with calcium carbonate']

    # Input Liming Urea 2002 - 2021
    code = 'RFB'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_input_liming_urea_1990_2021 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Area Harvested 2002 - 2021

    # List of elements
    list_elements = ['Area harvested']
    list_items = ['Cereals, primary + (Total)', 'Fibre Crops, Fibre Equivalent + (Total)', 'Fruit Primary + (Total)',
                  'Oilcrops, Oil Equivalent + (Total)', 'Pulses, Total + (Total)', 'Rice',
                  'Roots and Tubers, Total + (Total)',
                  'Sugar Crops Primary + (Total)', 'Vegetables Primary + (Total)']
    code = 'QCL'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_area_2022_2021 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Conversion from [t] in [t/ha]-----------------------------------------------------------------------------------------
    # Summming Area harvested per country and year (and element)
    df_area_total_2022_2021 = df_area_2022_2021.groupby(['Area', 'Element', 'Year'])['Value'].sum().reset_index()

    # UREA
    # Filtering and dropping columns
    df_input_urea_1990_2021 = df_input_liming_urea_1990_2021[df_input_liming_urea_1990_2021['Item'] == 'Urea']
    df_input_urea_1990_2021 = df_input_urea_1990_2021.drop(
        columns=['Domain Code', 'Domain', 'Area Code', 'Element Code',
                 'Item Code', 'Year Code', 'Unit', 'Item'])
    # Concatenate
    df_urea_area = pd.concat([df_area_total_2022_2021, df_input_urea_1990_2021])
    # Step 1: Pivot the DataFrame
    pivot_df = df_urea_area.pivot_table(index=['Area', 'Year'], columns='Element', values='Value').reset_index()
    # Step 2: Compute the input [t/ha]
    pivot_df['Input[t/ha]'] = pivot_df['Agricultural Use'] / pivot_df['Area harvested']
    # Drop the columns Yield
    pivot_df = pivot_df.drop(columns=['Agricultural Use', 'Area harvested'])
    # Adding a column Item
    pivot_df['Item'] = 'Urea'
    cols = pivot_df.columns.tolist()
    cols.insert(cols.index('Input[t/ha]'), cols.pop(cols.index('Item')))
    pivot_df = pivot_df[cols]
    pivot_df_urea = pivot_df.copy()

    # LIMING
    # Filtering and dropping columns
    df_input_liming_1990_2021 = df_input_liming_urea_1990_2021[df_input_liming_urea_1990_2021[
                                                                   'Item'] == 'Calcium ammonium nitrate (CAN) and other mixtures with calcium carbonate']
    df_input_liming_1990_2021 = df_input_liming_1990_2021.drop(
        columns=['Domain Code', 'Domain', 'Area Code', 'Element Code',
                 'Item Code', 'Year Code', 'Unit', 'Item'])
    # Concatenate
    df_liming_area = pd.concat([df_area_total_2022_2021, df_input_liming_1990_2021])
    # Step 1: Pivot the DataFrame
    pivot_df = df_liming_area.pivot_table(index=['Area', 'Year'], columns='Element', values='Value').reset_index()
    # Step 2: Compute the input [t/ha]
    pivot_df['Input[t/ha]'] = pivot_df['Agricultural Use'] / pivot_df['Area harvested']
    # Drop the columns
    pivot_df = pivot_df.drop(columns=['Agricultural Use', 'Area harvested'])
    # Adding a column Item
    pivot_df['Item'] = 'Calcium ammonium nitrate (CAN) and other mixtures with calcium carbonate'
    cols = pivot_df.columns.tolist()
    cols.insert(cols.index('Input[t/ha]'), cols.pop(cols.index('Item')))
    pivot_df = pivot_df[cols]
    pivot_df_liming = pivot_df.copy()

    # Conversion from [kg/ha] in [t/ha]-------------------------------------------------------------------------------------

    # Concatenating
    df_input_pesticides_nitrogen = pd.concat([df_input_pesticides_1990_2021, df_input_nitrogen_1990_2021])
    # Step 1: Pivot the DataFrame
    pivot_df = df_input_pesticides_nitrogen.pivot_table(index=['Area', 'Year', 'Item'], columns='Element',
                                                        values='Value').reset_index()
    # Step 2: Compute the Input [t/ha]
    pivot_df['Input[t/ha]'] = pivot_df['Use per area of cropland'] * 0.001
    # Drop the columns
    pivot_df_pesticides_nitrogen = pivot_df.drop(columns=['Use per area of cropland'])

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------

    # Concatenating
    pivot_df_input = pd.concat([pivot_df_urea, pivot_df_liming], axis=0)
    pivot_df_input = pd.concat([pivot_df_input, pivot_df_pesticides_nitrogen], axis=0)

    # Food item name matching with dictionary
    # Read excel file
    df_dict_csc = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-crops')

    # Merge based on 'Item'
    df_input_pathwaycalc = pd.merge(df_dict_csc, pivot_df_input, on='Item')

    # Drop the 'Item' column
    df_input_pathwaycalc = df_input_pathwaycalc.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_input_pathwaycalc.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Input[t/ha]': 'value'}, inplace=True)

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_input_pathwaycalc['module'] = 'agriculture'
    df_input_pathwaycalc['lever'] = 'climate-smart-crop'
    df_input_pathwaycalc['level'] = 0
    cols = df_input_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_input_pathwaycalc = df_input_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_input_pathwaycalc['geoscale'] = df_input_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_input_pathwaycalc['geoscale'] = df_input_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                                'Netherlands')
    df_input_pathwaycalc['geoscale'] = df_input_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # EF AGROFORESTRY ------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------
    # Is equal to 0 for all ots for all countries

    # Use pivot_df_input as a structural basis
    agroforestry_crop = pivot_df_input.copy()

    # Drop the column Item
    agroforestry_crop = agroforestry_crop.drop(columns=['Item', 'Input[t/ha]'])

    # Rename the column in geoscale and timescale
    agroforestry_crop.rename(columns={'Area': 'geoscale', 'Year': 'timescale'}, inplace=True)

    # Changing data type to numeric (except for the geoscale column)
    agroforestry_crop.loc[:, agroforestry_crop.columns != 'geoscale'] = agroforestry_crop.loc[:,
                                                                        agroforestry_crop.columns != 'geoscale'].apply(
        pd.to_numeric, errors='coerce')

    # Add rows to have 1990-2022
    # Generate a DataFrame with all combinations of geoscale and timescale
    geoscale_values = agroforestry_crop['geoscale'].unique()
    timescale_values = pd.Series(range(1990, 2023))

    # Create a DataFrame for the cartesian product
    cartesian_product = pd.MultiIndex.from_product([geoscale_values, timescale_values],
                                                   names=['geoscale', 'timescale']).to_frame(index=False)



    # Merge the original DataFrame with the cartesian product to include all combinations
    agroforestry_crop = pd.merge(cartesian_product, agroforestry_crop, on=['geoscale', 'timescale'], how='left')

    # Add the variables with a value of 0
    agroforestry_crop['agr_climate-smart-crop_ef_agroforestry_cover-crop[tC/ha]'] = 0
    agroforestry_crop['agr_climate-smart-crop_ef_agroforestry_cropland[tC/ha]'] = 0
    agroforestry_crop['agr_climate-smart-crop_ef_agroforestry_hedges[tC/ha]'] = 0
    agroforestry_crop['agr_climate-smart-crop_ef_agroforestry_no-till[tC/ha]'] = 0

    # Melt the df
    agroforestry_crop_pathwaycalc = pd.melt(agroforestry_crop, id_vars=['timescale', 'geoscale'],
                                           value_vars=['agr_climate-smart-crop_ef_agroforestry_cover-crop[tC/ha]',
                                                       'agr_climate-smart-crop_ef_agroforestry_cropland[tC/ha]',
                                                       'agr_climate-smart-crop_ef_agroforestry_hedges[tC/ha]',
                                                       'agr_climate-smart-crop_ef_agroforestry_no-till[tC/ha]'],
                                           var_name='variables', value_name='value')

    # PathwayCalc formatting
    agroforestry_crop_pathwaycalc['module'] = 'agriculture'
    agroforestry_crop_pathwaycalc['lever'] = 'climate-smart-crop'
    agroforestry_crop_pathwaycalc['level'] = 0
    cols = agroforestry_crop_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    cols.insert(cols.index('timescale'), cols.pop(cols.index('variables')))
    agroforestry_crop_pathwaycalc = agroforestry_crop_pathwaycalc[cols]


    # ----------------------------------------------------------------------------------------------------------------------
    # LOSSES ---------------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # FOOD BALANCE SHEETS (FBS) - For everything  -------------------------------------------------
    # List of elements
    list_elements = ['Losses', 'Production Quantity']

    list_items = ['Cereals - Excluding Beer + (Total)', 'Fruits - Excluding Wine + (Total)', 'Oilcrops + (Total)',
                  'Pulses + (Total)', 'Rice (Milled Equivalent)', 'Starchy Roots + (Total)', 'Sugar Crops + (Total)',
                  'Vegetables + (Total)', ]

    # 1990 - 2013
    code = 'FBSH'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_losses_1990_2013 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # 2010 - 2022
    # Different list because different in item nomination such as rice
    list_items = ['Cereals - Excluding Beer + (Total)', 'Fruits - Excluding Wine + (Total)', 'Oilcrops + (Total)',
                  'Pulses + (Total)', 'Rice and products', 'Starchy Roots + (Total)', 'Sugar Crops + (Total)',
                  'Vegetables + (Total)', ]
    code = 'FBS'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_losses_2010_2021 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Renanming rice to have same name with other df
    df_losses_1990_2013['Item'] = df_losses_1990_2013['Item'].replace('Rice (Milled Equivalent)', 'Rice and products')

    # Concatenating
    df_losses = pd.concat([df_losses_1990_2013, df_losses_2010_2021])

    # Compute losses ([%] of production) -----------------------------------------------------------------------------------
    # Losses [%] = 1 / (1 - Losses [1000t] / Production [1000t]) (pre processing for multiplicating the workflow)

    # Step 1: Pivot the DataFrame
    pivot_df = df_losses.pivot_table(index=['Area', 'Year', 'Item'], columns='Element', values='Value').reset_index()

    # Step 2: Compute the Losses [%] (really it's unit less)
    pivot_df['Losses[%]'] = 1 / (1 - pivot_df['Losses'] / pivot_df['Production'])

    # Drop the columns Production, Import Quantity and Export Quantity
    pivot_df = pivot_df.drop(columns=['Production', 'Losses'])

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------

    # Food item name matching with dictionary
    # Read excel file
    df_dict_csc = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-crops')

    # Merge based on 'Item'
    df_losses_pathwaycalc = pd.merge(df_dict_csc, pivot_df, on='Item')

    # Drop the 'Item' column
    df_losses_pathwaycalc = df_losses_pathwaycalc.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_losses_pathwaycalc.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Losses[%]': 'value'}, inplace=True)

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_losses_pathwaycalc['module'] = 'agriculture'
    df_losses_pathwaycalc['lever'] = 'climate-smart-crop'
    df_losses_pathwaycalc['level'] = 0
    cols = df_losses_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_losses_pathwaycalc = df_losses_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_losses_pathwaycalc['geoscale'] = df_losses_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_losses_pathwaycalc['geoscale'] = df_losses_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                                  'Netherlands')
    df_losses_pathwaycalc['geoscale'] = df_losses_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # RESIDUE SHARE --------------------------------------------------------------------------------------------------------

    # ----------------------------------------------------------------------------------------------------------------------
    # YIELD ----------------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # CROPS  (QCL) (for everything except lgn-energycrop, gas-energycrop, algae and insect)
    # List of elements
    list_elements = ['Yield']

    list_items = ['Cereals, primary + (Total)', 'Fibre Crops, Fibre Equivalent + (Total)', 'Fruit Primary + (Total)',
                  'Oilcrops, Oil Equivalent + (Total)', 'Pulses, Total + (Total)', 'Rice',
                  'Roots and Tubers, Total + (Total)',
                  'Sugar Crops Primary + (Total)', 'Vegetables Primary + (Total)']

    # 1990 - 2022
    code = 'QCL'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_yield_1990_2022 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Unit conversion from [100g/ha] to [kcal/ha]  ----------------------------------------------------------------------------

    # Pivot the DataFrame
    pivot_df = df_yield_1990_2022.pivot_table(index=['Area', 'Year', 'Item'], columns='Element',
                                              values='Value').reset_index()

    # Read excel
    df_kcal_t = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/kcal_to_t.xlsx',
        sheet_name='kcal_per_100g')
    df_kcal_g = df_kcal_t[['Item crop yield', 'kcal per 100g']]
    # Merge
    merged_df = pd.merge(
        df_kcal_g,
        pivot_df,  # Only keep the needed columns
        left_on=['Item crop yield'],
        right_on=['Item']
    )
    # Operation
    merged_df['Yield'] = merged_df['Yield'] * merged_df['kcal per 100g']
    pivot_df_yield = merged_df[['Area', 'Year', 'Item', 'Yield']]
    pivot_df_yield = pivot_df_yield.copy()

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------

    # Food item name matching with dictionary
    # Read excel file
    df_dict_csc = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-crops')

    # Merge based on 'Item'
    df_yield_pathwaycalc = pd.merge(df_dict_csc, pivot_df_yield, on='Item')

    # Drop the 'Item' column
    df_yield_pathwaycalc = df_yield_pathwaycalc.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_yield_pathwaycalc.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Yield': 'value'}, inplace=True)

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_yield_pathwaycalc['module'] = 'agriculture'
    df_yield_pathwaycalc['lever'] = 'climate-smart-crop'
    df_yield_pathwaycalc['level'] = 0
    cols = df_yield_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_yield_pathwaycalc = df_yield_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_yield_pathwaycalc['geoscale'] = df_yield_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_yield_pathwaycalc['geoscale'] = df_yield_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                                'Netherlands')
    df_yield_pathwaycalc['geoscale'] = df_yield_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # ------------------------------------------------------------------------------------------------------------------
    # YIELD ALGAE & INSECT ---------------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------------------------------------

    # Use (agroforestry_crop) as a structural basis
    yield_aps = agroforestry_crop[['timescale', 'geoscale']].copy()

    # Add the variables with values based on EuCalc for those constant
    yield_aps['agr_climate-smart-crop_yield_algae[kcal/ha]'] = 119866666.666667
    yield_aps['agr_climate-smart-crop_yield_insect[kcal/ha]'] = 675000000.0
    yield_aps['agr_climate-smart-crop_yield_lgn-energycrop[kcal/ha]'] = 77387400.0

    # Melt the df
    yield_aps_pathwaycalc = pd.melt(yield_aps, id_vars=['timescale', 'geoscale'],
                                           value_vars=['agr_climate-smart-crop_yield_algae[kcal/ha]',
                                                       'agr_climate-smart-crop_yield_insect[kcal/ha]',
                                                       'agr_climate-smart-crop_yield_lgn-energycrop[kcal/ha]'],
                                           var_name='variables', value_name='value')


    # For other value : gas-energycrop
    # Load from previous EuCalc Data
    df_yield_data = pd.read_csv(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/agriculture_climate-smart-crop_eucalc.csv',
        sep=';')

    # Filter columns
    df_filtered_columns = df_yield_data[['geoscale', 'timescale', 'eucalc-name', 'value']]

    # rename col 'eucalc-name' in 'variables'
    df_filtered_columns = df_filtered_columns.rename(columns={'eucalc-name': 'variables'})

    # Filter rows that contains biomass-mix
    df_filtered_rows = df_filtered_columns[
        df_filtered_columns['variables'].str.contains('ots_agr_climate-smart-crop_yield_gas-energycrop', case=False, na=False)
    ]

    # Rename from ots_agr to agr
    df_filtered_rows = df_filtered_rows.copy()
    df_filtered_rows['variables'] = df_filtered_rows['variables'].str.replace('ots_agr', 'agr', regex=False)


    # Concat
    yield_aps_pathwaycalc = pd.concat([yield_aps_pathwaycalc, df_filtered_rows])

    # PathwayCalc formatting --------------------------------------------------------------------------------------------
    yield_aps_pathwaycalc['module'] = 'agriculture'
    yield_aps_pathwaycalc['lever'] = 'climate-smart-crop'
    yield_aps_pathwaycalc['level'] = 0
    cols = yield_aps_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    cols.insert(cols.index('timescale'), cols.pop(cols.index('variables')))
    yield_aps_pathwaycalc = yield_aps_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    yield_aps_pathwaycalc['geoscale'] = yield_aps_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    yield_aps_pathwaycalc['geoscale'] = yield_aps_pathwaycalc['geoscale'].replace(
        'Netherlands (Kingdom of the)',
        'Netherlands')
    yield_aps_pathwaycalc['geoscale'] = yield_aps_pathwaycalc['geoscale'].replace('Czechia',
                                                                                                'Czech Republic')

    # FINAL RESULT ---------------------------------------------------------------------------------------------------------
    df_climate_smart_crop = pd.concat([df_input_pathwaycalc, df_losses_pathwaycalc])
    df_climate_smart_crop = pd.concat([df_climate_smart_crop, df_yield_pathwaycalc])
    df_climate_smart_crop = pd.concat([df_climate_smart_crop, agroforestry_crop_pathwaycalc])
    df_climate_smart_crop = pd.concat([df_climate_smart_crop, yield_aps_pathwaycalc])
    df_climate_smart_crop = pd.concat([df_climate_smart_crop, df_energy_pathwaycalc])
    df_climate_smart_crop = df_climate_smart_crop.drop_duplicates()

    # Rename countries to Pathaywcalc name
    df_climate_smart_crop['geoscale'] = df_climate_smart_crop['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_climate_smart_crop['geoscale'] = df_climate_smart_crop['geoscale'].replace(
       'Netherlands (Kingdom of the)', 'Netherlands')
    df_climate_smart_crop['geoscale'] = df_climate_smart_crop['geoscale'].replace('Czechia', 'Czech Republic')

    # Extrapolating
    df_climate_smart_crop= ensure_structure(df_climate_smart_crop)
    df_climate_smart_crop = df_climate_smart_crop.drop_duplicates()
    df_climate_smart_crop_pathwaycalc = linear_fitting_ots_db(df_climate_smart_crop, years_ots, countries='all')


    return df_climate_smart_crop_pathwaycalc, df_energy_demand_cal

# CalculationLeaf CLIMATE SMART LIVESTOCK ------------------------------------------------------------------------------
def climate_smart_livestock_processing(df_csl_feed):

    # Common for all
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # ----------------------------------------------------------------------------------------------------------------------
    # LIVESTOCK DENSITY & GRAZING INTENSITY ---------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    list_elements = ['Livestock units per agricultural land area', 'Share in total livestock']

    list_items = ['Major livestock types > (List)']

    # 1990 - 2021
    code = 'EK'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_density_1990_2021 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Renaming item as the same animal (for meat and live/producing/slaugthered animals)
    # Commenting only to consider grazing animals (cattle, buffalo, sheep, goat, horse)
    # df_density_1990_2021.loc[df_density_1990_2021['Item'].str.contains('Pig', case=False, na=False), 'Item'] = 'Pig'
    df_density_1990_2021.loc[
        df_density_1990_2021['Item'].str.contains('Cattle', case=False, na=False), 'Item'] = 'Cattle'
    df_density_1990_2021.loc[
        df_density_1990_2021['Item'].str.contains('Buffalo', case=False, na=False), 'Item'] = 'Cattle'
    # df_density_1990_2021.loc[df_density_1990_2021['Item'].str.contains('Camel', case=False, na=False), 'Item'] = 'Other non-specified'
    # df_density_1990_2021.loc[df_density_1990_2021['Item'].str.contains('Rodent', case=False, na=False), 'Item'] = 'Other non-specified'
    # df_density_1990_2021.loc[df_density_1990_2021['Item'].str.contains('Chicken', case=False, na=False), 'Item'] = 'Chicken'
    # df_density_1990_2021.loc[df_density_1990_2021['Item'].str.contains('Duck', case=False, na=False), 'Item'] = 'Duck'
    # df_density_1990_2021.loc[df_density_1990_2021['Item'].str.contains('Geese', case=False, na=False), 'Item'] = 'Goose'
    # df_density_1990_2021.loc[df_density_1990_2021['Item'].str.contains('Pigeon', case=False, na=False), 'Item'] = 'Pigeon'
    df_density_1990_2021.loc[
        df_density_1990_2021['Item'].str.contains('Horses', case=False, na=False), 'Item'] = 'Horse'
    df_density_1990_2021.loc[df_density_1990_2021['Item'].str.contains('Sheep', case=False, na=False), 'Item'] = 'Sheep'
    df_density_1990_2021.loc[df_density_1990_2021['Item'].str.contains('Goat', case=False, na=False), 'Item'] = 'Goat'
    # df_density_1990_2021.loc[df_density_1990_2021['Item'].str.contains('Rabbits and hares', case=False, na=False), 'Item'] = 'Rabbit'

    # Aggregating
    # Reading excel lsu equivalent (for aggregatop,
    df_lsu = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/lsu_equivalent.xlsx',
        sheet_name='lsu_equivalent')
    # Merging
    df_density_1990_2021 = pd.merge(df_density_1990_2021, df_lsu, on='Item')

    # Aggregating
    df_density_1990_2021 = \
    df_density_1990_2021.groupby(['Aggregation', 'Area', 'Year', 'Element', 'Unit'], as_index=False)['Value'].sum()

    # Pivot the df
    pivot_df = df_density_1990_2021.pivot_table(index=['Area', 'Year', 'Aggregation'], columns='Element',
                                                values='Value').reset_index()

    # Normalize the share of ruminants
    pivot_df['Total ruminant share [%]'] = pivot_df.groupby(['Area', 'Year'])['Share in total livestock'].transform(
        'sum')
    pivot_df['Normalized ruminant share [%]'] = pivot_df['Share in total livestock'] / pivot_df[
        'Total ruminant share [%]']

    # Multiply Livestock per ha per type [lsu/ha] with the normalized ratio
    pivot_df['Livestock area per type per share [lsu/ha]'] = pivot_df['Livestock units per agricultural land area'] * \
                                                             pivot_df['Normalized ruminant share [%]']

    # Sum
    # Livestock density [lsu/ha] = sum per year & country (Livestock area per type per share [lsu/ha])
    pivot_df['Livestock density [lsu/ha]'] = pivot_df.groupby(['Area', 'Year'])[
        'Livestock area per type per share [lsu/ha]'].transform('sum')

    # Grouping for one value per country & year
    grouped_df = pivot_df.groupby(['Year', 'Area', 'Livestock density [lsu/ha]']).size().reset_index(name='Count')
    # Drop other columns by selecting only the desired columns
    grouped_df = grouped_df[['Year', 'Area', 'Livestock density [lsu/ha]']]

    # Adding an Item column for name
    grouped_df['Item'] = 'Density'


    # PathwayCalc formatting -----------------------------------------------------------------------------------------------

    # Renaming into 'Value'
    grouped_df.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Livestock density [lsu/ha]': 'value'},
                      inplace=True)

    # Read excel file
    df_dict_csl = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-livestock')

    # Merge based on 'Item'
    df_csl_density_pathwaycalc = pd.merge(df_dict_csl, grouped_df, on='Item')

    # Drop the 'Item' column
    df_csl_density_pathwaycalc = df_csl_density_pathwaycalc.drop(columns=['Item'])

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_csl_density_pathwaycalc['module'] = 'agriculture'
    df_csl_density_pathwaycalc['lever'] = 'climate-smart-livestock'
    df_csl_density_pathwaycalc['level'] = 0
    cols = df_csl_density_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_csl_density_pathwaycalc = df_csl_density_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_csl_density_pathwaycalc['geoscale'] = df_csl_density_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_csl_density_pathwaycalc['geoscale'] = df_csl_density_pathwaycalc['geoscale'].replace(
        'Netherlands (Kingdom of the)',
        'Netherlands')
    df_csl_density_pathwaycalc['geoscale'] = df_csl_density_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # AGROFORESTRY (GRASSLAND & HEDGES) ------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------
    # Is equal to 0 for all ots for all countries

    # Use density (grouped_df) as a structural basis
    agroforestry_liv = grouped_df.copy()

    # Drop the column Item
    agroforestry_liv = agroforestry_liv.drop(columns=['Item', 'value'])

    # Rename the column in geoscale and timescale
    agroforestry_liv.rename(columns={'Area': 'geoscale', 'Year': 'timescale'}, inplace=True)

    # Changing data type to numeric (except for the geoscale column)
    agroforestry_liv.loc[:, agroforestry_liv.columns != 'geoscale'] = agroforestry_liv.loc[:,
                                                                        agroforestry_liv.columns != 'geoscale'].apply(
        pd.to_numeric, errors='coerce')

    # Add rows to have 1990-2022
    # Generate a DataFrame with all combinations of geoscale and timescale
    geoscale_values = agroforestry_liv['geoscale'].unique()
    timescale_values = pd.Series(range(1990, 2023))

    # Create a DataFrame for the cartesian product
    cartesian_product = pd.MultiIndex.from_product([geoscale_values, timescale_values],
                                                   names=['geoscale', 'timescale']).to_frame(index=False)

    # Merge the original DataFrame with the cartesian product to include all combinations
    agroforestry_liv = pd.merge(cartesian_product, agroforestry_liv, on=['geoscale', 'timescale'], how='left')

    # Add the variables with a value of 0
    agroforestry_liv['agr_climate-smart-livestock_ef_agroforestry_grassland[tC/ha]'] = 0
    agroforestry_liv['agr_climate-smart-livestock_ef_agroforestry_hedges[tC/ha]'] = 0

    # Melt the df
    agroforestry_liv_pathwaycalc = pd.melt(agroforestry_liv, id_vars=['timescale', 'geoscale'],
                    value_vars=['agr_climate-smart-livestock_ef_agroforestry_grassland[tC/ha]', 'agr_climate-smart-livestock_ef_agroforestry_hedges[tC/ha]'],
                    var_name='variables', value_name='value')

    # PathwayCalc formatting --------------------------------------------------------------------------------------------
    agroforestry_liv_pathwaycalc['module'] = 'agriculture'
    agroforestry_liv_pathwaycalc['lever'] = 'climate-smart-livestock'
    agroforestry_liv_pathwaycalc['level'] = 0
    cols = agroforestry_liv_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    cols.insert(cols.index('timescale'), cols.pop(cols.index('variables')))
    agroforestry_liv_pathwaycalc = agroforestry_liv_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    agroforestry_liv_pathwaycalc['geoscale'] = agroforestry_liv_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    agroforestry_liv_pathwaycalc['geoscale'] = agroforestry_liv_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                                  'Netherlands')
    agroforestry_liv_pathwaycalc['geoscale'] = agroforestry_liv_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # ENTERIC EMISSIONS ----------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------
    list_elements = ['Enteric fermentation (Emissions CH4)', 'Stocks']

    list_items = ['All Animals > (List)']

    # 1990 - 2021
    code = 'GLE'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_enteric_1990_2021 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Renaming item as the same animal (for meat and live/producing/slaugthered animals)
    df_enteric_1990_2021.loc[
        df_enteric_1990_2021['Item'].str.contains('Cattle, dairy', case=False, na=False), 'Item'] = 'Dairy cows'
    df_enteric_1990_2021.loc[
        df_enteric_1990_2021['Item'].str.contains('Cattle, non-dairy', case=False, na=False), 'Item'] = 'Cattle'
    df_enteric_1990_2021.loc[df_enteric_1990_2021['Item'].str.contains('Goat', case=False, na=False), 'Item'] = 'Goat'
    df_enteric_1990_2021.loc[
        df_enteric_1990_2021['Item'].str.contains('Chickens, broilers', case=False, na=False), 'Item'] = 'Chicken'
    df_enteric_1990_2021.loc[df_enteric_1990_2021['Item'].str.contains('Chickens, layers', case=False,
                                                                       na=False), 'Item'] = 'Chicken laying hens'
    df_enteric_1990_2021.loc[df_enteric_1990_2021['Item'].str.contains('Duck', case=False, na=False), 'Item'] = 'Duck'
    df_enteric_1990_2021.loc[df_enteric_1990_2021['Item'].str.contains('Horse', case=False, na=False), 'Item'] = 'Horse'
    df_enteric_1990_2021.loc[df_enteric_1990_2021['Item'].str.contains('Sheep', case=False, na=False), 'Item'] = 'Sheep'
    df_enteric_1990_2021.loc[df_enteric_1990_2021['Item'].str.contains('Swine', case=False, na=False), 'Item'] = 'Pig'
    df_enteric_1990_2021.loc[
        df_enteric_1990_2021['Item'].str.contains('Turkey', case=False, na=False), 'Item'] = 'Turkey'
    df_enteric_1990_2021.loc[df_enteric_1990_2021['Item'].str.contains('Asse', case=False, na=False), 'Item'] = 'Asse'
    df_enteric_1990_2021.loc[
        df_enteric_1990_2021['Item'].str.contains('Buffalo', case=False, na=False), 'Item'] = 'Buffalo'
    df_enteric_1990_2021.loc[df_enteric_1990_2021['Item'].str.contains('Mule', case=False, na=False), 'Item'] = 'Mule'
    df_enteric_1990_2021.loc[
        df_enteric_1990_2021['Item'].str.contains('Camel', case=False, na=False), 'Item'] = 'Other non-specified'

    # Reading excel lsu equivalent
    df_lsu = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/lsu_equivalent.xlsx',
        sheet_name='lsu_equivalent')
    # Merging
    df_enteric_1990_2021 = pd.merge(df_enteric_1990_2021, df_lsu, on='Item')

    # Converting Animals to lsu
    condition = df_enteric_1990_2021['Unit'] == 'An'
    df_enteric_1990_2021.loc[condition, 'Value'] *= df_enteric_1990_2021['lsu']

    # Aggregating
    df_enteric_1990_2021_grouped = \
    df_enteric_1990_2021.groupby(['Aggregation', 'Area', 'Year', 'Element', 'Unit'], as_index=False)['Value'].sum()

    # Pivot the df
    pivot_df = df_enteric_1990_2021_grouped.pivot_table(index=['Area', 'Year', 'Aggregation'], columns='Element',
                                                        values='Value').reset_index()

    # Enteric emissions CH4 [t/lsu] = 1000 * 'Enteric fermentation (Emissions CH4) [kt]'/ 'Stocks [lsu]'
    pivot_df['Enteric emissions CH4 [t/lsu]'] = 1000 * pivot_df['Enteric fermentation (Emissions CH4)'] / pivot_df[
        'Stocks']

    # Drop the columns 'Enteric fermentation (Emissions CH4)' 'Stocks'
    pivot_df = pivot_df.drop(columns=['Enteric fermentation (Emissions CH4)', 'Stocks'])

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------

    # Renaming into 'Value'
    pivot_df.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Enteric emissions CH4 [t/lsu]': 'value'},
                    inplace=True)

    # Food item name matching with dictionary
    # Read excel file
    df_dict_csl_enteric = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-livestock_enteric')

    # Merge based on 'Item' & 'Aggregation'
    df_enteric_pathwaycalc = pd.merge(df_dict_csl_enteric, pivot_df, left_on='Item', right_on='Aggregation')

    # Drop the 'Item' column
    df_enteric_pathwaycalc = df_enteric_pathwaycalc.drop(columns=['Item', 'Aggregation'])

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_enteric_pathwaycalc['module'] = 'agriculture'
    df_enteric_pathwaycalc['lever'] = 'climate-smart-livestock'
    df_enteric_pathwaycalc['level'] = 0
    cols = df_enteric_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_enteric_pathwaycalc = df_enteric_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_enteric_pathwaycalc['geoscale'] = df_enteric_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_enteric_pathwaycalc['geoscale'] = df_enteric_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                                    'Netherlands')
    df_enteric_pathwaycalc['geoscale'] = df_enteric_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # MANURE EMISSIONS (APPLIED, PASTURE & TREATED) ------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------
    list_elements = ['Amount excreted in manure (N content)', 'Manure left on pasture (N content)',
                     'Manure applied to soils (N content)', 'Losses from manure treated (N content)']

    list_items = ['All Animals > (List)']

    # 1990 - 2021
    code = 'EMN'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_manure_1990_2021 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Renaming item as the same animal
    df_manure_1990_2021.loc[
        df_manure_1990_2021['Item'].str.contains('Cattle, dairy', case=False, na=False), 'Item'] = 'Dairy cows'
    df_manure_1990_2021.loc[
        df_manure_1990_2021['Item'].str.contains('Cattle, non-dairy', case=False, na=False), 'Item'] = 'Cattle'
    df_manure_1990_2021.loc[df_manure_1990_2021['Item'].str.contains('Goat', case=False, na=False), 'Item'] = 'Goat'
    df_manure_1990_2021.loc[
        df_manure_1990_2021['Item'].str.contains('Chickens, broilers', case=False, na=False), 'Item'] = 'Chicken'
    df_manure_1990_2021.loc[df_manure_1990_2021['Item'].str.contains('Chickens, layers', case=False,
                                                                     na=False), 'Item'] = 'Chicken laying hens'
    df_manure_1990_2021.loc[df_manure_1990_2021['Item'].str.contains('Duck', case=False, na=False), 'Item'] = 'Duck'
    df_manure_1990_2021.loc[df_manure_1990_2021['Item'].str.contains('Horse', case=False, na=False), 'Item'] = 'Horse'
    df_manure_1990_2021.loc[df_manure_1990_2021['Item'].str.contains('Sheep', case=False, na=False), 'Item'] = 'Sheep'
    df_manure_1990_2021.loc[df_manure_1990_2021['Item'].str.contains('Swine', case=False, na=False), 'Item'] = 'Pig'
    df_manure_1990_2021.loc[df_manure_1990_2021['Item'].str.contains('Turkey', case=False, na=False), 'Item'] = 'Turkey'
    df_manure_1990_2021.loc[df_manure_1990_2021['Item'].str.contains('Asse', case=False, na=False), 'Item'] = 'Asse'
    df_manure_1990_2021.loc[
        df_manure_1990_2021['Item'].str.contains('Buffalo', case=False, na=False), 'Item'] = 'Buffalo'
    df_manure_1990_2021.loc[df_manure_1990_2021['Item'].str.contains('Mule', case=False, na=False), 'Item'] = 'Mule'
    df_manure_1990_2021.loc[
        df_manure_1990_2021['Item'].str.contains('Camel', case=False, na=False), 'Item'] = 'Other non-specified'

    # Reading excel lsu equivalent (for aggregatop,
    df_lsu = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/lsu_equivalent.xlsx',
        sheet_name='lsu_equivalent')
    # Merging
    df_manure_1990_2021 = pd.merge(df_manure_1990_2021, df_lsu, on='Item')

    # Aggregating
    df_manure_1990_2021 = \
    df_manure_1990_2021.groupby(['Aggregation', 'Area', 'Year', 'Element', 'Unit'], as_index=False)['Value'].sum()

    # Pivot the df
    pivot_df = df_manure_1990_2021.pivot_table(index=['Area', 'Year', 'Aggregation'], columns='Element',
                                               values='Value').reset_index()

    # Manure applied/treated/pasture [%] = Manure applied to soil/treated/left on pasture (N content) [kg] / Amount excreted (N content) [kg]

    pivot_df['Manure applied [%]'] = pivot_df['Manure applied to soils (N content)'] / pivot_df[
        'Amount excreted in manure (N content)']
    pivot_df['Manure treated [%]'] = pivot_df['Losses from manure treated (N content)'] / pivot_df[
        'Amount excreted in manure (N content)']
    pivot_df['Manure pasture [%]'] = pivot_df['Manure left on pasture (N content)'] / pivot_df[
        'Amount excreted in manure (N content)']

    # Drop the columns
    pivot_df = pivot_df.drop(columns=['Manure applied to soils (N content)', 'Losses from manure treated (N content)',
                                      'Manure left on pasture (N content)', 'Amount excreted in manure (N content)'])

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------

    # Melt the DataFrame
    df_melted = pd.melt(pivot_df, id_vars=['Area', 'Year', 'Aggregation'],
                        value_vars=['Manure applied [%]', 'Manure treated [%]', 'Manure pasture [%]'],
                        var_name='Item', value_name='value')

    # Concatenate the aggregation column with the manure column names
    df_melted['Item'] = df_melted['Aggregation'] + ' ' + df_melted['Item']

    # Drop the aggregation column as it's now part of the item column
    df_melted = df_melted.drop(columns=['Aggregation'])

    # Renaming
    df_melted.rename(columns={'Area': 'geoscale', 'Year': 'timescale'}, inplace=True)

    # Food item name matching with dictionary
    # Read excel file
    df_dict_csl = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-livestock')

    # Merge based on 'Item' & 'Aggregation'
    df_manure_pathwaycalc = pd.merge(df_dict_csl, df_melted, on='Item')

    # Drop the 'Item' column
    df_manure_pathwaycalc = df_manure_pathwaycalc.drop(columns=['Item'])

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_manure_pathwaycalc['module'] = 'agriculture'
    df_manure_pathwaycalc['lever'] = 'climate-smart-livestock'
    df_manure_pathwaycalc['level'] = 0
    cols = df_manure_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_manure_pathwaycalc = df_manure_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_manure_pathwaycalc['geoscale'] = df_manure_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_manure_pathwaycalc['geoscale'] = df_manure_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                                  'Netherlands')
    df_manure_pathwaycalc['geoscale'] = df_manure_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # LOSSES ---------------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # FOOD BALANCE SHEETS (FBS) - For everything  -------------------------------------------------
    # List of elements
    list_elements = ['Losses', 'Production Quantity']

    list_items = ['Animal Products > (List)']

    # 1990 - 2013
    code = 'FBSH'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_losses_csl_1990_2013 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Renaming Elements
    df_losses_csl_1990_2013.loc[df_losses_csl_1990_2013['Element'].str.contains('Production Quantity',
                                                                                case=False,
                                                                                na=False), 'Element'] = 'Production'

    # 2010 - 2022
    # Different list because different in item nomination such as rice
    list_elements = ['Losses', 'Production Quantity']
    code = 'FBS'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_losses_csl_2010_2021 = faostat.get_data_df(code, pars=my_pars, strval=False)
    # Renaming Elements
    df_losses_csl_2010_2021.loc[df_losses_csl_2010_2021['Element'].str.contains('Production Quantity',
                                                                                case=False,
                                                                                na=False), 'Element'] = 'Production'

    # Concatenating
    df_losses_csl = pd.concat([df_losses_csl_1990_2013, df_losses_csl_2010_2021])

    # Compute losses ([%] of production) -----------------------------------------------------------------------------------
    # Losses [%] = 1 / (1 - Losses [1000t] / Production [1000t]) (pre processing for multiplicating the workflow)

    # Step 1: Pivot the DataFrame
    pivot_df = df_losses_csl.pivot_table(index=['Area', 'Year', 'Item'], columns='Element',
                                         values='Value').reset_index()

    # Step 2: Compute the Losses [%] (really it's unit less)
    pivot_df['Losses[%]'] = 1 / (1 - pivot_df['Losses'] / pivot_df['Production'])

    # Drop the columns Production, Import Quantity and Export Quantity
    pivot_df = pivot_df.drop(columns=['Production', 'Losses'])

    # Extrapolating for 2022 -----------------------------------------------------------------------------------------------

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------

    # Food item name matching with dictionary
    # Read excel file
    df_dict_csl_losses = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-livestock_losses')

    # Merge based on 'Item'
    df_losses_csl_pathwaycalc = pd.merge(df_dict_csl_losses, pivot_df, on='Item')

    # Drop the 'Item' column
    df_losses_csl_pathwaycalc = df_losses_csl_pathwaycalc.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_losses_csl_pathwaycalc.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Losses[%]': 'value'},
                                     inplace=True)

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_losses_csl_pathwaycalc['module'] = 'agriculture'
    df_losses_csl_pathwaycalc['lever'] = 'climate-smart-livestock'
    df_losses_csl_pathwaycalc['level'] = 0
    cols = df_losses_csl_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_losses_csl_pathwaycalc = df_losses_csl_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_losses_csl_pathwaycalc['geoscale'] = df_losses_csl_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_losses_csl_pathwaycalc['geoscale'] = df_losses_csl_pathwaycalc['geoscale'].replace(
        'Netherlands (Kingdom of the)',
        'Netherlands')
    df_losses_csl_pathwaycalc['geoscale'] = df_losses_csl_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # FEED RATION ----------------------------------------------------------------------------------------------------------
    # ---------------------------------------------------------------------------------------------------------------------
    # Fill nan with zeros
    df_csl_feed['Feed'].fillna(0, inplace=True)

    # Add a column with the total feed (per country and year)
    df_csl_feed['Total feed'] = df_csl_feed.groupby(['Area', 'Year'])['Feed'].transform('sum')

    # Feed ration [%] = Feed from item i / Total feed
    df_csl_feed['Feed ratio'] = df_csl_feed['Feed'] / df_csl_feed['Total feed']

    # Drop columns
    df_csl_feed = df_csl_feed.drop(columns=['Feed', 'Total feed'])

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------

    # Renaming into 'Value'
    df_csl_feed.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Feed ratio': 'value'}, inplace=True)

    # Read excel file
    df_dict_csl = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-livestock')

    # Merge based on 'Item'
    df_csl_feed_pathwaycalc = pd.merge(df_dict_csl, df_csl_feed, on='Item')

    # Drop the 'Item' column
    df_csl_feed_pathwaycalc = df_csl_feed_pathwaycalc.drop(columns=['Item'])

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_csl_feed_pathwaycalc['module'] = 'agriculture'
    df_csl_feed_pathwaycalc['lever'] = 'climate-smart-livestock'
    df_csl_feed_pathwaycalc['level'] = 0
    cols = df_csl_feed_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_csl_feed_pathwaycalc = df_csl_feed_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_csl_feed_pathwaycalc['geoscale'] = df_csl_feed_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_csl_feed_pathwaycalc['geoscale'] = df_csl_feed_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                                      'Netherlands')
    df_csl_feed_pathwaycalc['geoscale'] = df_csl_feed_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # SLAUGHTERED LIVESTOCK  & YIELD (DAIRY & EGGS) ------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    list_elements = ['Producing Animals/Slaughtered', 'Production Quantity']

    list_items = ['Milk, Total > (List)', 'Eggs Primary > (List)']

    # 1990 - 2022
    code = 'QCL'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_producing_animals_1990_2022 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Drop the rows where Production is not in Nb of Eggs
    df_producing_animals_1990_2022 = df_producing_animals_1990_2022[df_producing_animals_1990_2022['Unit'] != '1000 No']

    # Renaming item as the same animal (for meat and live/producing/slaugthered animals)
    df_producing_animals_1990_2022.loc[
        df_producing_animals_1990_2022['Item'].str.contains('Cattle', case=False, na=False), 'Item'] = 'Dairy cows'
    df_producing_animals_1990_2022.loc[
        df_producing_animals_1990_2022['Item'].str.contains('Sheep', case=False, na=False), 'Item'] = 'Dairy sheep'
    df_producing_animals_1990_2022.loc[
        df_producing_animals_1990_2022['Item'].str.contains('Goat', case=False, na=False), 'Item'] = 'Dairy goat'
    df_producing_animals_1990_2022.loc[
        df_producing_animals_1990_2022['Item'].str.contains('Buffalo', case=False, na=False), 'Item'] = 'Dairy buffalo'
    df_producing_animals_1990_2022.loc[df_producing_animals_1990_2022['Item'].str.contains('Hen eggs', case=False,
                                                                                           na=False), 'Item'] = 'Chicken laying hens'
    df_producing_animals_1990_2022.loc[
        df_producing_animals_1990_2022['Item'].str.contains('Eggs from other birds', case=False,
                                                            na=False), 'Item'] = 'Other laying hens'

    # Unit conversion Poultry : [1000 An] => [An]
    df_producing_animals_1990_2022.loc[df_producing_animals_1990_2022['Unit'] == '1000 An', 'Value'] *= 1000

    # Reading excel lsu equivalent
    df_lsu = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/lsu_equivalent.xlsx',
        sheet_name='lsu_equivalent')
    # Merging
    df_producing_animals_1990_2022 = pd.merge(df_producing_animals_1990_2022, df_lsu, on='Item')

    # Converting Animals to lsu
    condition = (df_producing_animals_1990_2022['Unit'] == 'An') | (df_producing_animals_1990_2022['Unit'] == '1000 An')
    df_producing_animals_1990_2022.loc[condition, 'Value'] *= df_producing_animals_1990_2022['lsu']

    # Aggregating
    grouped_df = \
    df_producing_animals_1990_2022.groupby(['Aggregation', 'Area', 'Year', 'Element', 'Unit'], as_index=False)[
        'Value'].sum()

    # Pivot the df
    pivot_df = grouped_df.pivot_table(index=['Area', 'Year', 'Aggregation'], columns='Element',
                                      values='Value').reset_index()

    # "Merging" the columns 'Laying' and 'Milk Animals' into 'Producing Animals'
    # Replace NaN with 0
    pivot_df['Laying'].fillna(0, inplace=True)
    pivot_df['Milk Animals'].fillna(0, inplace=True)

    # Sum the columns to create the 'Producing Animals' column
    pivot_df['Producing Animals'] = pivot_df['Laying'] + pivot_df['Milk Animals']

    # Yield [t/lsu] = Production quantity / Producing animals/Slaugthered
    pivot_df['Yield [t/lsu]'] = pivot_df['Production'] / pivot_df['Producing Animals']

    # Drop the columns Yield
    pivot_df = pivot_df.drop(columns=['Laying', 'Milk Animals', 'Production', 'Producing Animals'])

    # ----------------------------------------------------------------------------------------------------------------------
    # SLAUGHTERED LIVESTOCK  & YIELD (MEAT) --------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------
    list_elements = ['Producing Animals/Slaughtered', 'Stocks', 'Production Quantity']

    list_items = ['Meat, Total > (List)', 'Live Animals > (List)']

    # 1990 - 2022
    code = 'QCL'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_slaughtered_1990_2022 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Dropping 'Bees'
    df_slaughtered_1990_2022 = df_slaughtered_1990_2022[df_slaughtered_1990_2022['Item'] != 'Bees']

    # Renaming item as the same animal (for meat and live/producing/slaugthered animals)
    df_slaughtered_1990_2022.loc[
        df_slaughtered_1990_2022['Item'].str.contains('Pig', case=False, na=False), 'Item'] = 'Pig'
    df_slaughtered_1990_2022.loc[
        df_slaughtered_1990_2022['Item'].str.contains('Cattle', case=False, na=False), 'Item'] = 'Cattle'
    df_slaughtered_1990_2022.loc[
        df_slaughtered_1990_2022['Item'].str.contains('Buffalo', case=False, na=False), 'Item'] = 'Cattle'
    df_slaughtered_1990_2022.loc[
        df_slaughtered_1990_2022['Item'].str.contains('Camel', case=False, na=False), 'Item'] = 'Other non-specified'
    df_slaughtered_1990_2022.loc[
        df_slaughtered_1990_2022['Item'].str.contains('Rodent', case=False, na=False), 'Item'] = 'Other non-specified'
    df_slaughtered_1990_2022.loc[
        df_slaughtered_1990_2022['Item'].str.contains('Chicken', case=False, na=False), 'Item'] = 'Chicken'
    df_slaughtered_1990_2022.loc[
        df_slaughtered_1990_2022['Item'].str.contains('Duck', case=False, na=False), 'Item'] = 'Duck'
    df_slaughtered_1990_2022.loc[
        df_slaughtered_1990_2022['Item'].str.contains('Geese', case=False, na=False), 'Item'] = 'Goose'
    df_slaughtered_1990_2022.loc[
        df_slaughtered_1990_2022['Item'].str.contains('Pigeon', case=False, na=False), 'Item'] = 'Pigeon'
    df_slaughtered_1990_2022.loc[
        df_slaughtered_1990_2022['Item'].str.contains('Horses', case=False, na=False), 'Item'] = 'Horse'
    df_slaughtered_1990_2022.loc[
        df_slaughtered_1990_2022['Item'].str.contains('Rabbits and hares', case=False, na=False), 'Item'] = 'Rabbit'

    # Unit conversion Poultry : [1000 An] => [An]
    df_slaughtered_1990_2022.loc[df_slaughtered_1990_2022['Unit'] == '1000 An', 'Value'] *= 1000

    # Reading excel lsu equivalent
    df_lsu = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/lsu_equivalent.xlsx',
        sheet_name='lsu_equivalent')
    # Merging
    df_slaughtered_1990_2022 = pd.merge(df_slaughtered_1990_2022, df_lsu, on='Item')

    # Converting Animals to lsu
    condition = (df_slaughtered_1990_2022['Unit'] == 'An') | (df_slaughtered_1990_2022['Unit'] == '1000 An')
    df_slaughtered_1990_2022.loc[condition, 'Value'] *= df_slaughtered_1990_2022['lsu']

    # Aggregating
    grouped_df = df_slaughtered_1990_2022.groupby(['Aggregation', 'Area', 'Year', 'Element', 'Unit'], as_index=False)[
        'Value'].sum()

    # Pivot the df
    pivot_df_slau = grouped_df.pivot_table(index=['Area', 'Year', 'Aggregation'], columns='Element',
                                           values='Value').reset_index()

    # Replace NaN with 0
    pivot_df_slau['Producing Animals/Slaughtered'].fillna(0, inplace=True)
    pivot_df_slau['Production'].fillna(0, inplace=True)

    # Slaughtered animals [%] = 'Producing Animals/Slaughtered' / 'Stocks'
    pivot_df_slau['Slaughtered animals [%]'] = pivot_df_slau['Producing Animals/Slaughtered'] / pivot_df_slau['Stocks']

    # Yield [t/lsu] = Production quantity / Producing animals/Slaugthered
    pivot_df_slau['Yield [t/lsu]'] = pivot_df_slau['Production'] / pivot_df_slau['Producing Animals/Slaughtered']

    # Drop the columns
    pivot_df_slau = pivot_df_slau.drop(columns=['Producing Animals/Slaughtered', 'Stocks', 'Production'])

    # Replace NaN with 0
    pivot_df_slau['Yield [t/lsu]'].fillna(0, inplace=True)
    pivot_df_slau['Slaughtered animals [%]'].fillna(0, inplace=True)

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------

    # Separating between slaugthered animals and yield (for meat)
    df_yield_meat = pivot_df_slau[['Area', 'Year', 'Aggregation', 'Yield [t/lsu]']]
    df_slau_meat = pivot_df_slau[['Area', 'Year', 'Aggregation', 'Slaughtered animals [%]']]

    # Creating copies
    df_yield_meat = df_yield_meat.copy()
    df_slau_meat = df_slau_meat.copy()

    # Renaming into 'Value'
    df_yield_meat.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Yield [t/lsu]': 'value'}, inplace=True)
    pivot_df.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Yield [t/lsu]': 'value'}, inplace=True)
    df_slau_meat.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Slaughtered animals [%]': 'value'},
                        inplace=True)

    # Concatenating yield (meat, milk & eggs)
    df_yield_liv = pd.concat([df_yield_meat, pivot_df])

    # Read excel
    df_kcal_t = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/kcal_to_t.xlsx',
        sheet_name='kcal_per_100g')
    df_kcal_g = df_kcal_t[['Item livestock yield', 'kcal per t']]
    # Merge
    merged_df = pd.merge(
        df_kcal_g,
        df_yield_liv,  # Only keep the needed columns
        left_on=['Item livestock yield'],
    right_on=['Aggregation']
    )
    # Operation
    merged_df['value'] = merged_df['value'] * merged_df['kcal per t']
    df_yield_liv = merged_df[['geoscale', 'timescale', 'Aggregation', 'value']]
    df_yield_liv = df_yield_liv.copy()

    # Food item name matching with dictionary
    # Read excel file
    df_dict_csl_yield = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-livestock_yield')
    df_dict_csl_slau = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-livestock_slau')

    # Merge based on 'Item'
    df_yield_liv_pathwaycalc = pd.merge(df_dict_csl_yield, df_yield_liv, left_on='Item', right_on='Aggregation')
    df_slau_liv_pathwaycalc = pd.merge(df_dict_csl_slau, df_slau_meat, left_on='Item', right_on='Aggregation')

    # Drop the 'Item' column
    df_yield_liv_pathwaycalc = df_yield_liv_pathwaycalc.drop(columns=['Item', 'Aggregation'])
    df_slau_liv_pathwaycalc = df_slau_liv_pathwaycalc.drop(columns=['Item', 'Aggregation'])

    # Concatenating yield and slau
    df_yield_slau_liv_pathwaycalc = pd.concat([df_yield_liv_pathwaycalc, df_slau_liv_pathwaycalc])

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_yield_slau_liv_pathwaycalc['module'] = 'agriculture'
    df_yield_slau_liv_pathwaycalc['lever'] = 'climate-smart-livestock'
    df_yield_slau_liv_pathwaycalc['level'] = 0
    cols = df_yield_slau_liv_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_yield_pathwaycalc = df_yield_slau_liv_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_yield_slau_liv_pathwaycalc['geoscale'] = df_yield_slau_liv_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_yield_slau_liv_pathwaycalc['geoscale'] = df_yield_slau_liv_pathwaycalc['geoscale'].replace(
        'Netherlands (Kingdom of the)',
        'Netherlands')
    df_yield_slau_liv_pathwaycalc['geoscale'] = df_yield_slau_liv_pathwaycalc['geoscale'].replace('Czechia',
                                                                                                  'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # FINAL RESULTS --------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    df_csl = pd.concat([df_csl_density_pathwaycalc, df_enteric_pathwaycalc])
    df_csl = pd.concat([df_csl, df_manure_pathwaycalc])
    df_csl = pd.concat([df_csl, df_losses_csl_pathwaycalc])
    df_csl = pd.concat([df_csl, df_csl_feed_pathwaycalc])
    df_csl = pd.concat([df_csl, df_yield_slau_liv_pathwaycalc])
    df_csl = pd.concat([df_csl, agroforestry_liv_pathwaycalc])
    df_csl = df_csl.drop_duplicates()

    # Extrapolating
    df_climate_smart_livestock_pathwaycalc = ensure_structure(df_csl)
    df_climate_smart_livestock_pathwaycalc = linear_fitting_ots_db(df_climate_smart_livestock_pathwaycalc, years_ots, countries='all')


    return df_climate_smart_livestock_pathwaycalc

# CalculationLeaf CLIMATE SMART FORESTRY -------------------------------------------------------------------------------
def climate_smart_forestry_processing():

    # ----------------------------------------------------------------------------------------------------------------------
    # INCREMENTAL GROWTH [m3/ha] -------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Read csv
    df_g_inc = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/data_forestry.xlsx',
        sheet_name='annual_ginc_per_area_m3ha')

    # Read and format forest area for later
    df_area = pd.read_csv(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/fra-extentOfForest.csv')
    df_area.columns = df_area.iloc[0]
    df_area = df_area[1:]
    # Rename column name 'geoscale'
    df_area.rename(columns={df_area.columns[0]: 'geoscale'}, inplace=True)

    # Format correctly
    # Melting the dfs to have the relevant format (geoscale, year, value)
    df_g_inc = pd.melt(df_g_inc, id_vars=['geoscale'], var_name='timescale', value_name='value')
    df_area = pd.melt(df_area, id_vars=['geoscale'], var_name='timescale', value_name='forest area [ha]')
    # Changing data type to numeric (except for the geoscale column)
    df_g_inc.loc[:, df_g_inc.columns != 'geoscale'] = df_g_inc.loc[:, df_g_inc.columns != 'geoscale'].apply(
        pd.to_numeric, errors='coerce')
    # Merge the dfs (growing stock and area) to filter the relevant countries
    df_g_inc_area = pd.merge(df_g_inc, df_area, on=['geoscale', 'timescale'])
    # Only keep the columns geoscale, timescale and value
    df_g_inc_area = df_g_inc_area[['geoscale', 'timescale', 'value']]
    df_g_inc_area_pathwaycalc = df_g_inc_area.copy()

    # DEPRECIATED Compute the incremental difference -----------------------------------------------------------------------------------
    # Ensure the DataFrame is sorted by geoscale and timescale
    # df_g_inc.sort_values(by=['geoscale', 'timescale'], inplace=True)

    # Compute the incremental growing stock for each country : incremental growing stock [m3] = growing stock y(i) - growing stock y(i-1)
    # df_g_inc['incremental growing stock [m3/ha]'] = df_g_inc.groupby('geoscale')['growing stock [m3/ha]'].diff()

    # Calculate the number of years between each period
    # df_g_inc['years_diff'] = df_g_inc.groupby('geoscale')['timescale'].diff()

    # Calculate the annual increment by dividing the incremental growing stock by the number of years
    # df_g_inc['annual increment [m3/ha/yr]'] = df_g_inc['incremental growing stock [m3/ha]'] / df_g_inc['years_diff']

    # Drop the rows that are not countries (they both contain 2024)
    # df_g_inc_area = df_g_inc_area[~df_g_inc_area['geoscale'].str.contains('2024', na=False)]

    # Incremental growing stock [m3/ha] = Incremental growing stock [m3] / forest area [ha]
    # df_g_inc_area['Incremental growing stock [m3/ha]'] = df_g_inc_area['incremental growing stock [m3]'] / df_g_inc_area['forest area [ha]']

    # Incremental growing stock [m3/ha] = Incremental growing stock [m3] / forest area [ha]
    # df_g_inc_area['value'] = df_g_inc_area['annual increment [m3/yr]'] / df_g_inc_area['forest area [ha]']

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Adding the columns module, lever, level and string-pivot at the correct places
    df_g_inc_area_pathwaycalc['module'] = 'land-use'
    df_g_inc_area_pathwaycalc['lever'] = 'climate-smart-forestry'
    df_g_inc_area_pathwaycalc['level'] = 0
    df_g_inc_area_pathwaycalc['variables'] = 'agr_climate-smart-forestry_g-inc[m3/ha]'
    cols = df_g_inc_area_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    cols.insert(cols.index('geoscale'), cols.pop(cols.index('variables')))
    df_g_inc_area_pathwaycalc = df_g_inc_area_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_g_inc_area_pathwaycalc['geoscale'] = df_g_inc_area_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_g_inc_area_pathwaycalc['geoscale'] = df_g_inc_area_pathwaycalc['geoscale'].replace(
        'Netherlands (Kingdom of the)',
        'Netherlands')
    df_g_inc_area_pathwaycalc['geoscale'] = df_g_inc_area_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # CSF MANAGED ----------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Is equal to 0 for all ots for all countries

    # Use df_g_inc_area_pathwaycalc as a structural basis
    csf_managed = df_g_inc_area_pathwaycalc.copy()

    # Add rows to have 1990-2022
    # Generate a DataFrame with all combinations of geoscale and timescale
    geoscale_values = csf_managed['geoscale'].unique()
    timescale_values = pd.Series(range(1990, 2023))

    # Create a DataFrame for the cartesian product
    cartesian_product = pd.MultiIndex.from_product([geoscale_values, timescale_values],
                                                   names=['geoscale', 'timescale']).to_frame(index=False)

    # Merge the original DataFrame with the cartesian product to include all combinations
    csf_managed = pd.merge(cartesian_product, csf_managed, on=['geoscale', 'timescale'], how='left')

    # Replace the variable with ots_agr_climate-smart-forestry_csf-man[m3/ha]
    csf_managed['variables'] = 'agr_climate-smart-forestry_csf-man[m3/ha]'

    # Replace the value with 0
    csf_managed['value'] = 0

    # PathwayCalc formatting
    csf_managed['module'] = 'land-use'
    csf_managed['lever'] = 'climate-smart-forestry'
    csf_managed['level'] = 0
    cols = csf_managed.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    csf_managed = csf_managed[cols]

    # ----------------------------------------------------------------------------------------------------------------------
    # FAWS SHARE & GSTOCK (FAWS & NON FAWS)  -------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Read files (growing stock available fo wood supply and not)
    gstock_total = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/data_forestry.xlsx',
        sheet_name='gstock_total_Mm3')
    gstock_faws = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/data_forestry.xlsx',
        sheet_name='gstock_faws_Mm3')
    area_faws = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/data_forestry.xlsx',
        sheet_name='forest_area_faws_1000ha')

    # Format correctly
    # Melting the dfs to have the relevant format (geoscale, year, value)
    gstock_faws = pd.melt(gstock_faws, id_vars=['geoscale'], var_name='timescale',
                          value_name='growing stock faws [Mm3]')
    area_faws = pd.melt(area_faws, id_vars=['geoscale'], var_name='timescale', value_name='area faws [1000ha]')
    gstock_total = pd.melt(gstock_total, id_vars=['geoscale'], var_name='timescale',
                           value_name='growing stock total [Mm3]')
    # Convert 'year' to integer type (optional, for better numerical handling)
    gstock_faws['timescale'] = gstock_faws['timescale'].astype(int)
    area_faws['timescale'] = area_faws['timescale'].astype(int)
    gstock_total['timescale'] = gstock_total['timescale'].astype(int)

    # Merge together and  with forest area (df_area) (also filters the relevant countries)
    gstock = pd.merge(gstock_faws, gstock_total, on=['geoscale', 'timescale'])
    gstock = pd.merge(gstock, area_faws, on=['geoscale', 'timescale'])
    gstock = pd.merge(gstock, df_area, on=['geoscale', 'timescale'])

    # Changing data type to numeric (except for the geoscale column)
    gstock.loc[:, gstock.columns != 'geoscale'] = gstock.loc[:, gstock.columns != 'geoscale'].apply(pd.to_numeric,
                                                                                                    errors='coerce')

    # Growing stock not faws [m3] = Growing stock total [m3] - Growing stock faws [m3]
    gstock['growing stock non faws [Mm3]'] = gstock['growing stock total [Mm3]'] - gstock['growing stock faws [Mm3]']

    # Forest area not for wood supply [ha] = total forest area [ha] - forest available for wood supply [ha]
    gstock['area non faws [ha]'] = gstock['forest area [ha]'] - 1000 * gstock['area faws [1000ha]']

    # Growing stock faws [m3/ha] = 10**6 * Growing stock faws [Mm3] / forest available for wood supply [ha]
    gstock['Growing stock faws [m3/ha]'] = (10 ** 6 * gstock['growing stock faws [Mm3]']) / (
                1000 * gstock['area faws [1000ha]'])

    # Growing stock non faws [m3/ha] = 10**6 * Growing stock non faws [Mm3] / forest non faws [ha]
    gstock['Growing stock non faws [m3/ha]'] = (10 ** 6 * gstock['growing stock non faws [Mm3]']) / gstock[
        'area non faws [ha]']

    # Share faws [%] = total forest area [ha] - forest available for wood supply [ha]
    gstock['Share faws [%]'] = 1000 * gstock['area faws [1000ha]'] / gstock['forest area [ha]']

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Melt the DataFrame
    gstock_pathwaycalc = pd.melt(gstock, id_vars=['geoscale', 'timescale'],
                                 value_vars=['Growing stock faws [m3/ha]', 'Growing stock non faws [m3/ha]',
                                             'Share faws [%]'],
                                 var_name='Item', value_name='value')

    # Read excel file
    df_dict_forestry = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-forestry')

    # Merge based on 'Item'
    gstock_pathwaycalc = pd.merge(df_dict_forestry, gstock_pathwaycalc, on='Item')

    # Drop the 'Item' column
    gstock_pathwaycalc = gstock_pathwaycalc.drop(columns=['Item'])

    # Adding the columns module, lever, level and string-pivot at the correct places
    gstock_pathwaycalc['module'] = 'land-use'
    gstock_pathwaycalc['lever'] = 'climate-smart-forestry'
    gstock_pathwaycalc['level'] = 0
    cols = gstock_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    gstock_pathwaycalc = gstock_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    gstock_pathwaycalc['geoscale'] = gstock_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    gstock_pathwaycalc['geoscale'] = gstock_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                            'Netherlands')
    gstock_pathwaycalc['geoscale'] = gstock_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # HARVESTING RATE -------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------
    # Read files (growing stock available fo wood supply and not)
    h_rate = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/data_forestry.xlsx',
        sheet_name='h-rate')

    # Replace - with Na
    # List of columns to modify
    columns_to_replace = [1990, 2000, 2010, 2015]
    # Replace '-' with NaN in the specified columns
    h_rate[columns_to_replace] = h_rate[columns_to_replace].replace('-', np.nan)

    # Format correctly
    # Melting the dfs to have the relevant format (geoscale, year, value)
    h_rate = pd.melt(h_rate, id_vars=['geoscale'], var_name='timescale', value_name='value')
    # Convert 'year' to integer type (optional, for better numerical handling)
    h_rate['timescale'] = h_rate['timescale'].astype(int)

    # Merge with forest area (df_area) (to filter the relevant countries) then filter out
    h_rate = pd.merge(h_rate, df_area, on=['geoscale', 'timescale'])
    h_rate = h_rate[['geoscale', 'timescale', 'value']]

    # Create copy
    h_rate_pathwaycalc = h_rate.copy()

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Adding the columns module, lever, level and string-pivot at the correct places
    h_rate_pathwaycalc['module'] = 'land-use'
    h_rate_pathwaycalc['lever'] = 'climate-smart-forestry'
    h_rate_pathwaycalc['level'] = 0
    h_rate_pathwaycalc['variables'] = 'agr_climate-smart-forestry_h-rate[%]'
    cols = h_rate_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    cols.insert(cols.index('geoscale'), cols.pop(cols.index('variables')))
    h_rate_pathwaycalc = h_rate_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    h_rate_pathwaycalc['geoscale'] = h_rate_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    h_rate_pathwaycalc['geoscale'] = h_rate_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                            'Netherlands')
    h_rate_pathwaycalc['geoscale'] = h_rate_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # NATURAL LOSSES -------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Read file
    nat_losses = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/data_forestry.xlsx',
        sheet_name='nat-losses_1000ha')

    # Format correctly
    # Melt the DataFrame to long format
    df_melted = pd.melt(nat_losses, id_vars=['geoscale'], var_name='variable', value_name='Losses [1000ha]')

    # Extract 'item' and 'year' from the 'variable' column
    df_melted['Item'] = df_melted['variable'].str.extract(r'^(.*?)\s\d{4}$')[0]
    df_melted['timescale'] = df_melted['variable'].str.extract(r'(\d{4})$')[0]

    # Drop the original 'variable' column
    df_melted = df_melted.drop(columns=['variable'])

    # Rearrange the columns
    nat_losses = df_melted[['geoscale', 'timescale', 'Item', 'Losses [1000ha]']]

    # Change type to numeric for timescale to merge
    nat_losses['timescale'] = nat_losses['timescale'].apply(pd.to_numeric, errors='coerce')

    # Adding forest area and total growing stock
    nat_losses = pd.merge(nat_losses, df_area, on=['geoscale', 'timescale'])
    nat_losses = pd.merge(nat_losses, gstock_total, on=['geoscale', 'timescale'])

    # Change type to numeric
    numeric_cols = nat_losses.columns[3:]  # Get all columns except the first three
    nat_losses[numeric_cols] = nat_losses[numeric_cols].apply(pd.to_numeric,
                                                              errors='coerce')  # Convert to numeric, if not already

    # Ratio of losses area compared to total forest area
    nat_losses['Ratio of losses'] = 1000 * nat_losses['Losses [1000ha]'] / nat_losses['forest area [ha]']

    # Growing stock total [m3/ha] = Growing stock [Mm3] / forest area [ha]
    nat_losses['Growing stock total [m3/ha]'] = 10 ** 6 * nat_losses['growing stock total [Mm3]'] / nat_losses[
        'forest area [ha]']

    # Losses [m3/ha] = Ratio of losses [%] * Growing stock total [m3/ha]
    nat_losses['value'] = nat_losses['Ratio of losses'] * nat_losses['Growing stock total [m3/ha]']

    # Filtering
    nat_losses_pathwaycalc = nat_losses.copy()
    nat_losses_pathwaycalc = nat_losses_pathwaycalc[['Item', 'geoscale', 'timescale', 'value']]

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Read excel file
    df_dict_forestry = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='climate-smart-forestry')

    # Merge based on 'Item'
    nat_losses_pathwaycalc = pd.merge(df_dict_forestry, nat_losses_pathwaycalc, on='Item')

    # Drop the 'Item' column
    nat_losses_pathwaycalc = nat_losses_pathwaycalc.drop(columns=['Item'])

    # Adding the columns module, lever, level and string-pivot at the correct places
    nat_losses_pathwaycalc['module'] = 'land-use'
    nat_losses_pathwaycalc['lever'] = 'climate-smart-forestry'
    nat_losses_pathwaycalc['level'] = 0
    cols = nat_losses_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    nat_losses_pathwaycalc = nat_losses_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    nat_losses_pathwaycalc['geoscale'] = nat_losses_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    nat_losses_pathwaycalc['geoscale'] = nat_losses_pathwaycalc['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                                    'Netherlands')
    nat_losses_pathwaycalc['geoscale'] = nat_losses_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # FINAL RESULT ---------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Concat all dfs together
    df_csf = pd.concat([df_g_inc_area_pathwaycalc, csf_managed])
    df_csf = pd.concat([df_csf, gstock_pathwaycalc])
    df_csf = pd.concat([df_csf, h_rate_pathwaycalc])
    df_csf = pd.concat([df_csf, nat_losses_pathwaycalc])

    # Extrapolating
    df_climate_smart_forestry_pathwaycalc = ensure_structure(df_csf)
    df_climate_smart_forestry_pathwaycalc = linear_fitting_ots_db(df_climate_smart_forestry_pathwaycalc, years_ots,
                                                                   countries='all')

    return df_climate_smart_forestry_pathwaycalc, csf_managed

# CalculationLeaf LAND MANAGEMENT --------------------------------------------------------------------------------------
def land_management_processing(csf_managed):

    # ----------------------------------------------------------------------------------------------------------------------
    # LAND MATRIX & LAND MAN USE----------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Importing UNFCCC excel files and reading them with a loop (only for Switzerland) Table 4.1 ---------------------------
    # Putting in a df in 3 dimensions (from, to, year)
    # Define the path where the Excel files are located
    folder_path = '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/data_unfccc_2023'

    # List all files in the folder
    files = os.listdir(folder_path)

    # Filter and sort files by the year (1990 to 2020)
    sorted_files = sorted([f for f in files if f.startswith('CHE_2023_') and int(f.split('_')[2]) in range(1990, 2021)],
                          key=lambda x: int(x.split('_')[2]))

    # Initialize a list to store DataFrames
    data_frames = []

    # Loop through sorted files, read the required rows, and append to the list
    for file in sorted_files:
        # Extract the year from the filename
        year = int(file.split('_')[2])

        # Full path to the file
        file_path = os.path.join(folder_path, file)

        # Read the specific rows and sheet from the Excel file
        df = pd.read_excel(file_path, sheet_name='Table4.1', skiprows=4, nrows=14, header=None)

        # Add a column for the year to the DataFrame
        df['Year'] = year

        # Append to the list of DataFrames
        data_frames.append(df)

    # Combine all DataFrames into a single DataFrame with a multi-index
    combined_df = pd.concat(data_frames, axis=0).set_index(['Year'])

    # Create a 3D array
    values_3d = np.array([df.values for df in data_frames])

    # Convert array in string
    data = values_3d.astype(str)

    # Create a row mask where the first column of each 14x13 slice doesn't contain 'unmanaged' -----------------------------
    row_mask = np.all(np.core.defchararray.find(data[:, :, 0], 'unmanaged') == -1, axis=0)

    # Create a column mask where the first row of each 14x13 slice doesn't contain 'unmanaged'
    col_mask = np.all(np.core.defchararray.find(data[:, 0, :], 'unmanaged') == -1, axis=0)

    # Apply the row mask to keep rows in each slice that do not contain 'unmanaged' in the first column
    filtered_data = data[:, row_mask, :]

    # Apply the column mask to keep columns in each slice that do not contain 'unmanaged' in the first row
    filtered_data = filtered_data[:, :, col_mask]

    # Creating a copy due to mask issue in the following steps
    filtered_data = filtered_data.copy()

    # Dropping the row that contain 'FROM' (index 1) ---------------------------------------------------------------------------------
    # Function to drop the second row (index 1) in a 14x13 slice
    def drop_second_row(slice_2d):
        # Create a mask for all rows except the one to drop (row index 1)
        row_mask = np.arange(slice_2d.shape[0]) != 1

        # Keep only the rows that are not the second row
        filtered_slice = slice_2d[row_mask, :]

        return filtered_slice

    # Apply the function to each 14x13 slice
    filtered_data_2 = np.array([drop_second_row(filtered_data[i]) for i in range(filtered_data.shape[0])])

    # Create a copy for potential issues due to mask
    filtered_data_2 = filtered_data_2.copy()

    # LAND MATRIX -------------------------------------------------------------------------------------------------------------

    # Create a copy
    array_land_matrix = filtered_data_2.copy()

    # Drop the unwanted row and column to only keep the land to and from (not final)
    # Function to drop the second row (index 1) in a 14x13 slice
    def drop_rows_and_columns(slice_2d, rows_to_drop=None, cols_to_drop=None):
        """
        Drop specific rows and columns from a 2D NumPy array.

        Parameters:
        slice_2d (np.ndarray): The 2D NumPy array from which rows and columns will be dropped.
        rows_to_drop (list or None): List of row indices to be dropped. If None, no rows are dropped.
        cols_to_drop (list or None): List of column indices to be dropped. If None, no columns are dropped.

        Returns:
        np.ndarray: The modified 2D NumPy array with specified rows and columns removed.
        """
        # If rows_to_drop is None or empty, don't drop any rows
        if rows_to_drop is None:
            rows_to_drop = []
        # If cols_to_drop is None or empty, don't drop any columns
        if cols_to_drop is None:
            cols_to_drop = []

        # Create a mask for rows to keep (not in rows_to_drop)
        if rows_to_drop:
            row_mask = np.ones(slice_2d.shape[0], dtype=bool)
            row_mask[rows_to_drop] = False
        else:
            row_mask = np.ones(slice_2d.shape[0], dtype=bool)

        # Create a mask for columns to keep (not in cols_to_drop)
        if cols_to_drop:
            col_mask = np.ones(slice_2d.shape[1], dtype=bool)
            col_mask[cols_to_drop] = False
        else:
            col_mask = np.ones(slice_2d.shape[1], dtype=bool)

        # Apply the masks to keep only the rows and columns that are not in the drop lists
        filtered_slice = slice_2d[row_mask, :][:, col_mask]

        return filtered_slice

    # Apply the function to each 14x13 slice
    array_land_matrix = np.array(
        [drop_rows_and_columns(array_land_matrix[i], rows_to_drop=[7, 8], cols_to_drop=None) for i in
         range(array_land_matrix.shape[0])])

    # Transform in a df
    # Reshape array
    array_2d = array_land_matrix.reshape(-1, array_land_matrix.shape[2])
    # Convert the 2D array to a DataFrame
    df_land_matrix = pd.DataFrame(array_2d)

    # Set the first row as index
    df_land_matrix.columns = df_land_matrix.iloc[0]  # Set the first row as the new column headers
    df_land_matrix = df_land_matrix[1:]  # Remove the first row from the DataFrame
    df_land_matrix = df_land_matrix.reset_index(drop=True)  # Reset the index after removing the first row

    # Drop the rows that contain TO:
    df_land_matrix = df_land_matrix[
        ~df_land_matrix.apply(lambda row: row.astype(str).str.contains('TO:').any(), axis=1)]

    # Rename cols 1990 into timescale
    df_land_matrix.rename(columns={'1990': 'timescale'}, inplace=True)

    # Change type to numeric
    numeric_cols = df_land_matrix.columns[1:]  # Get all columns except the first three
    df_land_matrix[numeric_cols] = df_land_matrix[numeric_cols].apply(pd.to_numeric,
                                                                      errors='coerce')  # Convert to numeric, if not already

    # Divide each column by the initial area to convert from [ha] to [%]
    df_land_matrix['Forest land (managed)'] = df_land_matrix['Forest land (managed)'] / df_land_matrix['Initial area']
    df_land_matrix['Cropland '] = df_land_matrix['Cropland '] / df_land_matrix['Initial area']
    df_land_matrix['Grassland (managed)'] = df_land_matrix['Grassland (managed)'] / df_land_matrix['Initial area']
    df_land_matrix['Wetlands (managed)'] = df_land_matrix['Wetlands (managed)'] / df_land_matrix['Initial area']
    df_land_matrix['Settlements'] = df_land_matrix['Settlements'] / df_land_matrix['Initial area']
    df_land_matrix['Other land'] = df_land_matrix['Other land'] / df_land_matrix['Initial area']

    # Drop the column 'Initial area'
    df_land_matrix = df_land_matrix.drop(columns=['Initial area'])

    # Melt to have year, values, land-to and land-from
    df_land_matrix = pd.melt(df_land_matrix, id_vars=['TO:', 'timescale'],
                             value_vars=['Forest land (managed)', 'Cropland ', 'Grassland (managed)',
                                         'Wetlands (managed)',
                                         'Settlements', 'Other land'],
                             var_name='FROM:', value_name='value')

    # Combine 'TO:' and 'FROM:' columns into a single 'item' column
    df_land_matrix['Item'] = df_land_matrix['FROM:'] + ' to ' + df_land_matrix['TO:']

    # Drop the original 'TO:' and 'FROM:' columns if no longer needed
    df_land_matrix = df_land_matrix.drop(columns=['TO:', 'FROM:'])

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Match with dictionary for correct names
    # Read excel file
    df_dict_land_man = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='land-management')

    # Merge based on 'Item'
    df_land_matrix_pathwaycalc = pd.merge(df_dict_land_man, df_land_matrix, on='Item')

    # Drop the 'Item' column
    df_land_matrix_pathwaycalc = df_land_matrix_pathwaycalc.drop(columns=['Item'])

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_land_matrix_pathwaycalc['module'] = 'land-use'
    df_land_matrix_pathwaycalc['lever'] = 'land-man'
    df_land_matrix_pathwaycalc['level'] = 0
    df_land_matrix_pathwaycalc['geoscale'] = 'Switzerland'
    cols = df_land_matrix_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    cols.insert(cols.index('timescale'), cols.pop(cols.index('geoscale')))
    df_land_matrix_pathwaycalc = df_land_matrix_pathwaycalc[cols]

    # LAND USE -------------------------------------------------------------------------------------------------------------
    # Use the row 'Final area' for 'land-man_use' forest, other, settlement and wetland ------------------------------------
    def keep_final_use_row(slice_2d):
        # Create a mask for all rows except the one to drop (row index 1)
        row_mask = np.arange(slice_2d.shape[0]) == 7

        # Keep only the rows that are not the second row
        filtered_slice = slice_2d[row_mask, :]

        return filtered_slice

    # Apply the function to each 14x13 slice
    filtered_data_land_use = np.array([keep_final_use_row(filtered_data_2[i]) for i in range(filtered_data_2.shape[0])])

    # Transform  array in df
    # Remove the extra dimension
    reshaped_array = filtered_data_land_use.reshape(31, 9)
    # Create a DataFrame from the reshaped array
    df_land_use = pd.DataFrame(reshaped_array)

    # Change the correct indices for columns
    new_column_names = ['element', 'agr_land-man_use_forest[ha]', 'agr_land-man_use_cropland[ha]',
                        'agr_land-man_use_grassland[ha]', 'agr_land-man_use_wetland[ha]',
                        'agr_land-man_use_settlement[ha]',
                        'agr_land-man_use_other[ha]', 'initial area', 'timescale']

    # Assign the new column names to the DataFrame
    df_land_use.columns = new_column_names

    # Dropping the columns 'element' and 'initial area'
    df_land_use = df_land_use.drop(columns=['element', 'initial area'])
    df_land_use_filtered = df_land_use.drop(columns=['agr_land-man_use_cropland[ha]', 'agr_land-man_use_grassland[ha]'])

    # Melting the dfs to have the relevant format (geoscale, year, value)
    df_land_use_pathwaycalc = pd.melt(df_land_use_filtered, id_vars=['timescale'], var_name='variables',
                                      value_name='value')

    # Convert the 'value' column from string to numeric
    df_land_use_pathwaycalc['value'] = pd.to_numeric(df_land_use_pathwaycalc['value'], errors='coerce')

    # Unit conversion [kha] => [ha]
    df_land_use_pathwaycalc['value'] = df_land_use_pathwaycalc['value'] * 1000

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Adding the columns module, lever, level and string-pivot at the correct places
    df_land_use_pathwaycalc['module'] = 'land-use'
    df_land_use_pathwaycalc['lever'] = 'land-man'
    df_land_use_pathwaycalc['level'] = 0
    df_land_use_pathwaycalc['geoscale'] = 'Switzerland'
    cols = df_land_use_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    cols.insert(cols.index('timescale'), cols.pop(cols.index('geoscale')))
    df_land_use_pathwaycalc = df_land_use_pathwaycalc[cols]

    # ----------------------------------------------------------------------------------------------------------------------
    # LAND DYN -------------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # 1 for forest, 0 for grassland and unmanaged for all ots

    # Using csf_managed as a structural basis
    df_land_dyn_forest = csf_managed.copy()
    df_land_dyn_grass = csf_managed.copy()
    df_land_dyn_unmanaged = csf_managed.copy()

    # Changing values and variable name
    df_land_dyn_forest['variables'] = 'agr_land-man_dyn_forest[%]'
    df_land_dyn_forest['value'] = 1
    df_land_dyn_grass['variables'] = 'agr_land-man_dyn_grassland[%]'
    df_land_dyn_grass['value'] = 0
    df_land_dyn_unmanaged['variables'] = 'agr_land-man_dyn_unmanaged[%]'
    df_land_dyn_unmanaged['value'] = 0

    # Concatenating
    df_land_dyn = pd.concat([df_land_dyn_forest, df_land_dyn_grass])
    df_land_dyn = pd.concat([df_land_dyn, df_land_dyn_unmanaged])

    # PathwayCalc formatting
    df_land_dyn['lever'] = 'land-man'

    # ----------------------------------------------------------------------------------------------------------------------
    # LAND GAP -------------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------
    # Difference in values between FAO and UNFCCC

    # Read FAO Values (for Switzerland) --------------------------------------------------------------------------------------------
    # List of countries
    list_countries = ['Switzerland']

    # List of elements
    list_elements = ['Area']

    list_items = ['-- Cropland', '-- Permanent meadows and pastures', 'Forest land']

    # 1990 - 2022
    ld = faostat.list_datasets()
    code = 'RL'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_land_use_fao = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Drop columns
    df_land_use_fao = df_land_use_fao.drop(
        columns=['Domain Code', 'Domain', 'Area Code', 'Element Code',
                 'Item Code', 'Year Code', 'Unit', 'Element', 'Area'])

    # Reshape
    df = df_land_use_fao.copy()
    # Reshape the DataFrame using pivot
    reshaped_df = df.pivot(index='Year', columns='Item', values='Value')
    # Reset the index if you want a flat DataFrame with 'item' as a column
    reshaped_df = reshaped_df.reset_index()

    # Read UNFCCC values (for Switzerland)
    # done in previous steps, result is df_land_use

    # Merged based on timescale
    df_land_gap = pd.merge(reshaped_df, df_land_use, left_on='Year', right_on='timescale')

    # Change type to numeric
    numeric_cols = df_land_gap.columns[1:]  # Get all columns except the first three
    df_land_gap[numeric_cols] = df_land_gap[numeric_cols].apply(pd.to_numeric,
                                                                errors='coerce')

    # Computing the difference & Unit conversion [kha] => [ha]
    df_land_gap['agr_land-man_gap_cropland[ha]'] = 1000 * (df_land_gap['agr_land-man_use_cropland[ha]'] -
                                                          df_land_gap['Cropland'])
    df_land_gap['agr_land-man_gap_forest[ha]'] = 1000 * (df_land_gap['agr_land-man_use_forest[ha]'] -
                                                        df_land_gap['Forest land'])
    df_land_gap['agr_land-man_gap_grassland[ha]'] = 1000 * (df_land_gap['agr_land-man_use_grassland[ha]'] -
                                                           df_land_gap['Permanent meadows and pastures'])
    # df_land_gap['agr_land-man_gap_other[ha]'] = df_land_gap[''] - df_land_gap['']
    # df_land_gap['agr_land-man_gap_settlement[ha]'] = df_land_gap[''] - df_land_gap['']
    # df_land_gap['agr_land-man_gap_wetland[ha]'] = df_land_gap[''] - df_land_gap['']

    # Keep only the useful columns
    df_land_gap = df_land_gap[['timescale', 'agr_land-man_gap_cropland[ha]', 'agr_land-man_gap_forest[ha]',
                               'agr_land-man_gap_grassland[ha]']]

    # Melt the df
    df_land_gap = pd.melt(df_land_gap, id_vars=['timescale'],
                                          var_name='variables', value_name='value')

    # PathwayCalc formatting
    df_land_gap['module'] = 'land-use'
    df_land_gap['lever'] = 'land-man'
    df_land_gap['level'] = 0
    df_land_gap['geoscale'] = 'Switzerland' # Setting the geoscale for CH
    cols = df_land_gap.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    cols.insert(cols.index('timescale'), cols.pop(cols.index('variables')))
    df_land_gap = df_land_gap[cols]

    # Rename countries to Pathaywcalc name
    #df_land_gap['geoscale'] = df_land_gap['geoscale'].replace(
    #    'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    #df_land_gap['geoscale'] = df_land_gap['geoscale'].replace(
    #    'Netherlands (Kingdom of the)', 'Netherlands')
    #df_land_gap['geoscale'] = df_land_gap['geoscale'].replace('Czechia', 'Czech Republic')

    # ----------------------------------------------------------------------------------------------------------------------
    # FINAL RESULTS --------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------
    # Concatenating all dfs
    df_land_management_pathwaycalc = pd.concat([df_land_matrix_pathwaycalc, df_land_use_pathwaycalc])
    df_land_management_pathwaycalc = pd.concat([df_land_management_pathwaycalc, df_land_dyn])
    df_land_management_pathwaycalc = pd.concat([df_land_management_pathwaycalc, df_land_gap])

    # Extrapolating
    df_land_management_pathwaycalc = ensure_structure(df_land_management_pathwaycalc)
    df_land_management_pathwaycalc = linear_fitting_ots_db(df_land_management_pathwaycalc, years_ots, countries='all')

    return df_land_management_pathwaycalc

# CalculationLeaf BIOENERGY CAPACITY -----------------------------------------------------------------------------------

def bioernergy_capacity_processing(df_csl_feed):
    # Using and formatting df_csl_feed as a structural basis for constant ots values across all countries
    df_bioenergy_capacity_all = df_csl_feed.copy()
    df_bioenergy_capacity_all = df_bioenergy_capacity_all.drop(columns=['Item', 'Feed'])
    # Dropping duplicate rows
    df_bioenergy_capacity_all = df_bioenergy_capacity_all.drop_duplicates()

    # Using and formatting df_csl_feed as a structural basis for constant ots values in Switzerland
    df_bioenergy_capacity_CH = df_bioenergy_capacity_all.copy()
    # Keeping only the rows where geoscale = Switzerland
    df_bioenergy_capacity_CH = df_bioenergy_capacity_CH[df_bioenergy_capacity_CH['Area'] == 'Switzerland']

    # Adding the constant ots values
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_elec_biogases-hf[GW]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_elec_biogases[GW]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_elec_solid-biofuel-hf[GW]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_elec_solid-biofuel[GW]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_efficiency_biogases-hf[%]'] = 1.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_efficiency_biogases[%]'] = 1.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_efficiency_solid-biofuel-hf[%]'] = 1.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_efficiency_solid-biofuel[%]'] = 1.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_liq_biodiesel[TWh]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_liq_biogasoline[TWh]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_liq_biojetkerosene[TWh]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_liq_other-liquid-biofuel[TWh]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_load-factor_biogases-hf[%]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_load-factor_biogases[%]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_load-factor_solid-biofuel-hf[%]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_load-factor_solid-biofuel[%]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_bgs-mix_digestor[%]'] = 1.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_bgs-mix_landfill[%]'] = 0.3647531014351739
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_bgs-mix_other-biogases[%]'] = 0.0
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_bgs-mix_ren-mun-wastes[%]'] = 0.3567258574556069
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_bgs-mix_sewage[%]'] = 0.6352468985648261
    df_bioenergy_capacity_CH['agr_bioenergy-capacity_bgs-mix_themal-biogases[%]'] = 0.0

    # Drop columns 'Total feed' and 'Feed ratio'
    df_bioenergy_capacity_CH = df_bioenergy_capacity_CH.drop(columns=['Total feed', 'Feed ratio'])

    # Melting
    df_bioenergy_capacity_CH_pathwaycalc= pd.melt(df_bioenergy_capacity_CH, id_vars=['Area', 'Year'],
                                          var_name='variables', value_name='value')

    # Renaming columns
    df_bioenergy_capacity_CH_pathwaycalc.rename(columns={'Area': 'geoscale', 'Year': 'timescale'}, inplace=True)

    # PathwayCalc formatting
    df_bioenergy_capacity_CH_pathwaycalc['module'] = 'agriculture'
    df_bioenergy_capacity_CH_pathwaycalc['lever'] = 'bioenergy-capacity'
    df_bioenergy_capacity_CH_pathwaycalc['level'] = 0
    cols = df_bioenergy_capacity_CH_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    cols.insert(cols.index('timescale'), cols.pop(cols.index('variables')))
    df_bioenergy_capacity_CH_pathwaycalc = df_bioenergy_capacity_CH_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_bioenergy_capacity_CH_pathwaycalc['geoscale'] = df_bioenergy_capacity_CH_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_bioenergy_capacity_CH_pathwaycalc['geoscale'] = df_bioenergy_capacity_CH_pathwaycalc['geoscale'].replace(
        'Netherlands (Kingdom of the)', 'Netherlands')
    df_bioenergy_capacity_CH_pathwaycalc['geoscale'] = df_bioenergy_capacity_CH_pathwaycalc['geoscale'].replace('Czechia', 'Czech Republic')

    # Extrapolating
    df_bioenergy_capacity_CH_pathwaycalc = ensure_structure(df_bioenergy_capacity_CH_pathwaycalc)
    df_bioenergy_capacity_CH_pathwaycalc = linear_fitting_ots_db(df_bioenergy_capacity_CH_pathwaycalc, years_ots, countries='all')

    return df_bioenergy_capacity_CH_pathwaycalc

# CalculationLeaf BIOMASS HIERARCHY ------------------------------------------------------------------------------------

def biomass_bioernergy_hierarchy_processing(df_csl_feed):
    # ------------------------------------------------------------------------------------------------------------------
    # BIOMASS MIX
    # ------------------------------------------------------------------------------------------------------------------
    # Load from previous EuCalc Data
    df_biomass_mix_data = pd.read_csv(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/agriculture_biomass-use-hierarchy_eucalc.csv', sep=';')

    # Filter columns
    df_filtered_columns = df_biomass_mix_data[['geoscale', 'timescale', 'eucalc-name', 'value']]
    df_filtered_columns.copy()

    # rename col 'eucalc-name' in 'variables'
    df_filtered_columns = df_filtered_columns.rename(columns={'eucalc-name': 'variables'})

    # Filter rows that contains biomass-mix
    df_filtered_rows = df_filtered_columns[
        df_filtered_columns['variables'].str.contains('ots_agr_biomass-hierarchy_biomass-mix', case=False, na=False)
    ]

    # Drop rows where 'variables' contains '%_1'
    df_biomass_mix = df_filtered_rows[~df_filtered_rows['variables'].str.contains('%_1', na=False)]
    df_biomass_mix = df_biomass_mix.copy()

    # Rename from ots_agr to agr
    df_biomass_mix['variables'] = df_biomass_mix['variables'].str.replace('ots_agr', 'agr', regex=False)

    # ------------------------------------------------------------------------------------------------------------------
    # BIOMASS RESIDUES CEREALS BURNT & SOIL
    # ------------------------------------------------------------------------------------------------------------------
    # Load from previous EuCalc Data
    df_biomass_residues_data = pd.read_csv(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/agriculture_biomass-use-hierarchy_eucalc.csv', sep=';')

    # Filter columns
    df_filtered_columns = df_biomass_residues_data[['geoscale', 'timescale', 'eucalc-name', 'value']]

    # rename col 'eucalc-name' in 'variables'
    df_filtered_columns = df_filtered_columns.rename(columns={'eucalc-name': 'variables'})

    # Filter rows that contains biomass-mix
    df_filtered_rows = df_filtered_columns[
        df_filtered_columns['variables'].str.contains('ots_agr_biomass-hierarchy_crop_cereal', case=False, na=False)
    ]

    # Drop rows where 'variables' contains '%_1'
    df_biomass_residues = df_filtered_rows[~df_filtered_rows['variables'].str.contains('%_1', na=False)].copy()

    # Rename from ots_agr to agr
    df_biomass_residues['variables'] = df_biomass_residues['variables'].str.replace('ots_agr', 'agr', regex=False)

    # ------------------------------------------------------------------------------------------------------------------
    # BIOMASS HIERARCHY
    # ------------------------------------------------------------------------------------------------------------------

    # Using and formatting df_csl_feed as a structural basis for constant ots values across all countries
    df_biomass_hierarchy_all = df_csl_feed.copy()
    df_biomass_hierarchy_all = df_biomass_hierarchy_all.drop(columns=['Item', 'Feed'])
    # Dropping duplicate rows
    df_biomass_hierarchy_all = df_biomass_hierarchy_all.drop_duplicates()

    # Using and formatting df_csl_feed as a structural basis for constant ots values in Switzerland
    df_biomass_hierarchy_CH = df_biomass_hierarchy_all.copy()
    # Keeping only the rows where geoscale = Switzerland
    df_biomass_hierarchy_CH = df_biomass_hierarchy_CH[df_biomass_hierarchy_CH['Area'] == 'Switzerland']

    # Renaming columns
    df_biomass_hierarchy_CH.rename(columns={'Area': 'geoscale', 'Year': 'timescale'}, inplace=True)
    df_biomass_hierarchy_all.rename(columns={'Area': 'geoscale', 'Year': 'timescale'}, inplace=True)

    # Adding ots values
    df_biomass_hierarchy_all['agr_biomass-hierarchy-bev-ibp-use-oth_fertilizer[%]'] = 0.05
    df_biomass_hierarchy_all['agr_biomass-hierarchy-bev-ibp-use-oth_solid-bioenergy[%]'] = 0.8
    df_biomass_hierarchy_all['agr_biomass-hierarchy-bev-ibp-use-oth_biogasoline[%]'] = 0.05
    df_biomass_hierarchy_all['agr_biomass-hierarchy_bioenergy_ibp_fdk[%]'] = 0.1
    df_biomass_hierarchy_all['agr_biomass-hierarchy_bioenergy_fdk-demand_eth_mix_cereal[%]'] = 0.5
    df_biomass_hierarchy_all['agr_biomass-hierarchy_bioenergy_fdk-demand_eth_mix_sugarcrop[%]'] = 0.5
    df_biomass_hierarchy_all['agr_biomass-hierarchy_bioenergy_fdk-demand_oil_mix_voil[%]'] = 1.0
    df_biomass_hierarchy_all['agr_biomass-hierarchy_bioenergy_liquid_biodiesel_btl[%]'] = 0.0
    df_biomass_hierarchy_all['agr_biomass-hierarchy_bioenergy_liquid_biodiesel_est[%]'] = 1.0
    df_biomass_hierarchy_all['agr_biomass-hierarchy_bioenergy_liquid_biodiesel_hvo[%]'] = 0.0
    df_biomass_hierarchy_all['agr_biomass-hierarchy_bioenergy_liquid_biogasoline_ezm[%]'] = 0.0
    df_biomass_hierarchy_all['agr_biomass-hierarchy_bioenergy_liquid_biogasoline_fer[%]'] = 1.0
    df_biomass_hierarchy_all['agr_biomass-hierarchy_bioenergy_liquid_biojetkerosene_btl[%]'] = 0.0
    df_biomass_hierarchy_all['agr_biomass-hierarchy_bioenergy_liquid_biojetkerosene_hvo[%]'] = 1.0

    # Drop columns 'Total feed' and 'Feed ratio'
    df_biomass_hierarchy_all = df_biomass_hierarchy_all.drop(columns=['Total feed', 'Feed ratio'])

    # Melt df
    df_biomass_hierarchy_pathwaycalc = pd.melt(df_biomass_hierarchy_all, id_vars=['geoscale', 'timescale'],
                                               var_name='variables', value_name='value')

    # Concat dfs
    df_biomass_hierarchy_pathwaycalc = pd.concat([df_biomass_hierarchy_pathwaycalc, df_biomass_mix])
    df_biomass_hierarchy_pathwaycalc = pd.concat([df_biomass_hierarchy_pathwaycalc, df_biomass_residues])

    # PathwayCalc formatting
    df_biomass_hierarchy_pathwaycalc['module'] = 'agriculture'
    df_biomass_hierarchy_pathwaycalc['lever'] = 'biomass-hierarchy'
    df_biomass_hierarchy_pathwaycalc['level'] = 0
    cols = df_biomass_hierarchy_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_biomass_hierarchy_pathwaycalc = df_biomass_hierarchy_pathwaycalc[cols]

    # Extrapolating
    df_biomass_hierarchy_pathwaycalc = ensure_structure(df_biomass_hierarchy_pathwaycalc)
    df_biomass_hierarchy_pathwaycalc = linear_fitting_ots_db(df_biomass_hierarchy_pathwaycalc, years_ots, countries='all')

    return df_biomass_hierarchy_pathwaycalc

# CalculationLeaf LIVESTOCK PROTEIN MEALS ------------------------------------------------------------------------------------
def livestock_protein_meals_processing(df_csl_feed):

    # Using and formatting df_csl_feed as a structural basis for constant ots values across all countries
    df_protein_meals_all = df_csl_feed.copy()
    df_protein_meals_all = df_protein_meals_all.drop(columns=['Item', 'Feed'])
    # Dropping duplicate rows
    df_protein_meals_all = df_protein_meals_all.drop_duplicates()

    # Adding ots values
    df_protein_meals_all['agr_alt-protein_abp-dairy-milk_algae[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_abp-dairy-milk_insect[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_abp-hens-egg_algae[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_abp-hens-egg_insect[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_meat-bovine_algae[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_meat-bovine_insect[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_meat-oth-animals_algae[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_meat-oth-animals_insect[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_meat-pig_algae[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_meat-pig_insect[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_meat-poultry_algae[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_meat-poultry_insect[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_meat-sheep_algae[%]'] = 0.0
    df_protein_meals_all['agr_alt-protein_meat-sheep_insect[%]'] = 0.0

    # Drop columns 'Total feed' and 'Feed ratio'
    df_protein_meals_all = df_protein_meals_all.drop(columns=['Total feed', 'Feed ratio'])

    # Melt df
    df_protein_meals_pathwaycalc = pd.melt(df_protein_meals_all, id_vars=['Area', 'Year'],
                                           var_name='variables', value_name='value')

    # Renaming columns
    df_protein_meals_pathwaycalc.rename(columns={'Area': 'geoscale', 'Year': 'timescale'}, inplace=True)

    # PathwayCalc formatting
    df_protein_meals_pathwaycalc['module'] = 'agriculture'
    df_protein_meals_pathwaycalc['lever'] = 'alt-protein'
    df_protein_meals_pathwaycalc['level'] = 0
    cols = df_protein_meals_pathwaycalc.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_protein_meals_pathwaycalc = df_protein_meals_pathwaycalc[cols]

    # Rename countries to Pathaywcalc name
    df_protein_meals_pathwaycalc['geoscale'] = df_protein_meals_pathwaycalc['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_protein_meals_pathwaycalc['geoscale'] = df_protein_meals_pathwaycalc['geoscale'].replace(
        'Netherlands (Kingdom of the)', 'Netherlands')
    df_protein_meals_pathwaycalc['geoscale'] = df_protein_meals_pathwaycalc['geoscale'].replace(
        'Czechia', 'Czech Republic')

    # Extrapolating
    df_protein_meals_pathwaycalc = ensure_structure(df_protein_meals_pathwaycalc)
    df_protein_meals_pathwaycalc = linear_fitting_ots_db(df_protein_meals_pathwaycalc, years_ots,
                                                                 countries='all')

    return df_protein_meals_pathwaycalc




# CalculationLeaf CAL - LIFESTYLE -----------------------------------------------------------------------------------

def lifestyle_calibration():
    # ----------------------------------------------------------------------------------------------------------------------
    # FOOD SUPPLY (DIET) ---------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Read data ------------------------------------------------------------------------------------------------------------

    # Common for all
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # FOOD BALANCE SHEETS (FBS) - -------------------------------------------------
    # List of elements
    list_elements = ['Food supply (kcal/capita/day)']
    list_items = ['Cereals - Excluding Beer + (Total)', 'Fruits - Excluding Wine + (Total)', 'Oilcrops + (Total)',
                  'Pulses + (Total)', 'Rice (Milled Equivalent)',
                  'Starchy Roots + (Total)', 'Stimulants + (Total)', 'Sugar Crops + (Total)', 'Vegetables + (Total)',
                  'Demersal Fish', 'Freshwater Fish',
                  'Aquatic Animals, Others', 'Pelagic Fish', 'Beer', 'Beverages, Alcoholic', 'Beverages, Fermented',
                  'Wine', 'Sugar (Raw Equivalent)', 'Sweeteners, Other', 'Vegetable Oils + (Total)',
                  'Milk - Excluding Butter + (Total)', 'Eggs + (Total)', 'Animal fats + (Total)', 'Offals + (Total)',
                  'Bovine Meat', 'Meat, Other', 'Pigmeat',
                  'Poultry Meat', 'Mutton & Goat Meat', 'Fish, Seafood + (Total)', 'Coffee and products']

    # 1990 - 2013 - Food supply
    ld = faostat.list_datasets()
    code = 'FBSH'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002',
                  '2003', '2004', '2005', '2006', '2007', '2008', '2009']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_diet_1990_2013 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # 1990 - 2013 - Population
    list_elements = ['Total Population - Both sexes']
    list_items = ['Population']
    ld = faostat.list_datasets()
    code = 'FBSH'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002',
                  '2003', '2004', '2005', '2006', '2007', '2008', '2009']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_population_1990_2013 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # 2010-2022
    list_elements = ['Food supply (kcal)']
    list_items = ['Cereals - Excluding Beer + (Total)', 'Fruits - Excluding Wine + (Total)', 'Oilcrops + (Total)',
                  'Pulses + (Total)', 'Rice and products',
                  'Starchy Roots + (Total)', 'Stimulants + (Total)', 'Sugar Crops + (Total)', 'Vegetables + (Total)',
                  'Demersal Fish', 'Freshwater Fish',
                  'Aquatic Animals, Others', 'Pelagic Fish', 'Beer', 'Beverages, Alcoholic', 'Beverages, Fermented',
                  'Wine', 'Sugar (Raw Equivalent)', 'Sweeteners, Other', 'Vegetable Oils + (Total)',
                  'Milk - Excluding Butter + (Total)', 'Eggs + (Total)', 'Animal fats + (Total)', 'Offals + (Total)',
                  'Bovine Meat', 'Meat, Other', 'Pigmeat',
                  'Poultry Meat', 'Mutton & Goat Meat', 'Fish, Seafood + (Total)', 'Coffee and products']
    code = 'FBS'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021',
                  '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_diet_2010_2022 = faostat.get_data_df(code, pars=my_pars, strval=False)

    df_diet_1990_2013.loc[
        df_diet_1990_2013['Item'].str.contains('Rice \(Milled Equivalent\)', case=False,
                                               na=False), 'Item'] = 'Rice and products'

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Element', 'Item', 'Year', 'Value']
    df_diet_1990_2013 = df_diet_1990_2013[columns_to_filter]
    df_population_1990_2013 = df_population_1990_2013[columns_to_filter]
    df_diet_2010_2022 = df_diet_2010_2022[columns_to_filter]

    # Pivot the df
    pivot_df_diet_1990_2013 = df_diet_1990_2013.pivot_table(index=['Area', 'Year', 'Item'], columns='Element',
                                          values='Value').reset_index()
    pivot_df_population_1990_2013 = df_population_1990_2013.pivot_table(index=['Area', 'Year', 'Item'], columns='Element',
                                                            values='Value').reset_index()
    pivot_df_diet_2010_2022 = df_diet_2010_2022.pivot_table(index=['Area', 'Year', 'Item'], columns='Element',
                                                            values='Value').reset_index()
    # Merge the DataFrames on 'Area' and 'Year'
    merged_df = pd.merge(
        pivot_df_diet_1990_2013,
        pivot_df_population_1990_2013[['Area', 'Year', 'Total Population - Both sexes']],  # Only keep the needed columns
        on=['Area', 'Year']
    )

    # Multiplying population [capita] with food supply [kcal/capita/day] to have food supply [kcal] (per year implicitely)
    merged_df['Food supply (kcal)'] = 365.25 * 1000 * merged_df['Total Population - Both sexes'] * merged_df['Food supply (kcal/capita/day)']
    merged_df = merged_df[['Area', 'Year', 'Item', 'Food supply (kcal)']]

    # Concatenating all the years together
    pivot_df_diet = pd.concat([merged_df, pivot_df_diet_2010_2022])

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Food item name matching with dictionary
    # Read excel file
    df_dict_calibration = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='calibration')

    # Prepend "Diet" to each value in the 'Item' column
    pivot_df_diet['Item'] = pivot_df_diet['Item'].apply(lambda x: f"Diet {x}")

    # Merge based on 'Item'
    df_diet_calibration = pd.merge(df_dict_calibration, pivot_df_diet, on='Item')

    # Drop the 'Item' column
    df_diet_calibration = df_diet_calibration.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_diet_calibration.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Food supply (kcal)': 'value'}, inplace=True)

    return df_diet_calibration


# CalculationLeaf CAL - LIVESTOCK & CROP -----------------------------------------------------------------------------------
def livestock_crop_calibration(df_energy_demand_cal):
    # ----------------------------------------------------------------------------------------------------------------------
    # LIVESTOCK POPULATION -------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Read data ------------------------------------------------------------------------------------------------------------

    # Common for all
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # EMISSIONS FROM LIVESTOCK (GLE) - -------------------------------------------------
    # List of elements
    list_elements = ['Stocks']

    list_items = ['Swine + (Total)', 'Sheep and Goats + (Total)', 'Cattle, dairy', 'Cattle, non-dairy',
                  'Chickens, layers']

    list_items_poultry = ['Chickens, broilers', 'Ducks', 'Turkeys']

    list_items_others = ['Asses', 'Buffalo', 'Camels', 'Horses', 'Llamas', 'Mules and hinnies']

    # 1990 - 2022
    ld = faostat.list_datasets()
    code = 'GLE'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_liv_population = faostat.get_data_df(code, pars=my_pars, strval=False)

    my_items_poultry = [faostat.get_par(code, 'item')[i] for i in list_items_poultry]
    my_pars_poultry = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items_poultry,
        'year': my_years
    }
    df_liv_population_poultry = faostat.get_data_df(code, pars=my_pars_poultry, strval=False)

    my_items_others = [faostat.get_par(code, 'item')[i] for i in list_items_others]
    my_pars_others = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items_others,
        'year': my_years
    }
    df_liv_population_others = faostat.get_data_df(code, pars=my_pars_others, strval=False)

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Element', 'Item', 'Year', 'Value']
    df_liv_population = df_liv_population[columns_to_filter]
    df_liv_population_poultry = df_liv_population_poultry[columns_to_filter]
    df_liv_population_others = df_liv_population_others[columns_to_filter]

    # Creating one column with Item and Element
    #df_liv_population['Item'] = df_liv_population['Item'] + ' ' + df_liv_population['Element']
    df_liv_population = df_liv_population.drop(columns=['Element'])

    # Reading excel lsu equivalent
    df_lsu = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/lsu_equivalent.xlsx',
        sheet_name='lsu_equivalent_GLE')

    # Converting into lsu
    df_liv_population = pd.merge(df_liv_population, df_lsu, on='Item')
    df_liv_population['Value'] = df_liv_population['Value'] * df_liv_population['lsu']
    df_liv_population = df_liv_population.drop(columns=['lsu'])

    # Converting into lsu (other animals)
    df_liv_population_others = pd.merge(df_liv_population_others, df_lsu, on='Item')
    df_liv_population_others['Value'] = df_liv_population_others['Value'] * df_liv_population_others['lsu']
    df_liv_population_others = df_liv_population_others.drop(columns=['lsu'])

    # Aggregating for other animals
    df_liv_population_others = df_liv_population_others.groupby(['Area', 'Element', 'Year'], as_index=False)[
        'Value'].sum()
    # Prepend "Others" to each value in the 'Element' column
    df_liv_population_others['Element'] = df_liv_population_others['Element'].apply(lambda x: f"Others {x}")
    # Rename column
    df_liv_population_others.rename(
        columns={'Element': 'Item'}, inplace=True)

    # Converting into lsu (poultry)
    df_liv_population_poultry = pd.merge(df_liv_population_poultry, df_lsu, on='Item')
    df_liv_population_poultry['Value'] = df_liv_population_poultry['Value'] * df_liv_population_poultry['lsu']
    df_liv_population_poultry = df_liv_population_poultry.drop(columns=['lsu'])

    # Aggregating for poultry
    df_liv_population_poultry = df_liv_population_poultry.groupby(['Area', 'Element', 'Year'], as_index=False)[
        'Value'].sum()
    # Prepend "Poultry" to each value in the 'Element' column
    df_liv_population_poultry['Element'] = df_liv_population_poultry['Element'].apply(lambda x: f"Poultry {x}")
    # Rename column
    df_liv_population_poultry.rename(
        columns={'Element': 'Item'}, inplace=True)

    # Concatenating
    df_liv_population = pd.concat([df_liv_population, df_liv_population_others])
    df_liv_population = pd.concat([df_liv_population, df_liv_population_poultry])

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Food item name matching with dictionary
    # Read excel file
    df_dict_calibration = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='calibration')

    # Merge based on 'Item'
    df_liv_population_calibration = pd.merge(df_dict_calibration, df_liv_population, on='Item')

    # Drop the 'Item' column
    df_liv_population_calibration = df_liv_population_calibration.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_liv_population_calibration.rename(
        columns={'Area': 'geoscale', 'Year': 'timescale', 'Value': 'value'},
        inplace=True)

    # ----------------------------------------------------------------------------------------------------------------------
    # DOMESTIC PRODUCTION (CROP & LIVESTOCK PRODUCTS) ----------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------
    # Read data ------------------------------------------------------------------------------------------------------------

    # Common for all
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # FOOD BALANCE SHEETS (FBS) - -------------------------------------------------
    # List of elements
    list_elements = ['Domestic supply quantity']

    list_items = ['Cereals - Excluding Beer + (Total)', 'Fruits - Excluding Wine + (Total)', 'Oilcrops + (Total)',
                  'Pulses + (Total)', 'Rice (Milled Equivalent)',
                  'Starchy Roots + (Total)', 'Sugar Crops + (Total)', 'Vegetables + (Total)',
                  'Milk - Excluding Butter + (Total)', 'Eggs + (Total)',
                  'Bovine Meat', 'Meat, Other', 'Pigmeat',
                  'Poultry Meat', 'Mutton & Goat Meat']

    # 1990 - 2013
    ld = faostat.list_datasets()
    code = 'FBSH'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002',
                  '2003', '2004', '2005', '2006', '2007', '2008', '2009']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_domestic_supply_1990_2013 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # 2010-2022
    list_items = ['Cereals - Excluding Beer + (Total)', 'Fruits - Excluding Wine + (Total)', 'Oilcrops + (Total)',
                  'Pulses + (Total)', 'Rice and products',
                  'Starchy Roots + (Total)', 'Sugar Crops + (Total)', 'Vegetables + (Total)',
                  'Milk - Excluding Butter + (Total)', 'Eggs + (Total)',
                  'Bovine Meat', 'Meat, Other', 'Pigmeat',
                  'Poultry Meat', 'Mutton & Goat Meat']
    code = 'FBS'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021',
                  '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_domestic_supply_2010_2022 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Renaming the items for name matching
    df_domestic_supply_1990_2013.loc[
        df_domestic_supply_1990_2013['Item'].str.contains('Rice \(Milled Equivalent\)', case=False,
                                               na=False), 'Item'] = 'Rice and products'

    # Concatenating all the years together
    df_domestic_supply = pd.concat([df_domestic_supply_1990_2013, df_domestic_supply_2010_2022])

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Element', 'Item', 'Year', 'Value']
    df_domestic_supply = df_domestic_supply[columns_to_filter]

    # Pivot the df
    pivot_df_domestic_supply = df_domestic_supply.pivot_table(index=['Area', 'Year', 'Item'], columns='Element',
                                        values='Value').reset_index()

    # Unit conversion [kt] => [t]
    pivot_df_domestic_supply['Domestic supply quantity [t]'] = 1000 * pivot_df_domestic_supply['Domestic supply quantity']

    # Unit conversion [t] => [kcal]
    # Read excel
    df_kcal_t = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/kcal_to_t.xlsx',
        sheet_name='kcal_per_100g')
    df_kcal_t = df_kcal_t[['Item', 'kcal per t']]
    # Merge
    merged_df = pd.merge(
        df_kcal_t,
        pivot_df_domestic_supply,  # Only keep the needed columns
        on=['Item']
    )
    # Operation
    merged_df['Domestic supply quantity [kcal]'] = merged_df['Domestic supply quantity [t]'] * merged_df['kcal per t']
    pivot_df_domestic_supply = merged_df[['Area', 'Year', 'Item', 'Domestic supply quantity [kcal]']]
    pivot_df_domestic_supply = pivot_df_domestic_supply.copy()

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Food item name matching with dictionary
    # Read excel file
    df_dict_calibration = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='calibration')

    # Prepend "Diet" to each value in the 'Item' column
    pivot_df_domestic_supply['Item'] = pivot_df_domestic_supply['Item'].apply(lambda x: f"Domestic Supply {x}")

    # Renaming existing columns (geoscale, timsecale, value)
    pivot_df_domestic_supply.rename(
        columns={'Area': 'geoscale', 'Year': 'timescale', 'Domestic supply quantity [kcal]': 'value'},
        inplace=True)

    # Concat with energy demand
    df_supply_and_energy = pd.concat([pivot_df_domestic_supply, df_energy_demand_cal])

    # Merge based on 'Item'
    df_domestic_supply_calibration = pd.merge(df_dict_calibration, df_supply_and_energy, on='Item')

    # Drop the 'Item' column
    df_domestic_supply_calibration = df_domestic_supply_calibration.drop(columns=['Item'])

    return df_domestic_supply_calibration, df_liv_population_calibration



# CalculationLeaf CAL - LIVESTOCK MANURE -----------------------------------------------------------------------------------

def manure_calibration():
    # ----------------------------------------------------------------------------------------------------------------------
    # MANURE EMISSIONS ---------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------
    # Read data ------------------------------------------------------------------------------------------------------------

    # Common for all
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # EMISSIONS FROM LIVESTOCK (GLE) - -------------------------------------------------
    # List of elements
    list_elements = ['Enteric fermentation (Emissions CH4)', 'Manure management (Emissions CH4)',
                     'Manure management (Emissions N2O)', 'Manure left on pasture (Emissions N2O)',
                     'Emissions (N2O) (Manure applied)']

    list_items = ['Swine + (Total)','Sheep and Goats + (Total)', 'Cattle, dairy', 'Cattle, non-dairy', 'Chickens, layers']

    list_items_poultry = ['Chickens, broilers', 'Ducks', 'Turkeys']

    list_items_others = ['Asses', 'Buffalo','Camels', 'Horses', 'Llamas', 'Mules and hinnies']

    # 1990 - 2022
    ld = faostat.list_datasets()
    code = 'GLE'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021','2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_liv_emissions = faostat.get_data_df(code, pars=my_pars, strval=False)

    my_items_poultry = [faostat.get_par(code, 'item')[i] for i in list_items_poultry]
    my_pars_poultry = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items_poultry,
        'year': my_years
    }
    df_liv_emissions_poultry = faostat.get_data_df(code, pars=my_pars_poultry, strval=False)

    my_items_others = [faostat.get_par(code, 'item')[i] for i in list_items_others]
    my_pars_others = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items_others,
        'year': my_years
    }
    df_liv_emissions_others = faostat.get_data_df(code, pars=my_pars_others, strval=False)

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Element', 'Item', 'Year', 'Value']
    df_liv_emissions = df_liv_emissions[columns_to_filter]
    df_liv_emissions_poultry = df_liv_emissions_poultry[columns_to_filter]
    df_liv_emissions_others = df_liv_emissions_others[columns_to_filter]

    # Creating one column with Item and Element
    df_liv_emissions['Item'] = df_liv_emissions['Item'] + ' ' + df_liv_emissions['Element']
    df_liv_emissions = df_liv_emissions.drop(columns=['Element'])

    # Aggregating for other animals
    df_liv_emissions_others = df_liv_emissions_others.groupby(['Area', 'Element', 'Year'], as_index=False)['Value'].sum()
    # Prepend "Others" to each value in the 'Element' column
    df_liv_emissions_others['Element'] = df_liv_emissions_others['Element'].apply(lambda x: f"Others {x}")
    # Rename column
    df_liv_emissions_others.rename(
        columns={'Element': 'Item'}, inplace=True)

    # Aggregating for poultry
    df_liv_emissions_poultry = df_liv_emissions_poultry.groupby(['Area', 'Element', 'Year'], as_index=False)[
        'Value'].sum()
    # Prepend "Poultry" to each value in the 'Element' column
    df_liv_emissions_poultry['Element'] = df_liv_emissions_poultry['Element'].apply(lambda x: f"Poultry {x}")
    # Rename column
    df_liv_emissions_poultry.rename(
        columns={'Element': 'Item'}, inplace=True)

    # Concatenating
    df_liv_emissions = pd.concat([df_liv_emissions, df_liv_emissions_others])
    df_liv_emissions = pd.concat([df_liv_emissions, df_liv_emissions_poultry])

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Food item name matching with dictionary
    # Read excel file
    df_dict_calibration = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='calibration')

    # Merge based on 'Item'
    df_liv_emissions_calibration = pd.merge(df_dict_calibration, df_liv_emissions, on='Item')

    # Drop the 'Item' column
    df_liv_emissions_calibration = df_liv_emissions_calibration.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_liv_emissions_calibration.rename(
        columns={'Area': 'geoscale', 'Year': 'timescale', 'Value': 'value'},
        inplace=True)

    # Add empty rows for enteric poultry and hens eggs = 0
    # Hens egg
    df_to_duplicate = df_liv_emissions_calibration[df_liv_emissions_calibration['variables'] == 'cal_agr_liv_CH4-emission_abp-hens-egg_treated[kt]'].copy()
    # Modify the duplicated rows
    df_to_duplicate['value'] = 0  # Set value to 0
    df_to_duplicate['variables'] = 'cal_agr_liv_CH4-emission_abp-hens-egg_enteric[kt]'  # Rename variable
    # Append the new rows to the original DataFrame
    df_liv_emissions_calibration = pd.concat([df_liv_emissions_calibration, df_to_duplicate], ignore_index=True)
    # Poultry meat
    df_to_duplicate['variables'] = 'cal_agr_liv_CH4-emission_meat-poultry_enteric[kt]'  # Rename variable
    df_liv_emissions_calibration = pd.concat([df_liv_emissions_calibration, df_to_duplicate], ignore_index=True)

    return df_liv_emissions_calibration


# CalculationLeaf CAL - ENERGY & GHG -----------------------------------------------------------------------------------
def energy_ghg_calibration():
    # ----------------------------------------------------------------------------------------------------------------------
    # TOTAL GHG EMISSIONS ---------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------
    # Read data ------------------------------------------------------------------------------------------------------------

    # Common for all
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # EMISSIONS TOTAL (GT) - -------------------------------------------------
    # List of elements
    list_elements = ['Emissions (CH4)', 'Emissions (N2O)', 'Emissions (CO2)']

    list_items = ['-- Agrifood systems + (Total)']

    # 1990 - 2022
    ld = faostat.list_datasets()
    code = 'GT'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_emissions = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Element', 'Year', 'Value']
    df_emissions = df_emissions[columns_to_filter].copy()

    # Pivot the df
    df_emissions = df_emissions.pivot_table(index=['Area', 'Year', 'Element'],
                                          values='Value').reset_index()

    # Unit conversion [kt] => [t]
    df_emissions['Value'] = df_emissions['Value'] * 10**(3)

    # Rename column
    df_emissions.rename(columns={'Element': 'Item'}, inplace=True)

    # ----------------------------------------------------------------------------------------------------------------------
    # ENERGY DEMAND (electricity, gas, coal, heat) ---------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Read FAO Values (for Switzerland) --------------------------------------------------------------------------------------------
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # List of elements
    list_elements = ['Energy use in agriculture']

    list_items = ['Natural gas', 'Electricity', 'Coal', 'Heat']

    # 1990 - 2022
    ld = faostat.list_datasets()
    code = 'GN'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_energy_fao = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Item', 'Year', 'Value']
    df_energy_fao = df_energy_fao[columns_to_filter].copy()

    # Pivot the df
    df_energy_fao = df_energy_fao.pivot_table(index=['Area', 'Year', 'Item'],
                                                  values='Value').reset_index()

    # ----------------------------------------------------------------------------------------------------------------------
    # CO2 EMISSIONS FROM ENERGY USE ---------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Read FAO Values (for Switzerland) --------------------------------------------------------------------------------------------
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # List of elements
    list_elements = ['Emissions (CO2)']

    list_items = ['Total Energy + (Total)']

    # 1990 - 2022
    ld = faostat.list_datasets()
    code = 'GN'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_energy_use = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Item', 'Year', 'Value']
    df_energy_use = df_energy_use[columns_to_filter].copy()

    # Pivot the df
    df_energy_use = df_energy_use.pivot_table(index=['Area', 'Year', 'Item'],
                                              values='Value').reset_index()

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Food item name matching with dictionary
    # Read excel file
    df_dict_calibration = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='calibration')

    # Concat
    df_emissions = pd.concat([df_emissions, df_energy_fao])
    df_emissions = pd.concat([df_emissions, df_energy_use])

    # Merge based on 'Item'
    df_emissions_calibration = pd.merge(df_dict_calibration, df_emissions, on='Item')

    # Drop the 'Item' column
    df_emissions_calibration = df_emissions_calibration.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_emissions_calibration.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Value': 'value'},
                               inplace=True)

    return df_emissions_calibration


# CalculationLeaf CAL - NITROGEN -----------------------------------------------------------------------------------
def nitrogen_calibration():
    # ----------------------------------------------------------------------------------------------------------------------
    # TOTAL GHG EMISSIONS ---------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------
    # Read data ------------------------------------------------------------------------------------------------------------

    # Common for all
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # EMISSIONS TOTAL (GT) - -------------------------------------------------
    # List of elements
    list_elements = ['Emissions (N2O)']

    list_items = ['Synthetic Fertilizers']

    # 1990 - 2022
    ld = faostat.list_datasets()
    code = 'GT'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_nitrogen = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Element', 'Year', 'Value']
    df_nitrogen = df_nitrogen[columns_to_filter]

    # Pivot the df
    df_nitrogen = df_nitrogen.pivot_table(index=['Area', 'Year', 'Element'],
                                          values='Value').reset_index()

    # Unit conversion [kt] => [Mt]
    df_nitrogen['Value'] = df_nitrogen['Value'] * 10**(-3)

    # Rename column
    df_nitrogen.rename(columns={'Element': 'Item'}, inplace=True)

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Food item name matching with dictionary
    # Read excel file
    df_dict_calibration = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='calibration')

    # Prepend "Fertilizers" to each value in the 'Item' column
    df_nitrogen['Item'] = df_nitrogen['Item'].apply(lambda x: f"Fertilizers {x}")

    # Merge based on 'Item'
    df_nitrogen_calibration = pd.merge(df_dict_calibration, df_nitrogen, on='Item')

    # Drop the 'Item' column
    df_nitrogen_calibration = df_nitrogen_calibration.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_nitrogen_calibration.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Value':'value'},
                               inplace=True)

    return df_nitrogen_calibration

# CalculationLeaf CAL - FEED DEMAND ----------------------------------------------------------------------------------

def feed_calibration():
    # ----------------------------------------------------------------------------------------------------------------------
    # FEED DEMAND PART I --------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Read data ------------------------------------------------------------------------------------------------------------
    # Common for all
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # FOOD BALANCE SHEETS (FBS) - -------------------------------------------------
    # List of elements
    list_elements = ['Feed']

    list_items = ['Cereals - Excluding Beer + (Total)', 'Fruits - Excluding Wine + (Total)', 'Oilcrops + (Total)',
                  'Pulses + (Total)', 'Rice (Milled Equivalent)',
                  'Starchy Roots + (Total)', 'Sugar Crops + (Total)', 'Vegetables + (Total)',
                  'Fish, Seafood + (Total)', 'Animal Products + (Total)', 'Vegetable Oils + (Total)',
                  'Sugar & Sweeteners + (Total)']

    # 1990 - 2013
    ld = faostat.list_datasets()
    code = 'FBSH'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002',
                  '2003', '2004', '2005', '2006', '2007', '2008', '2009']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_feed_1990_2013 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # 2010-2022
    list_items = ['Cereals - Excluding Beer + (Total)', 'Fruits - Excluding Wine + (Total)', 'Oilcrops + (Total)',
                  'Pulses + (Total)', 'Rice and products',
                  'Starchy Roots + (Total)', 'Sugar Crops + (Total)', 'Vegetables + (Total)',
                  'Fish, Seafood + (Total)', 'Animal Products + (Total)', 'Vegetable Oils + (Total)',
                  'Sugar & Sweeteners + (Total)']
    code = 'FBS'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021',
                  '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_feed_2010_2022 = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Renaming the items for name matching
    df_feed_1990_2013.loc[
        df_feed_1990_2013['Item'].str.contains('Rice \(Milled Equivalent\)', case=False,
                                                          na=False), 'Item'] = 'Rice and products'

    # Concatenating all the years together
    df_feed = pd.concat([df_feed_1990_2013, df_feed_2010_2022])



    # ----------------------------------------------------------------------------------------------------------------------
    # FEED DEMAND PART II (molasse & cake) --------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # COMMODITY BALANCES (NON-FOOD) (OLD METHODOLOGY) - For molasse and cakes ----------------------------------------------
    # 1990 - 2013
    list_elements = ['Feed']
    list_items = ['Copra Cake', 'Cottonseed Cake', 'Groundnut Cake', 'Oilseed Cakes, Other', 'Palmkernel Cake',
                  'Rape and Mustard Cake', 'Sesameseed Cake', 'Soyabean Cake', 'Sunflowerseed Cake']
    code = 'CBH'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002',
                  '2003', '2004', '2005', '2006', '2007', '2008', '2009']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_feed_1990_2013_cake = faostat.get_data_df(code, pars=my_pars, strval=False)

    # SUPPLY UTILIZATION ACCOUNTS (SCl) - For molasse and cakes ----------------------------------------------------------
    # 2010 - 2022
    list_elements = ['Feed']
    list_items = ['Molasses', 'Cake of  linseed', 'Cake of  soya beans', 'Cake of copra', 'Cake of cottonseed',
                  'Cake of groundnuts', 'Cake of hempseed', 'Cake of kapok', 'Cake of maize', 'Cake of mustard seed',
                  'Cake of palm kernel', 'Cake of rapeseed', 'Cake of rice bran', 'Cake of safflowerseed',
                  'Cake of sesame seed', 'Cake of sunflower seed', 'Cake, oilseeds nes', 'Cake, poppy seed',
                  'Cocoa powder and cake']
    code = 'SCL'
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_feed_2010_2021_molasse_cake = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Aggregating cakes
    df_feed_cake = pd.concat([df_feed_1990_2013_cake, df_feed_2010_2021_molasse_cake])
    # Filtering
    filtered_df = df_feed_cake[df_feed_cake['Item'].str.contains('cake', case=False)]
    # Groupby Area, Year and Element and sum the Value
    grouped_df = filtered_df.groupby(['Area', 'Element', 'Year'])['Value'].sum().reset_index()
    # Unit conversion [t] => [kt]
    grouped_df['Value'] = grouped_df['Value'] / 1000
    # Adding a column 'Item' containing 'Cakes' for all row, before the 'Value' column
    grouped_df['Item'] = 'Cakes'
    cols = grouped_df.columns.tolist()
    cols.insert(cols.index('Value'), cols.pop(cols.index('Item')))
    df_feed_cake = grouped_df[cols]

    # Filtering for molasse
    df_feed_molasses = df_feed_2010_2021_molasse_cake[
        df_feed_2010_2021_molasse_cake['Item'].str.contains('Molasses', case=False)]
    df_feed_molasses = df_feed_molasses.copy()

    # Unit conversion [t] => [kt]
    df_feed_molasses['Value'] = df_feed_molasses['Value'] / 1000

    # Concatenating
    df_feed = pd.concat([df_feed, df_feed_molasses])
    df_feed = pd.concat([df_feed, df_feed_cake])

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Element', 'Item', 'Year', 'Value']
    df_feed = df_feed[columns_to_filter]

    # Pivot the df
    pivot_df_feed = df_feed.pivot_table(index=['Area', 'Year', 'Item'], columns='Element',
                                        values='Value').reset_index()

    # Univ conversion [kt] => [kcal]
    # Read excel
    df_kcal_t = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/kcal_to_t.xlsx',
        sheet_name='kcal_per_100g')
    df_kcal_t = df_kcal_t[['Item', 'kcal per t']]
    # Merge
    merged_df = pd.merge(
        df_kcal_t,
        pivot_df_feed,
    )
    # Operation
    merged_df['Feed [kcal]'] = 1000 * merged_df['Feed'] * merged_df['kcal per t']
    pivot_df_feed = merged_df[['Area', 'Year', 'Item', 'Feed [kcal]']]
    pivot_df_feed = pivot_df_feed.copy()

    # Adding meat products with 0 everywhere (no meat used as feed from FAOSTAT)
    duplicated_rows = pivot_df_feed[
        pivot_df_feed['Item'] == 'Pulses'].copy()  # Duplicate rows for random item
    duplicated_rows['Item'] = 'Animal Products'  # Change geoscale value to 'EU27' in duplicated rows
    duplicated_rows['Feed [kcal]'] = 0 # Set the value to 0
    pivot_df_feed = pd.concat([pivot_df_feed, duplicated_rows],
                                   ignore_index=True)  # Append duplicated rows back to the original DataFrame

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Food item name matching with dictionary
    # Read excel file
    df_dict_calibration = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='calibration')

    # Prepend "Diet" to each value in the 'Item' column
    pivot_df_feed['Item'] = pivot_df_feed['Item'].apply(lambda x: f"Feed {x}")

    # Merge based on 'Item'
    df_feed_calibration = pd.merge(df_dict_calibration, pivot_df_feed, on='Item')

    # Drop the 'Item' column
    df_feed_calibration = df_feed_calibration.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timesecale, value)
    df_feed_calibration.rename(
        columns={'Area': 'geoscale', 'Year': 'timescale', 'Feed [kcal]': 'value'},
        inplace=True)

    return df_feed_calibration

# CalculationLeaf CAL - LAND -----------------------------------------------------------------------------------

def land_calibration():
    # Read FAO Values (for Switzerland) --------------------------------------------------------------------------------------------
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # List of elements
    list_elements = ['Area']

    list_items = ['-- Cropland', '-- Permanent meadows and pastures']

    # 1990 - 2022
    ld = faostat.list_datasets()
    code = 'RL'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_land_use_fao = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Item', 'Year', 'Value']
    df_land_use_fao = df_land_use_fao[columns_to_filter]

    # Pivot the df
    df_land_use_fao = df_land_use_fao.pivot_table(index=['Area', 'Year', 'Item'],
                                          values='Value').reset_index()

    # Unit conversion [k ha] => [ha]
    df_land_use_fao['Value'] = df_land_use_fao['Value'] * 1000

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Food item name matching with dictionary
    # Read excel file
    df_dict_calibration = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='calibration')

    # Prepend "Fertilizers" to each value in the 'Item' column
    df_land_use_fao['Item'] = df_land_use_fao['Item'].apply(lambda x: f"Land {x}")

    # Merge based on 'Item'
    df_land_use_fao_calibration = pd.merge(df_dict_calibration, df_land_use_fao, on='Item')

    # Drop the 'Item' column
    df_land_use_fao_calibration = df_land_use_fao_calibration.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_land_use_fao_calibration.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Value':'value'},
                                   inplace=True)

    return df_land_use_fao_calibration

# CalculationLeaf CAL - LIMING & UREA CO2 EMISSIONS -----------------------------------------------------------------------------------

def CO2_emissions():
    # ----------------------------------------------------------------------------------------------------------------------
    # LIMING & URA CO2 EMISSIONS ----------------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Importing UNFCCC excel files and reading them with a loop (only for Switzerland) Table 4.1 ---------------------------
    # Putting in a df in 3 dimensions (from, to, year)
    # Define the path where the Excel files are located
    folder_path = '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/data/data_unfccc_2023'

    # List all files in the folder
    files = os.listdir(folder_path)

    # Filter and sort files by the year (1990 to 2020)
    sorted_files = sorted([f for f in files if f.startswith('CHE_2023_') and int(f.split('_')[2]) in range(1990, 2021)],
                          key=lambda x: int(x.split('_')[2]))

    # Initialize a list to store DataFrames
    data_frames = []

    # Loop through sorted files, read the required rows, and append to the list
    for file in sorted_files:
        # Extract the year from the filename
        year = int(file.split('_')[2])

        # Full path to the file
        file_path = os.path.join(folder_path, file)

        # Read the specific rows and sheet from the Excel file
        df = pd.read_excel(file_path, sheet_name='Table3s2', skiprows=10, nrows=2, header=None)

        # Add a column for the year to the DataFrame
        df['Year'] = year

        # Append to the list of DataFrames
        data_frames.append(df)

    # Combine all DataFrames into a single DataFrame with a multi-index
    combined_df = pd.concat(data_frames, axis=0).set_index(['Year'])

    # Filter the second and third columns (index 1 and 2)
    df_liming_urea = combined_df.iloc[:, [0, 1]]

    # Rename the columns to 'Year' and 'Item'
    df_liming_urea.columns = ['Item', 'Value']

    # Reset the index and rename it to 'Year'
    df_liming_urea = df_liming_urea.reset_index()
    df_liming_urea.rename(columns={'index': 'Year'}, inplace=True)



    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Food item name matching with dictionary
    # Read excel file
    df_dict_calibration = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='calibration')

    # Adding a column geoscale
    df_liming_urea['geoscale'] = 'Switzerland'

    # Prepend "Diet" to each value in the 'Item' column
    #df_liming_urea['Item'] = df_liming_urea['Item'].apply(lambda x: f"Diet {x}")

    # Merge based on 'Item'
    df_liming_urea_calibration = pd.merge(df_dict_calibration, df_liming_urea, on='Item')

    # Drop the 'Item' column
    df_liming_urea_calibration = df_liming_urea_calibration.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_liming_urea_calibration.rename(
        columns={'Area': 'geoscale', 'Year': 'timescale', 'Value': 'value'}, inplace=True)

    return df_liming_urea_calibration


# CalculationLeaf CAL - WOOD ------------------------------

def wood_calibration():
    # ----------------------------------------------------------------------------------------------------------------------
    # WOOD DEMAND ---------------------------------------------------------------------------------------------------
    # ----------------------------------------------------------------------------------------------------------------------

    # Read FAO Values (for Switzerland) --------------------------------------------------------------------------------------------
    # List of countries
    list_countries = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark',
                      'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia',
                      'Lithuania', 'Luxembourg', 'Malta', 'Netherlands (Kingdom of the)', 'Poland', 'Portugal',
                      'Romania', 'Slovakia',
                      'Slovenia', 'Spain', 'Sweden', 'Switzerland',
                      'United Kingdom of Great Britain and Northern Ireland']

    # List of elements
    list_elements = ['Production Quantity']

    list_items = ['Wood fuel + (Total)', 'Industrial roundwood + (Total)',
                  'Pulpwood, round and split (production) + (Total)', 'Sawlogs and veneer logs + (Total)']

    # 1990 - 2022
    ld = faostat.list_datasets()
    code = 'FO'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_wood = faostat.get_data_df(code, pars=my_pars, strval=False)

    # 1990 - 2022 ROUNDWOOD
    list_items = ['Roundwood + (Total)']
    ld = faostat.list_datasets()
    code = 'FO'
    pars = faostat.list_pars(code)
    my_countries = [faostat.get_par(code, 'area')[c] for c in list_countries]
    my_elements = [faostat.get_par(code, 'elements')[e] for e in list_elements]
    my_items = [faostat.get_par(code, 'item')[i] for i in list_items]
    list_years = ['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001',
                  '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
                  '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022']
    my_years = [faostat.get_par(code, 'year')[y] for y in list_years]

    my_pars = {
        'area': my_countries,
        'element': my_elements,
        'item': my_items,
        'year': my_years
    }
    df_roundwood = faostat.get_data_df(code, pars=my_pars, strval=False)

    # Concatenating dfs
    df_wood = pd.concat([df_wood, df_roundwood], axis=0)

    # Filtering to keep wanted columns
    columns_to_filter = ['Area', 'Item', 'Year', 'Value']
    df_wood = df_wood[columns_to_filter]

    # Pivot the df
    df_wood = df_wood.pivot_table(index=['Area', 'Year', 'Item'],
                                              values='Value').reset_index()

    # PathwayCalc formatting -----------------------------------------------------------------------------------------------
    # Food item name matching with dictionary
    # Read excel file
    df_dict_calibration = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/dictionaries/dictionnary_agriculture_landuse.xlsx',
        sheet_name='calibration')

    # Merge based on 'Item'
    df_wood_calibration = pd.merge(df_dict_calibration, df_wood, on='Item')

    # Drop the 'Item' column
    df_wood_calibration = df_wood_calibration.drop(columns=['Item'])

    # Renaming existing columns (geoscale, timsecale, value)
    df_wood_calibration.rename(columns={'Area': 'geoscale', 'Year': 'timescale', 'Value': 'value'},
                                    inplace=True)

    return df_wood_calibration

# CalculationLeaf CALIBRATION FORMATTING
def calibration_formatting(df_diet_calibration, df_domestic_supply_calibration, df_liv_population_calibration,
                     df_nitrogen_calibration, df_liv_emissions_calibration, df_feed_calibration,
                     df_land_use_fao_calibration, df_liming_urea_calibration, df_wood_calibration,
                     df_emissions_calibration):

    # AGRICULTURE MODULE -----------------------------------------------------------------------------------------------

    # Concatenate dfs
    df_calibration = pd.concat([df_diet_calibration, df_domestic_supply_calibration], axis=0)
    df_calibration = pd.concat([df_calibration, df_liv_population_calibration], axis=0)
    df_calibration = pd.concat([df_calibration, df_nitrogen_calibration], axis=0)
    df_calibration = pd.concat([df_calibration, df_liv_emissions_calibration], axis=0)
    df_calibration = pd.concat([df_calibration, df_feed_calibration], axis=0)
    df_calibration = pd.concat([df_calibration, df_land_use_fao_calibration], axis=0)
    df_calibration = pd.concat([df_calibration, df_liming_urea_calibration], axis=0)
    #df_calibration = pd.concat([df_calibration, df_wood_calibration], axis=0)
    df_calibration = pd.concat([df_calibration, df_emissions_calibration], axis=0)

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_calibration['module'] = 'agriculture'
    df_calibration['lever'] = 'none'
    df_calibration['level'] = 0
    cols = df_calibration.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_calibration = df_calibration[cols]

    # Rename countries to Pathaywcalc name
    df_calibration['geoscale'] = df_calibration['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_calibration['geoscale'] = df_calibration['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                                'Netherlands')
    df_calibration['geoscale'] = df_calibration['geoscale'].replace('Czechia', 'Czech Republic')

    # Change data type of timescale to int
    df_calibration["timescale"] = pd.to_numeric(df_calibration["timescale"], errors="coerce")

    # Extrapolation for missing data
    df_calibration_struct = ensure_structure(df_calibration)
    df_calibration_ext = linear_fitting_ots_db(df_calibration_struct, years_ots,
                                                countries='all')

    # Filter to keep only data from 1990
    df_calibration_ext_agr = df_calibration_ext[df_calibration_ext["timescale"] >= 1990]

    # Exporting to csv
    df_calibration_ext_agr.to_csv('agriculture_calibration.csv', index=False)

    # LANDUSE MODULE ---------------------------------------------------------------------------------------------------
    # Concatenate dfs
    df_calibration = df_wood_calibration

    # Adding the columns module, lever, level and string-pivot at the correct places
    df_calibration['module'] = 'land-use'
    df_calibration['lever'] = 'none'
    df_calibration['level'] = 0
    cols = df_calibration.columns.tolist()
    cols.insert(cols.index('value'), cols.pop(cols.index('module')))
    cols.insert(cols.index('value'), cols.pop(cols.index('lever')))
    cols.insert(cols.index('value'), cols.pop(cols.index('level')))
    df_calibration = df_calibration[cols]

    # Rename countries to Pathaywcalc name
    df_calibration['geoscale'] = df_calibration['geoscale'].replace(
        'United Kingdom of Great Britain and Northern Ireland', 'United Kingdom')
    df_calibration['geoscale'] = df_calibration['geoscale'].replace('Netherlands (Kingdom of the)',
                                                                                'Netherlands')
    df_calibration['geoscale'] = df_calibration['geoscale'].replace('Czechia', 'Czech Republic')

    # Extrapolation for missing data
    df_calibration_struct = ensure_structure(df_calibration)
    df_calibration_ext = linear_fitting_ots_db(df_calibration_struct, years_ots,
                                                countries='all')
    df_calibration_ext_landuse = df_calibration_ext[df_calibration_ext["timescale"] >= 1990]

    # Exporting to csv
    df_calibration_ext_landuse.to_csv('land-use_calibration.csv', index=False)


    return df_calibration_ext_agr

# CalculationLeaf FXA FORMATTING
def fxa_preprocessing():

    # Load FXA data
    df_fxa = pd.read_csv(
        '/Users/crosnier/Documents/PathwayCalc/_database/data/csv/agriculture_fixed-assumptions.csv',
        sep=';')

    # Add fxa_ in front of lus_land_total-area[ha]
    df_fxa['eucalc-name'] = df_fxa['eucalc-name'].replace('lus_land_total-area[ha]', 'fxa_lus_land_total-area[ha]')

    # Extract fxa list we need for Agriculture & Land Use
    df_ref = pd.read_excel(
        '/Users/crosnier/Documents/PathwayCalc/_database/agriculture_land-use_references.xlsx',
        sheet_name='references_agriculture')
    df_ref_fxa = df_ref[df_ref['level'] =='fxa'].copy()

    # Reformat according to new format
    df_fxa = df_fxa.drop(columns=['string-pivot', 'type-prefix', 'element', 'item', 'unit', 'reference-id', 'interaction-file', 'module-prefix'])
    df_fxa.rename(columns={'eucalc-name': 'variables'}, inplace=True)

    # Filter those we need for Agriculture & Land Use
    df_fxa_pathwaycalc = df_fxa[df_fxa['variables'].isin(df_ref_fxa['variables'])]

    # Extrapolate
    df_fxa_pathwaycalc = ensure_structure(df_fxa_pathwaycalc)
    df_fxa_pathwaycalc = linear_fitting_ots_db(df_fxa_pathwaycalc, years_ots, countries='all')

    # Export as csv
    df_fxa_pathwaycalc.to_csv('/Users/crosnier/Documents/PathwayCalc/_database/data/csv/agriculture_fixed-assumptions_pathwaycalc.csv', sep=';', index=False)

    return


# CalculationLeaf Pickle creation
#  FIXME only Switzerland for now
def init_years_lever():
    # function that can be used when running the module as standalone to initialise years and levers
    years_setting = [1990, 2023, 2025, 2050, 5]
    f = open('/Users/crosnier/Documents/PathwayCalc/config/lever_position.json')
    lever_setting = json.load(f)[0]
    return years_setting, lever_setting
def database_from_csv_to_datamatrix():
    #############################################
    ##### database_from_csv_to_datamatrix() #####
    #############################################

    years_setting, lever_setting = init_years_lever()

    # Set years range
    startyear = years_setting[0]
    baseyear = years_setting[1]
    lastyear = years_setting[2]
    start_fts = years_setting[2]
    stop_fts = years_setting[3]
    step_fts = years_setting[4]
    years_ots = list(np.linspace(start=startyear, stop=baseyear, num=(baseyear-startyear)+1).astype(int)) # make list with years from 1990 to 2015
    years_fts = list(np.arange(start_fts, stop_fts + 1, step_fts)) # make list with years from 2020 to 2050 (steps of 5 years)
    years_all = years_ots + years_fts

    # FixedAssumptionsToDatamatrix

    file = '../../data/datamatrix/agriculture.pickle'
    with open(file, 'rb') as handle:
        DM_agriculture_old = pickle.load(handle)

    for key in DM_agriculture_old['fxa'].keys():
        if 'cal_' in key:
            DM_agriculture_old['fxa'][key].filter({'Years': years_ots})
        else:
            dm = DM_agriculture_old['fxa'][key].copy()
            DM_agriculture_old['fxa'][key] = linear_fitting(dm, years_ots)
            DM_agriculture_old['fxa'][key].filter({'Years': years_ots + years_fts})

    dm = DM_agriculture_old['fxa']['lus_land_total-area']
    if 'lus_land_total-area' in dm.col_labels['Variables']:
        dm.rename_col('lus_land_total-area', 'fxa_lus_land_total-area', dim='Variables')
    DM_agriculture_old['fxa']['lus_land_total-area'] = dm

    # LeversToDatamatrix FTS based on EuCalc fts
    dm_fts = DM_agriculture_old['fts'].copy()

    # Filter dm_fts to start year at 2025 not 2020
    filter_years_DM(dm_fts, years_fts)

    # To remove '_' at the ending of some keys as the ones for diet
    for key in dm_fts.keys():
        if isinstance(dm_fts[key], dict):  # Check if the value is a dictionary
            new_dict = {}
            for sub_key, value in dm_fts[key].items():
                # Ensure the key is a string before modifying it
                new_key = sub_key.rstrip('_') if isinstance(sub_key, str) else sub_key
                new_dict[new_key] = value  # Assign value to the new key
            dm_fts[key] = new_dict  # Replace the original dictionary


    #file = 'agriculture_fixed-assumptions_pathwaycalc'
    #lever = 'none'
    #edit_database(file, lever, column='eucalc-name', mode='rename',pattern={'meat_': 'meat-', 'abp_': 'abp-'})
    #edit_database(file, lever, column='eucalc-name', mode='rename',pattern={'_rem_': '_', '_to_': '_', 'land-man_ef': 'fxa_land-man_ef'})
    #edit_database(file, lever, column='eucalc-name', mode='rename',pattern={'land-man_soil-type': 'fxa_land-man_soil-type'})
    #edit_database(file, lever, column='eucalc-name', mode='rename',pattern={'_def_': '_def-', '_gstock_': '_gstock-', '_nat-losses_': '_nat-losses-'})
    # AGRICULTURE ------------------------------------------------------------------------------------------------------
    # LIVESTOCK MANURE - N2O emissions
    #df = read_database_fxa(file, filter_dict={'variables': 'fxa_ef_liv_N2O-emission_ef.*'})
    #dm_ef_N2O = DataMatrix.create_from_df(df, num_cat=2)
    #dict_fxa['ef_liv_N2O-emission'] = dm_ef_N2O
    # LIVESTOCK MANURE - CH4 emissions
    """df = read_database_fxa(file, filter_dict={'variables': 'ef_liv_CH4-emission_treated.*'})
    dm_ef_CH4 = DataMatrix.create_from_df(df, num_cat=1)
    dict_fxa['ef_liv_CH4-emission_treated'] = dm_ef_CH4
    # LIVESTOCK MANURE - N stock
    df = read_database_fxa(file, filter_dict={'variables': 'liv_manure_n-stock.*'})
    dm_nstock = DataMatrix.create_from_df(df, num_cat=1)
    dict_fxa['liv_manure_n-stock'] = dm_nstock
    # CROP PRODUCTION - Burnt residues emission
    df = read_database_fxa(file, filter_dict={'variables': 'ef_burnt-residues.*'})
    dm_ef_burnt = DataMatrix.create_from_df(df, num_cat=1)
    dict_fxa['ef_burnt-residues'] = dm_ef_burnt
    # CROP PRODUCTION - Soil residues emission
    df = read_database_fxa(file, filter_dict={'variables': 'ef_soil-residues.*'})
    dm_ef_soil = DataMatrix.create_from_df(df, num_cat=1)
    dict_fxa['ef_soil-residues'] = dm_ef_soil
    # CROP PRODUCTION - Residue yield
    df = read_database_fxa(file, filter_dict={'variables': 'residues_yield.*'})
    dm_residues_yield = DataMatrix.create_from_df(df, num_cat=1)
    dict_fxa['residues_yield'] = dm_residues_yield
    # LAND - Fibers domestic-self-sufficiency
    df = read_database_fxa(file, filter_dict={'variables': 'domestic-self-sufficiency_fibres-plant-eq'})
    dm_fibers = DataMatrix.create_from_df(df, num_cat=0)
    dict_fxa['domestic-self-sufficiency_fibres-plant-eq'] = dm_fibers
    # LAND - Fibers domestic supply quantity
    df = read_database_fxa(file, filter_dict={'variables': 'domestic-supply-quantity_fibres-plant-eq'})
    dm_fibers_sup = DataMatrix.create_from_df(df, num_cat=0)
    dict_fxa['domestic-supply-quantity_fibres-plant-eq'] = dm_fibers_sup
    dm_fibers.append(dm_fibers_sup, dim='Variables')
    # LAND - Emission crop rice
    df = read_database_fxa(file, filter_dict={'variables': 'emission_crop_rice'})
    dm_rice = DataMatrix.create_from_df(df, num_cat=0)
    dict_fxa['emission_crop_rice'] = dm_rice
    # NITROGEN BALANCE - Emission fertilizer
    df = read_database_fxa(file, filter_dict={'variables': 'agr_emission_fertilizer'})
    dm_n_fertilizer = DataMatrix.create_from_df(df, num_cat=0)
    dict_fxa['agr_emission_fertilizer'] = dm_n_fertilizer


    # LAND USE --------------------------------------------------------------------------------------------------------
    # LAND ALLOCATION - Total area
    df = read_database_fxa(file, filter_dict={'variables': 'lus_land_total-area'})
    dm_land_total = DataMatrix.create_from_df(df, num_cat=0)
    dict_fxa['lus_land_total-area'] = dm_land_total
    # CARBON STOCK - c-stock biomass & soil
    df = read_database_fxa(file, filter_dict={'variables': 'land-man_ef'})
    dm_ef_biomass = DataMatrix.create_from_df(df, num_cat=0)
    dict_fxa['land-man_ef'] = dm_ef_biomass
    # CARBON STOCK - soil type
    df = read_database_fxa(file, filter_dict={'variables': 'land-man_soil-type'})
    dm_soil = DataMatrix.create_from_df(df, num_cat=0)
    dict_fxa['land-man_soil-type'] = dm_soil
    # AGROFORESTRY CROP - emission factors
    df = read_database_fxa(file, filter_dict={'variables': 'agr_climate-smart-crop_ef_agroforestry'})
    dm_crop_ef_agroforestry = DataMatrix.create_from_df(df, num_cat=1)
    dict_fxa['agr_climate-smart-crop_ef_agroforestry'] = dm_crop_ef_agroforestry
    # AGROFORESTRY livestock - emission factors
    df = read_database_fxa(file, filter_dict={'variables': 'agr_climate-smart-livestock_ef_agroforestry'})
    dm_livestock_ef_agroforestry = DataMatrix.create_from_df(df, num_cat=1)
    dict_fxa['agr_climate-smart-livestock_ef_agroforestry'] = dm_livestock_ef_agroforestry
    # AGROFORESTRY Forestry - natural losses & others
    df = read_database_fxa(file, filter_dict={'variables': 'agr_climate-smart-forestry'})
    dm_agroforestry = DataMatrix.create_from_df(df, num_cat=1)
    dict_fxa['agr_climate-smart-forestry'] = dm_agroforestry"""

    # file
    __file__ = "/Users/crosnier/Documents/PathwayCalc/_database/pre_processing/agriculture & land use/agriculture_landuse_preprocessing_EU.py"

    # directories
    current_file_directory = os.path.dirname(os.path.abspath(__file__))

    # CalibrationDataToDatamatrix

    dict_fxa = {}
    # Data - Calibration
    #file = '/Users/crosnier/Documents/PathwayCalc/_database/data/csv/agriculture_calibration.csv'
    lever = 'none'
    #df_db = pd.read_csv(file)
    df_ots, df_fts = database_to_df(df_calibration, lever, level='all')
    df_ots = df_ots.drop(columns=['none']) # Drop column 'none'
    dm_cal = DataMatrix.create_from_df(df_ots, num_cat=0)

    # Data - Fixed assumptions - Calibration factors - Diet
    dm_cal_diet = dm_cal.filter_w_regex({'Variables': 'cal_agr_diet.*'})
    dm_cal_diet.deepen(based_on='Variables')
    dict_fxa['cal_diet'] = dm_cal_diet

    # Data - Fixed assumptions - Calibration factors - Food waste
    #dm_cal_food_waste = dm_cal.filter_w_regex({'Variables': 'cal_agr_food-wastes.*'})
    #dm_cal_food_waste.deepen(based_on='Variables')
    #dict_fxa['cal_food_waste'] = dm_cal_food_waste

    # Data - Fixed assumptions - Calibration factors - Livestock domestic production
    dm_cal_liv_dom_prod = dm_cal.filter_w_regex({'Variables': 'cal_agr_domestic-production-liv.*'})
    dm_cal_liv_dom_prod.deepen(based_on='Variables')
    dict_fxa['cal_agr_domestic-production-liv'] = dm_cal_liv_dom_prod

    # Data - Fixed assumptions - Calibration factors - Livestock population
    dm_cal_liv_pop = dm_cal.filter_w_regex({'Variables': 'cal_agr_liv-population.*'})
    dm_cal_liv_pop.deepen(based_on='Variables')
    dict_fxa['cal_agr_liv-population'] = dm_cal_liv_pop

    # Data - Fixed assumptions - Calibration factors - Livestock CH4 emissions
    dm_cal_liv_CH4 = dm_cal.filter_w_regex({'Variables': 'cal_agr_liv_CH4-emission.*'})
    dm_cal_liv_CH4.deepen(based_on='Variables')
    dm_cal_liv_CH4.deepen(based_on='Variables')
    dict_fxa['cal_agr_liv_CH4-emission'] = dm_cal_liv_CH4

    # Data - Fixed assumptions - Calibration factors - Livestock N2O emissions
    dm_cal_liv_N2O = dm_cal.filter_w_regex({'Variables': 'cal_agr_liv_N2O-emission.*'})
    dm_cal_liv_N2O.deepen(based_on='Variables')
    dm_cal_liv_N2O.deepen(based_on='Variables')
    dict_fxa['cal_agr_liv_N2O-emission'] = dm_cal_liv_N2O

    # Data - Fixed assumptions - Calibration factors - Feed demand
    dm_cal_feed = dm_cal.filter_w_regex({'Variables': 'cal_agr_demand_feed.*'})
    dm_cal_feed.deepen(based_on='Variables')
    dict_fxa['cal_agr_demand_feed'] = dm_cal_feed

    # Data - Fixed assumptions - Calibration factors - Crop production
    dm_cal_crop = dm_cal.filter_w_regex({'Variables': 'cal_agr_domestic-production_food.*'})
    dm_cal_crop.deepen(based_on='Variables')
    dict_fxa['cal_agr_domestic-production_food'] = dm_cal_crop

    # Data - Fixed assumptions - Calibration factors - Land
    dm_cal_land = dm_cal.filter_w_regex({'Variables': 'cal_agr_lus_land.*'})
    dm_cal_land.deepen(based_on='Variables')
    dict_fxa['cal_agr_lus_land'] = dm_cal_land

    # Data - Fixed assumptions - Calibration factors - Nitrogen balance
    dm_cal_n = dm_cal.filter_w_regex({'Variables': 'cal_agr_crop_emission_N2O-emission_fertilizer.*'})
    dict_fxa['cal_agr_crop_emission_N2O-emission_fertilizer'] = dm_cal_n

    # Data - Fixed assumptions - Calibration factors - Energy demand for agricultural land
    dm_cal_energy_demand = dm_cal.filter_w_regex({'Variables': 'cal_agr_energy-demand.*'})
    dm_cal_energy_demand.deepen(based_on='Variables')
    dict_fxa['cal_agr_energy-demand'] = dm_cal_energy_demand

    # Data - Fixed assumptions - Calibration factors - Agricultural emissions total (CH4, N2O, CO2)
    dm_cal_CH4 = dm_cal.filter_w_regex({'Variables': 'cal_agr_emissions-CH4'})
    dict_fxa['cal_agr_emissions_CH4'] = dm_cal_CH4
    dm_cal_N2O = dm_cal.filter_w_regex({'Variables': 'cal_agr_emissions-N2O'})
    dict_fxa['cal_agr_emissions_N2O'] = dm_cal_N2O
    dm_cal_CO2 = dm_cal.filter_w_regex({'Variables': 'cal_agr_emissions-CO2'})
    dict_fxa['cal_agr_emissions_CO2'] = dm_cal_CO2

    # Data - Fixed assumptions - Calibration factors - CO2 emissions (fuel, liming, urea)
    dm_cal_input = dm_cal.filter_w_regex({'Variables': 'cal_agr_input-use_emissions-CO2.*'})
    dm_cal_input.deepen(based_on='Variables')
    dict_fxa['cal_agr_input-use_emissions-CO2'] = dm_cal_input

    # Create a dictionnay with all the fixed assumptions (only for calibration since the other comes from pickle)
    """dict_fxa = {
        'cal_agr_diet': dm_cal_diet,
        'cal_agr_domestic-production-liv': dm_cal_liv_dom_prod,
        'cal_agr_liv-population': dm_cal_liv_pop,
        'cal_agr_liv_CH4-emission': dm_cal_liv_CH4,
        'cal_agr_liv_N2O-emission': dm_cal_liv_N2O,
        'cal_agr_domestic-production_food': dm_cal_crop,
        'cal_agr_demand_feed': dm_cal_feed,
        'cal_agr_lus_land': dm_cal_land,
        'cal_agr_crop_emission_N2O-emission_fertilizer': dm_cal_n,
        'cal_agr_emission_CH4': dm_cal_CH4,
        'cal_agr_emission_N2O': dm_cal_N2O,
        'cal_agr_emission_CO2': dm_cal_CO2,
        'cal_agr_energy-demand': dm_cal_energy_demand,
        'cal_input': dm_cal_input,
        'ef_liv_N2O-emission': dm_ef_N2O,
        'ef_liv_CH4-emission_treated': dm_ef_CH4,
        'liv_manure_n-stock': dm_nstock,
        'ef_burnt-residues': dm_ef_burnt,
        'ef_soil-residues': dm_ef_soil,
        'residues_yield': dm_residues_yield,
        'fibers': dm_fibers,
        'rice': dm_rice,
        'agr_emission_fertilizer' : dm_n_fertilizer,
        'lus_land_total-area' : dm_land_total,
        'land-man_ef' : dm_ef_biomass,
        'land-man_soil-type' : dm_soil,
        'agr_climate-smart-crop_ef_agroforestry' : dm_crop_ef_agroforestry,
        'agr_climate-smart-livestock_ef_agroforestry': dm_livestock_ef_agroforestry,
        'agr_climate-smart-forestry' : dm_agroforestry
    }"""


    #####################
    ###### LEVERS #######
    #####################
    # LeversToDatamatrix
    dict_ots = {}
    dict_fts = {}

    # [TUTORIAL] Data - Lever - Population
    #file = 'lifestyles_population'  # File name to read
    #lever = 'pop'  # Lever name to match the JSON?

    # Creates the datamatrix for lifestyles population
    #dict_ots, dict_fts = read_database_to_ots_fts_dict_w_groups(file, lever, num_cat_list=[1, 0, 0], baseyear=baseyear,
    #                                                            years=years_all, dict_ots=dict_ots, dict_fts=dict_fts,
    #                                                            column='eucalc-name',
    #                                                            group_list=['lfs_demography_.*',
    #                                                                        'lfs_macro-scenarii_.*',
    #                                                                        'lfs_population_.*'])

    # Data - Lever - Diet
    lever = 'diet'
    df_ots, df_fts = database_to_df(df_diet_pathwaycalc, lever, level='all')
    df_ots = df_ots.drop(columns=[lever])  # Drop column with lever name
    dm = DataMatrix.create_from_df(df_ots, num_cat=0)
    dict_temp = {}
    dm_temp = dm.filter_w_regex({'Variables': 'lfs_consumers-diet.*'})
    dm_temp.deepen()
    dict_temp['lfs_consumers-diet'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'share.*'})
    dm_temp.deepen()
    dict_temp['share'] = dm_temp
    dict_ots[lever] = dict_temp

    # Data - Lever - Energy requirements
    lever = 'kcal-req'
    df_ots, df_fts = database_to_df(df_kcal_req_pathwaycalc, lever, level='all')
    df_ots = df_ots.drop(columns=[lever])  # Drop column with lever name
    dm = DataMatrix.create_from_df(df_ots, num_cat=0)
    dict_ots[lever] = dm

    # Data - Lever - Food wastes
    lever = 'fwaste'
    df_ots, df_fts = database_to_df(df_waste_pathwaycalc, lever, level='all')
    df_ots = df_ots.drop(columns=[lever])  # Drop column with lever name
    dm = DataMatrix.create_from_df(df_ots, num_cat=1)
    dict_ots[lever] = dm

    # Data - Lever - self-sufficiency
    lever = 'food-net-import'
    df_ots, df_fts = database_to_df(df_ssr_pathwaycalc, lever, level='all')
    df_ots = df_ots.drop(columns=[lever])  # Drop column with lever name
    dm = DataMatrix.create_from_df(df_ots, num_cat=1)
    dict_ots[lever] = dm

    # Data - Lever - climate smart livestock
    lever = 'climate-smart-livestock'
    df_ots, df_fts = database_to_df(df_climate_smart_livestock_pathwaycalc, lever, level='all')
    df_ots = df_ots.drop(columns=[lever])  # Drop column with lever name
    dm = DataMatrix.create_from_df(df_ots, num_cat=0)
    dict_temp = {}
    dm_losses = dm.filter_w_regex({'Variables': 'agr_climate-smart-livestock_losses.*'})
    dm_losses.deepen()
    dict_temp['climate-smart-livestock_losses'] = dm_losses
    dm_yield = dm.filter_w_regex({'Variables': 'agr_climate-smart-livestock_yield.*'})
    dm_yield.deepen()
    dict_temp['climate-smart-livestock_yield'] = dm_yield
    dm_slau = dm.filter_w_regex({'Variables': 'agr_climate-smart-livestock_slaughtered.*'})
    dm_slau.deepen()
    dict_temp['climate-smart-livestock_slaughtered'] = dm_slau
    dm_density = dm.filter_w_regex({'Variables': 'agr_climate-smart-livestock_density.*'})
    dict_temp['climate-smart-livestock_density'] = dm_density
    dm_enteric = dm.filter_w_regex({'Variables': 'agr_climate-smart-livestock_enteric.*'})
    dm_enteric.deepen()
    dict_temp['climate-smart-livestock_enteric'] = dm_enteric
    dm_manure = dm.filter_w_regex({'Variables': 'agr_climate-smart-livestock_manure.*'})
    dm_manure.deepen()
    dm_manure.deepen(based_on='Variables')
    dm_manure.switch_categories_order(cat1='Categories2', cat2='Categories1')
    dict_temp['climate-smart-livestock_manure'] = dm_manure
    dm_ration = dm.filter_w_regex({'Variables': 'agr_climate-smart-livestock_ration.*'})
    dm_ration.deepen()
    dict_temp['climate-smart-livestock_ration'] = dm_ration
    dm_ef = dm.filter_w_regex({'Variables': 'agr_climate-smart-livestock_ef_agroforestry.*'})
    dm_ef.deepen()
    dict_temp['agr_climate-smart-livestock_ef_agroforestry'] = dm_ef
    dict_ots[lever] = dict_temp
    #edit_database(file,lever,column='eucalc-name',pattern={'_CH4-emission':''},mode='rename')
    #edit_database(file,lever,column='eucalc-name',pattern={'ration_crop_':'ration_crop-', 'ration_liv_':'ration_liv-'},mode='rename')
    """dict_ots, dict_fts = read_database_to_ots_fts_dict_w_groups(file, lever, num_cat_list=[1, 1, 1, 0, 1, 2, 1, 1], baseyear=baseyear,
                                                                years=years_all, dict_ots=dict_ots, dict_fts=dict_fts,
                                                                column='eucalc-name',
                                                                group_list=['climate-smart-livestock_losses.*', 'climate-smart-livestock_yield.*',
                                                                            'climate-smart-livestock_slaughtered.*', 'climate-smart-livestock_density',
                                                                            'climate-smart-livestock_enteric.*', 'climate-smart-livestock_manure.*',
                                                                            'climate-smart-livestock_ration.*', 'agr_climate-smart-livestock_ef_agroforestry.*'])
    """
    # Data - Lever - biomass hierarchy
    lever = 'biomass-hierarchy'
    df_ots, df_fts = database_to_df(df_biomass_hierarchy_pathwaycalc, lever, level='all')
    df_ots = df_ots.drop(columns=[lever])  # Drop column with lever name
    dm = DataMatrix.create_from_df(df_ots, num_cat=0)
    dict_temp = {}
    dm_temp = dm.filter_w_regex({'Variables': '.*biomass-hierarchy-bev-ibp-use-oth.*'})
    dm_temp.deepen()
    dict_temp['biomass-hierarchy-bev-ibp-use-oth'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_biomass-hierarchy_biomass-mix_digestor.*'})
    dm_temp.deepen()
    dict_temp['biomass-hierarchy_biomass-mix_digestor'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_biomass-hierarchy_biomass-mix_solid.*'})
    dm_temp.deepen()
    dict_temp['biomass-hierarchy_biomass-mix_solid'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_biomass-hierarchy_biomass-mix_liquid.*'})
    dm_temp.deepen()
    dict_temp['biomass-hierarchy_biomass-mix_liquid'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_biomass-hierarchy_bioenergy_liquid_biodiesel.*'})
    dm_temp.deepen()
    dict_temp['biomass-hierarchy_bioenergy_liquid_biodiesel'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_biomass-hierarchy_bioenergy_liquid_biogasoline.*'})
    dm_temp.deepen()
    dict_temp['biomass-hierarchy_bioenergy_liquid_biogasoline'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_biomass-hierarchy_bioenergy_liquid_biojetkerosene.*'})
    dm_temp.deepen()
    dict_temp['biomass-hierarchy_bioenergy_liquid_biojetkerosene'] = dm_temp
    #dm_temp = dm.filter_w_regex({'Variables': 'agr_biomass-hierarchy_crop_cereal.*'})
    #dm_temp.deepen()
    #dict['biomass-hierarchy_crop_cereal'] = dm_temp
    dict_ots[lever] = dict_temp

    """    dict_ots, dict_fts = read_database_to_ots_fts_dict_w_groups(file, lever, num_cat_list=[1, 1, 1, 1, 1, 1, 1, 1], baseyear=baseyear,
                                                                years=years_all, dict_ots=dict_ots, dict_fts=dict_fts,
                                                                column='eucalc-name',
                                                                group_list=['.*biomass-hierarchy-bev-ibp-use-oth.*',
                                                                            'biomass-hierarchy_biomass-mix_digestor.*',
                                                                            'biomass-hierarchy_biomass-mix_solid.*',
                                                                            'biomass-hierarchy_biomass-mix_liquid.*',
                                                                            'biomass-hierarchy_bioenergy_liquid_biodiesel.*',
                                                                            'biomass-hierarchy_bioenergy_liquid_biogasoline.*',
                                                                            'biomass-hierarchy_bioenergy_liquid_biojetkerosene.*',
                                                                            'biomass-hierarchy_crop_cereal.*'])"""

    # Data - Lever - bioenergy capacity
    lever = 'bioenergy-capacity'
    df_ots, df_fts = database_to_df(df_bioenergy_capacity_CH_pathwaycalc, lever, level='all')
    df_ots = df_ots.drop(columns=[lever])  # Drop column with lever name
    dm = DataMatrix.create_from_df(df_ots, num_cat=0)
    dict_temp = {}
    dm_temp = dm.filter_w_regex({'Variables': 'agr_bioenergy-capacity_load-factor.*'})
    dm_temp.deepen()
    dict_temp['bioenergy-capacity_load-factor'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_bioenergy-capacity_bgs-mix.*'})
    dm_temp.deepen()
    dict_temp['bioenergy-capacity_bgs-mix'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_bioenergy-capacity_efficiency.*'})
    dm_temp.deepen()
    dict_temp['bioenergy-capacity_efficiency'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_bioenergy-capacity_liq_b.*'})
    dm_temp.deepen()
    dict_temp['bioenergy-capacity_liq_b'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_bioenergy-capacity_elec.*'})
    dm_temp.deepen()
    dict_temp['bioenergy-capacity_elec'] = dm_temp
    dict_ots[lever] = dict_temp
    # Rename to correct format
    #edit_database(file,lever,column='eucalc-name',pattern={'capacity_solid-biofuel':'capacity_elec_solid-biofuel', 'capacity_biogases':'capacity_elec_biogases'},mode='rename')
    """    dict_ots, dict_fts = read_database_to_ots_fts_dict_w_groups(file, lever, num_cat_list=[1, 1, 1, 1, 1], baseyear=baseyear,
                                                                years=years_all, dict_ots=dict_ots, dict_fts=dict_fts,
                                                                column='eucalc-name',
                                                                group_list=['bioenergy-capacity_load-factor.*', 'bioenergy-capacity_bgs-mix.*',
                                                                            'bioenergy-capacity_efficiency.*', 'bioenergy-capacity_liq_b.*', 'bioenergy-capacity_elec.*'])
    """
    # Data - Lever - livestock protein meals
    lever = 'alt-protein'
    df_ots, df_fts = database_to_df(df_protein_meals_pathwaycalc, lever, level='all')
    df_ots = df_ots.drop(columns=[lever])  # Drop column with lever name
    dm = DataMatrix.create_from_df(df_ots, num_cat=2)
    dict_ots[lever] = dm


    # Data - Lever - climate smart crop
    lever = 'climate-smart-crop'
    df_ots, df_fts = database_to_df(df_climate_smart_crop_pathwaycalc, lever, level='all')
    df_ots = df_ots.drop(columns=[lever])  # Drop column with lever name
    dm = DataMatrix.create_from_df(df_ots, num_cat=0)
    dict_temp = {}
    dm_temp = dm.filter_w_regex({'Variables': 'agr_climate-smart-crop_losses.*'})
    dm_temp.deepen()
    dict_temp['climate-smart-crop_losses'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_climate-smart-crop_yield.*'})
    dm_temp.deepen()
    dict_temp['climate-smart-crop_yield'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_climate-smart-crop_input-use.*'})
    dm_temp.deepen()
    dict_temp['climate-smart-crop_input-use'] = dm_temp
    dm_temp = dm.filter_w_regex({'Variables': 'agr_climate-smart-crop_energy-demand.*'})
    dm_temp.deepen()
    dict_temp['climate-smart-crop_energy-demand'] = dm_temp
    dict_ots[lever] = dict_temp
    """dict_ots, dict_fts = read_database_to_ots_fts_dict_w_groups(file, lever, num_cat_list=[1, 1, 1, 1],
                                                                baseyear=baseyear,
                                                                years=years_all, dict_ots=dict_ots, dict_fts=dict_fts,
                                                                column='eucalc-name',
                                                                group_list=['climate-smart-crop_losses.*',
                                                                            'climate-smart-crop_yield.*',
                                                                            'agr_climate-smart-crop_input-use.*',
                                                                            'agr_climate-smart-crop_energy-demand.*'])"""

    #####################
    ###### CONSTANTS #######
    #####################
    # ConstantsToDatamatrix
    # Data - Read Constants (use 'xx|xx|xx' to add)
    cdm_const = ConstantDataMatrix.extract_constant('interactions_constants',
                                                    pattern='cp_time_days-per-year.*|cp_ibp_liv_.*_brf_fdk_afat|cp_ibp_liv_.*_brf_fdk_offal|cp_ibp_bev_.*|cp_liquid_tec.*|cp_load_hours|cp_ibp_aps_insect.*|cp_ibp_aps_algae.*|cp_efficiency_liv.*|cp_ibp_processed.*|cp_ef_urea.*|cp_ef_liming|cp_emission-factor_CO2.*',
                                                    num_cat=0)

    # Constant pre-processing ------------------------------------------------------------------------------------------
    # Creating a dictionnay with contants
    dict_const = {}

    # Time per year
    cdm_lifestyle = cdm_const.filter({'Variables': ['cp_time_days-per-year']})
    dict_const['cdm_lifestyle'] = cdm_lifestyle

    # Filter ibp constants for offal
    cdm_cp_ibp_offal = cdm_const.filter_w_regex({'Variables': 'cp_ibp_liv_.*_brf_fdk_offal'})
    cdm_cp_ibp_offal.rename_col_regex('_brf_fdk_offal', '', dim='Variables')
    cdm_cp_ibp_offal.rename_col_regex('liv_', 'liv_meat-', dim='Variables')
    cdm_cp_ibp_offal.deepen(based_on='Variables')  # Creating categories
    dict_const['cdm_cp_ibp_offal'] = cdm_cp_ibp_offal

    # Filter ibp constants for afat
    cdm_cp_ibp_afat = cdm_const.filter_w_regex({'Variables': 'cp_ibp_liv_.*_brf_fdk_afat'})
    cdm_cp_ibp_afat.rename_col_regex('_brf_fdk_afat', '', dim='Variables')
    cdm_cp_ibp_afat.rename_col_regex('liv_', 'liv_meat-', dim='Variables')
    cdm_cp_ibp_afat.deepen(based_on='Variables')  # Creating categories
    dict_const['cdm_cp_ibp_afat'] = cdm_cp_ibp_afat

    # Filtering relevant constants and sorting according to bev type (beer, wine, bev-alc, bev-fer)
    cdm_cp_ibp_bev_beer = cdm_const.filter_w_regex({'Variables': 'cp_ibp_bev_beer.*'})
    dict_const['cdm_cp_ibp_bev_beer'] = cdm_cp_ibp_bev_beer
    cdm_cp_ibp_bev_wine = cdm_const.filter_w_regex({'Variables': 'cp_ibp_bev_wine.*'})
    dict_const['cdm_cp_ibp_bev_wine'] = cdm_cp_ibp_bev_wine
    cdm_cp_ibp_bev_alc = cdm_const.filter_w_regex({'Variables': 'cp_ibp_bev_bev-alc.*'})
    dict_const['cdm_cp_ibp_bev_alc'] = cdm_cp_ibp_bev_alc
    cdm_cp_ibp_bev_fer = cdm_const.filter_w_regex({'Variables': 'cp_ibp_bev_bev-fer.*'})
    dict_const['cdm_cp_ibp_bev_fer'] = cdm_cp_ibp_bev_fer

    # Constants for biofuels
    cdm_biodiesel = cdm_const.filter_w_regex(({'Variables': 'cp_liquid_tec_biodiesel'}))
    cdm_biodiesel.rename_col_regex(str1="_fdk_oil", str2="", dim="Variables")
    cdm_biodiesel.rename_col_regex(str1="_fdk_lgn", str2="", dim="Variables")
    cdm_biodiesel.deepen()
    dict_const['cdm_biodiesel'] = cdm_biodiesel
    cdm_biogasoline = cdm_const.filter_w_regex(({'Variables': 'cp_liquid_tec_biogasoline'}))
    cdm_biogasoline.rename_col_regex(str1="_fdk_eth", str2="", dim="Variables")
    cdm_biogasoline.rename_col_regex(str1="_fdk_lgn", str2="", dim="Variables")
    cdm_biogasoline.deepen()
    dict_const['cdm_biogasoline'] = cdm_biogasoline
    cdm_biojetkerosene = cdm_const.filter_w_regex(({'Variables': 'cp_liquid_tec_biojetkerosene'}))
    cdm_biojetkerosene.rename_col_regex(str1="_fdk_oil", str2="", dim="Variables")
    cdm_biojetkerosene.rename_col_regex(str1="_fdk_lgn", str2="", dim="Variables")
    cdm_biojetkerosene.deepen()
    dict_const['cdm_biojetkerosene'] = cdm_biojetkerosene

    # Filter protein conversion efficiency constant
    cdm_cp_efficiency = cdm_const.filter_w_regex({'Variables': 'cp_efficiency_liv.*'})
    cdm_cp_efficiency.rename_col_regex('meat_', 'meat-', dim='Variables')
    cdm_cp_efficiency.rename_col_regex('abp_', 'abp-', dim='Variables')
    cdm_cp_efficiency.deepen(based_on='Variables')  # Creating categories
    dict_const['cdm_cp_efficiency'] = cdm_cp_efficiency

    # Constants for APS byproducts
    cdm_aps_ibp = cdm_const.filter_w_regex({'Variables': 'cp_ibp_aps.*'})
    cdm_aps_ibp.drop(dim='Variables', col_label=['cp_ibp_aps_insect_brf_fdk_manure'])
    cdm_aps_ibp.rename_col_regex('brf_', '', dim='Variables')
    cdm_aps_ibp.rename_col_regex('crop_algae', 'crop', dim='Variables')
    cdm_aps_ibp.rename_col_regex('crop_insect', 'crop', dim='Variables')
    cdm_aps_ibp.rename_col_regex('fdk_', 'fdk-', dim='Variables')
    cdm_aps_ibp.rename_col_regex('algae_', 'algae-', dim='Variables')  # Extra steps to have the correct cat order
    cdm_aps_ibp.rename_col_regex('insect_', 'insect-', dim='Variables')
    cdm_aps_ibp.deepen(based_on='Variables')  # Creating categories
    cdm_aps_ibp.rename_col_regex('algae-', 'algae_', dim='Categories1')  # Extra steps to have the correct cat order
    cdm_aps_ibp.rename_col_regex('insect-', 'insect_', dim='Categories1')
    cdm_aps_ibp.deepen(based_on='Categories1')
    dict_const['cdm_aps_ibp'] = cdm_aps_ibp

    # Feed yield
    cdm_feed_yield = cdm_const.filter_w_regex({'Variables': 'cp_ibp_processed'})
    cdm_feed_yield.rename_col_regex(str1="_to_", str2="-to-", dim="Variables")
    cdm_feed_yield.deepen()
    cdm_food_yield = cdm_feed_yield.filter({'Categories1': ['sweet-to-sugarcrop']})
    cdm_feed_yield.drop(dim='Categories1', col_label=['sweet-to-sugarcrop'])
    dict_const['cdm_food_yield'] = cdm_food_yield
    dict_const['cdm_feed_yield'] = cdm_feed_yield

    # Fertilizer
    cdm_fertilizer_co = cdm_const.filter({'Variables': ['cp_ef_liming', 'cp_ef_urea']})
    cdm_fertilizer_co.deepen()
    dict_const['cdm_fertilizer_co'] = cdm_fertilizer_co

    # CO2 emissions factor bioenergy
    cdm_const.rename_col_regex(str1="liquid_", str2="liquid-", dim="Variables")
    cdm_const.rename_col_regex(str1="gas_", str2="gas-", dim="Variables")
    cdm_const.rename_col_regex(str1="solid_", str2="solid-", dim="Variables")
    cdm_CO2 = cdm_const.filter({'Variables': ['cp_emission-factor_CO2_bioenergy-gas-biogas',
                                              'cp_emission-factor_CO2_bioenergy-liquid-biodiesels',
                                              'cp_emission-factor_CO2_bioenergy-liquid-ethanol',
                                              'cp_emission-factor_CO2_bioenergy-liquid-oth',
                                              'cp_emission-factor_CO2_bioenergy-solid-wood',
                                              'cp_emission-factor_CO2_electricity',
                                              'cp_emission-factor_CO2_gas-ff-natural', 'cp_emission-factor_CO2_heat',
                                              'cp_emission-factor_CO2_liquid-ff-diesel',
                                              'cp_emission-factor_CO2_liquid-ff-fuel-oil',
                                              'cp_emission-factor_CO2_liquid-ff-gasoline',
                                              'cp_emission-factor_CO2_liquid-ff-lpg', 'cp_emission-factor_CO2_oth',
                                              'cp_emission-factor_CO2_solid-ff-coal'],
                                'units': ['MtCO2/ktoe']})
    cdm_CO2.deepen()
    dict_const['cdm_CO2'] = cdm_CO2

    # Electricity
    cdm_load = cdm_const.filter({'Variables': ['cp_load_hours-per-year-twh']})
    dict_const['cdm_load'] = cdm_load

    # Group all datamatrix in a single structure -----------------------------------------------------------------------
    DM_agriculture = {
        'fxa': DM_agriculture_old['fxa'],
        'constant': dict_const,
        'fts': dm_fts,
        'ots': dict_ots
    }

    # Add EU27 and Vaud as dummys
    add_dummy_country_to_DM(DM_agriculture, 'EU27', 'Switzerland')
    add_dummy_country_to_DM(DM_agriculture, 'Vaud', 'Switzerland')

    # FXA pre-processing -----------------------------------------------------------------------------------------------

    # Emssion factors residues residues
    #DM_agriculture['fxa']['ef_soil-residues'].add(0.0, dummy=True, col_label='CH4-emission', dim='Categories1', unit='Mt')
    #DM_agriculture['fxa']['ef_soil-residues'].sort(dim='Categories1')
    #DM_agriculture['fxa']['ef_burnt-residues'].append(DM_agriculture['fxa']['ef_soil-residues'], dim='Variables')
    #DM_agriculture['fxa']['ef_burnt-residues'] = DM_agriculture['fxa']['ef_burnt-residues'].flatten()  # extra steps to have correct deepening
    #DM_agriculture['fxa']['ef_burnt-residues'].rename_col_regex(str1="residues_", str2="residues-", dim="Variables")
    #DM_agriculture['fxa']['ef_burnt-residues'].rename_col_regex(str1="fxa_", str2="", dim="Variables")
    #DM_agriculture['fxa']['ef_burnt-residues'].deepen()
    #DM_agriculture['fxa']['ef_burnt-residues'].rename_col_regex(str1="residues-", str2="residues_", dim="Categories1")
    #DM_agriculture['fxa']['ef_burnt-residues'].deepen()

    # caf GHG emissions
    #DM_agriculture['fxa']['cal_agr_emission_CH4'].append(DM_agriculture['fxa']['cal_agr_emission_N2O'], dim='Variables')
    #DM_agriculture['fxa']['cal_agr_emission_CH4'].append(DM_agriculture['fxa']['cal_agr_emission_CO2'], dim='Variables')
    #DM_agriculture['fxa']['cal_agr_emission_CH4'].rename_col_regex(str1='cal_agr_emissions-', str2='cal_agr_emissions_', dim='Variables')
    #DM_agriculture['fxa']['cal_agr_emission_CH4'].deepen()

    # write datamatrix to pickle
    __file__ = "/Users/crosnier/Documents/PathwayCalc/_database"
    current_file_directory = os.path.dirname(os.path.abspath(__file__))
    f = os.path.join(current_file_directory, '_database/data/datamatrix/agriculture.pickle')
    with open(f, 'wb') as handle:
        pickle.dump(DM_agriculture, handle, protocol=pickle.HIGHEST_PROTOCOL)
    return


# CalculationTree RUNNING LEVERS PRE-PROCESSING -----------------------------------------------------------------------------------------------
__file__ = "/Users/crosnier/Documents/PathwayCalc/_database"
current_file_directory = os.path.dirname(os.path.abspath(__file__))
f = os.path.join(current_file_directory, '_database/data/datamatrix/agriculture.pickle')

years_ots = create_years_list(1990, 2023, 1)  # make list with years from 1990 to 2015

df_diet_pathwaycalc, df_diet = diet_processing()
df_waste_pathwaycalc = food_waste_processing(df_diet)
df_kcal_req_pathwaycalc = energy_requirements_processing()
df_ssr_pathwaycalc, df_csl_feed = self_sufficiency_processing(years_ots)
df_climate_smart_crop_pathwaycalc, df_energy_demand_cal = climate_smart_crop_processing()
df_climate_smart_livestock_pathwaycalc = climate_smart_livestock_processing(df_csl_feed)
df_climate_smart_forestry_pathwaycalc, csf_managed = climate_smart_forestry_processing() #FutureWarning at last line
df_land_management_pathwaycalc = land_management_processing(csf_managed)
df_bioenergy_capacity_CH_pathwaycalc = bioernergy_capacity_processing(df_csl_feed)
df_biomass_hierarchy_pathwaycalc = biomass_bioernergy_hierarchy_processing(df_csl_feed)
df_protein_meals_pathwaycalc = livestock_protein_meals_processing(df_csl_feed)

# CalculationTree RUNNING CALIBRATION ----------------------------------------------------------------------------------
df_diet_calibration = lifestyle_calibration()
df_domestic_supply_calibration, df_liv_population_calibration = livestock_crop_calibration(df_energy_demand_cal)
df_nitrogen_calibration = nitrogen_calibration()
df_liv_emissions_calibration = manure_calibration()
df_feed_calibration = feed_calibration()
df_land_use_fao_calibration = land_calibration()
df_liming_urea_calibration = CO2_emissions()
df_wood_calibration = wood_calibration()
df_emissions_calibration = energy_ghg_calibration() # Fixme PerformanceWarning ?
df_calibration = calibration_formatting(df_diet_calibration, df_domestic_supply_calibration, df_liv_population_calibration,
                     df_nitrogen_calibration, df_liv_emissions_calibration, df_feed_calibration,
                     df_land_use_fao_calibration, df_liming_urea_calibration, df_wood_calibration,
                     df_emissions_calibration) # Fixme PerformanceWarning ?

# CalculationTree RUNNING FXA PRE-PROCESSING ---------------------------------------------------------------------------
#fxa_preprocessing()
# CalculationTree RUNNING PICKLE CREATION
database_from_csv_to_datamatrix() #Fixme duplicates in constants


